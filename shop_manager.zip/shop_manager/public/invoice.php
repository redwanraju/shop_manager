<?php
session_start();
include("../includes/header2.php");
/*
 * DB connection - change credentials if needed
 */
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shop_manager";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("DB Connection failed: " . $conn->connect_error);
}

/*
 * Simple CSRF token
 */
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(24));
}
$csrf_token = $_SESSION['csrf_token'];

$errors = [];
$warnings = [];
$success = '';
$invoice_id = null;

/*
 * Fetch products list for select options (safe)
 */
$prod_array = [];
$stmt = $conn->prepare("SELECT id, name, stock, unit, price, min_stock FROM products ORDER BY name ASC");
if ($stmt) {
    $stmt->execute();
    $res = $stmt->get_result();
    while ($r = $res->fetch_assoc()) {
        $prod_array[] = $r;
    }
    $stmt->close();
} else {
    $errors[] = "Failed to fetch products.";
}

/*
 * Handle form submit - create invoice
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_invoice'])) {

    // CSRF check
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $errors[] = "Invalid form submission (CSRF token mismatch).";
    } else {

        // Basic sanitation & validation
        $product_ids = $_POST['product_id'] ?? [];
        $quantities  = $_POST['quantity'] ?? [];
        $prices      = $_POST['price'] ?? [];

        if (!is_array($product_ids) || !is_array($quantities) || !is_array($prices)) {
            $errors[] = "Invalid product data.";
        } else {
            // Normalize arrays lengths
            $n = count($product_ids);
            if ($n === 0) {
                $errors[] = "Add at least one product.";
            } else {
                // Parse discount, tax, paid
                $discount = isset($_POST['discount']) ? floatval($_POST['discount']) : 0.0;
                $tax_percent = isset($_POST['tax']) ? floatval($_POST['tax']) : 0.0;
                $paid = isset($_POST['paid']) ? floatval($_POST['paid']) : 0.0;

                // Build items array with validated values
                $items = []; // each: ['product_id'=>int, 'qty'=>int, 'price'=>float]
                for ($i = 0; $i < $n; $i++) {
                    $pid = intval($product_ids[$i]);
                    $qty = intval($quantities[$i]);
                    $price = floatval($prices[$i]);

                    if ($pid <= 0) continue;
                    if ($qty < 0) $qty = 0;
                    if ($price < 0) $price = 0.0;

                    // skip zero quantity entries
                    if ($qty === 0) continue;

                    $items[] = [
                        'product_id' => $pid,
                        'qty' => $qty,
                        'price' => $price
                    ];
                }

                if (count($items) === 0) {
                    $errors[] = "No valid items (quantity > 0) provided.";
                } else {
                    // Start transaction
                    $conn->begin_transaction();

                    try {
                        // Insert invoice (invoice_no + created_at)
                        $invoice_no = "INV" . time();
                        $stmt = $conn->prepare("INSERT INTO invoices (invoice_no, created_at) VALUES (?, NOW())");
                        if (!$stmt) throw new Exception("Prepare failed (invoices insert): " . $conn->error);
                        $stmt->bind_param("s", $invoice_no);
                        if (!$stmt->execute()) throw new Exception("Execute failed (invoices insert): " . $stmt->error);
                        $invoice_id = $conn->insert_id;
                        $stmt->close();

                        $subtotal = 0.0;

                        // For each item: check stock, insert invoice_items, update product stock
                        $select_product_stmt = $conn->prepare("SELECT stock, min_stock, name FROM products WHERE id = ? FOR UPDATE");
                        if (!$select_product_stmt) throw new Exception("Prepare failed (select product): " . $conn->error);

                        $insert_item_stmt = $conn->prepare("INSERT INTO invoice_items (invoice_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
                        if (!$insert_item_stmt) throw new Exception("Prepare failed (insert invoice_items): " . $conn->error);

                        $update_stock_stmt = $conn->prepare("UPDATE products SET stock = stock - ? WHERE id = ?");
                        if (!$update_stock_stmt) throw new Exception("Prepare failed (update products): " . $conn->error);

                        foreach ($items as $it) {
                            $pid = $it['product_id'];
                            $qty = $it['qty'];
                            $price = $it['price'];

                            // Lock & fetch current stock
                            $select_product_stmt->bind_param("i", $pid);
                            $select_product_stmt->execute();
                            $res = $select_product_stmt->get_result();
                            $prod = $res->fetch_assoc();
                            if (!$prod) {
                                // product not found => skip or throw
                                throw new Exception("Product ID {$pid} not found.");
                            }

                            $current_stock = intval($prod['stock']);
                            $min_stock = intval($prod['min_stock']);
                            $prod_name = $prod['name'];

                            if ($qty > $current_stock) {
                                // Option A: adjust to available stock (like earlier behavior)
                                // $qty = $current_stock;
                                // Or Option B: throw — choose Option A for compatibility but notify user
                                $warnings[] = "Requested quantity for '{$prod_name}' exceeded stock ({$current_stock}). Adjusted to available stock.";
                                $qty = $current_stock;
                            }

                            if ($qty <= 0) {
                                // nothing to insert if adjusted to 0
                                continue;
                            }

                            // Insert invoice item
                            $insert_item_stmt->bind_param("iiid", $invoice_id, $pid, $qty, $price);
                            if (!$insert_item_stmt->execute()) throw new Exception("Insert invoice_items failed: " . $insert_item_stmt->error);

                            // Update product stock
                            $update_stock_stmt->bind_param("ii", $qty, $pid);
                            if (!$update_stock_stmt->execute()) throw new Exception("Update products stock failed: " . $update_stock_stmt->error);

                            // Check min stock after update (get remaining)
                            $remaining = $current_stock - $qty;
                            if ($remaining < $min_stock) {
                                $warnings[] = "Stock for '{$prod_name}' is below minimum ({$min_stock}) after this sale (remaining: {$remaining}).";
                            }

                            $subtotal += ($qty * $price);
                        }

                        // close statements
                        $select_product_stmt->close();
                        $insert_item_stmt->close();
                        $update_stock_stmt->close();

                        // Calculate tax/total/due
                        $tax_amount = ($subtotal - $discount) * ($tax_percent / 100);
                        $total = $subtotal - $discount + $tax_amount;
                        $due = $total - $paid;

                        // Update invoice with totals
                        $update_invoice_stmt = $conn->prepare("UPDATE invoices SET subtotal = ?, discount = ?, tax = ?, total = ?, paid = ?, due = ? WHERE id = ?");
                        if (!$update_invoice_stmt) throw new Exception("Prepare failed (update invoice): " . $conn->error);
                        $update_invoice_stmt->bind_param("ddddddi", $subtotal, $discount, $tax_amount, $total, $paid, $due, $invoice_id);
                        if (!$update_invoice_stmt->execute()) throw new Exception("Execute failed (update invoice): " . $update_invoice_stmt->error);
                        $update_invoice_stmt->close();

                        // Commit transaction
                        $conn->commit();
                        $success = "Invoice created successfully (Invoice No: {$invoice_no}).";
                        // regenerate CSRF token to avoid resubmission
                        $_SESSION['csrf_token'] = bin2hex(random_bytes(24));
                        $csrf_token = $_SESSION['csrf_token'];

                    } catch (Exception $e) {
                        $conn->rollback();
                        $errors[] = "Transaction failed: " . $e->getMessage();
                        // optional: log $e->getMessage()
                    }
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Create Invoice</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- jsPDF + html2canvas -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <style>
        .out-stock { background-color: #f8d7da !important; }
    </style>
</head>
<body class="container py-4">

    <h2 class="mb-4">🧾 Create Invoice</h2>

    <!-- messages -->
    <?php if (!empty($success)): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <?php if (!empty($warnings)): ?>
        <div class="alert alert-warning">
            <?php foreach ($warnings as $w) echo htmlspecialchars($w) . "<br>"; ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <?php foreach ($errors as $err) echo htmlspecialchars($err) . "<br>"; ?>
        </div>
    <?php endif; ?>


    <form method="POST" id="invoice_form" class="mb-3">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">

<table class="table table-bordered" id="invoice_table">
    <thead class="table-dark">
        <tr>
            <th style="width:55%">Product</th>
            <th style="width:15%">Quantity</th>
            <th style="width:15%">Unit Price</th>
            <th style="width:15%">Line Total</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>
                <select name="product_id[]" class="form-select product_select" required>
                    <option value="">-- Select product --</option>
                    <?php foreach ($prod_array as $p): ?>
                        <option value="<?= (int)$p['id'] ?>" 
                                data-price="<?= htmlspecialchars($p['price']) ?>">
                            <?= htmlspecialchars($p['name']) ?> 
                            (Stock: <?= (int)$p['stock'] ?> <?= htmlspecialchars($p['unit']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </td>
            <td><input type="number" name="quantity[]" class="form-control qty_input" min="1" value="1" required></td>
            <td><input type="number" name="price[]" class="form-control price_input" step="0.01" min="0" value="0.00" required></td>
            <td class="line_total text-end">0.00</td>
        </tr>
    </tbody>
</table>

<!-- মোট টোটাল দেখানোর অংশ -->
<div class="text-end mb-3">
    <h4>Gross Total: <span id="grand_total">0.00</span></h4>
</div>


        <div class="d-flex gap-2 mb-3">
            <button type="button" class="btn btn-secondary" id="add_row_btn">➕ Add Product</button>
            <button type="button" class="btn btn-outline-secondary" id="clear_rows_btn">Reset Rows</button>
        </div>

        <div class="row mb-3">
            <div class="col-md-4">
                <label>Discount</label>
                <input type="number" step="0.01" name="discount" class="form-control" value="0.00">
            </div>
            <div class="col-md-4">
                <label>Tax %</label>
                <input type="number" step="0.01" name="tax" class="form-control" value="0.00">
            </div>
            <div class="col-md-4">
                <label>Paid Amount</label>
                <input type="number" step="0.01" name="paid" class="form-control" value="0.00">
            </div>
			
        </div>

        <div class="text-end mb-3">
            <button type="submit" name="create_invoice" class="btn btn-primary">Create Invoice</button>
        </div>
    </form>

    <?php
    // If invoice created, show invoice preview for print/pdf
    if ($invoice_id) {
        $inv_stmt = $conn->prepare("SELECT * FROM invoices WHERE id = ?");
        $inv_stmt->bind_param("i", $invoice_id);
        $inv_stmt->execute();
        $invoice_data = $inv_stmt->get_result()->fetch_assoc();
        $inv_stmt->close();

        $items_stmt = $conn->prepare("SELECT ii.*, p.name, p.unit FROM invoice_items ii JOIN products p ON ii.product_id = p.id WHERE ii.invoice_id = ?");
        $items_stmt->bind_param("i", $invoice_id);
        $items_stmt->execute();
        $items_res = $items_stmt->get_result();
    ?>
        <div class="card mt-4" id="invoice_print">
            <div class="card-body">
                <h4>Invoice No: <?= htmlspecialchars($invoice_data['invoice_no']) ?></h4>
                <p>Date: <?= htmlspecialchars($invoice_data['created_at']) ?></p>

                <table class="table table-bordered">
                    <thead class="table-dark">
                        <tr><th>Product</th><th class="text-center">Qty</th><th>Unit</th><th class="text-end">Price</th><th class="text-end">Total</th></tr>
                    </thead>
                    <tbody>
                    <?php
                    $grand = 0.0;
                    while ($it = $items_res->fetch_assoc()) {
                        $line = $it['quantity'] * $it['price'];
                        $grand += $line;
                    ?>
                        <tr>
                            <td><?= htmlspecialchars($it['name']) ?></td>
                            <td class="text-center"><?= (int)$it['quantity'] ?></td>
                            <td><?= htmlspecialchars($it['unit']) ?></td>
                            <td class="text-end"><?= number_format($it['price'],2) ?></td>
                            <td class="text-end"><?= number_format($line,2) ?></td>
                        </tr>
                    <?php } ?>
                    </tbody>
                </table>

                <div class="text-end">
                    <p>Subtotal: <?= number_format($invoice_data['subtotal'],2) ?></p>
                    <p>Discount: <?= number_format($invoice_data['discount'],2) ?></p>
                    <p>Tax: <?= number_format($invoice_data['tax'],2) ?></p>
                    <h4>Total: <?= number_format($invoice_data['total'],2) ?></h4>
                    <p>Paid: <?= number_format($invoice_data['paid'],2) ?></p>
                    <p>Due: <?= number_format($invoice_data['due'],2) ?></p>
                </div>
            </div>
        </div>

        <div class="mt-3">
            <button class="btn btn-success" onclick="printInvoice()">🖨️ Print Invoice</button>
            <button class="btn btn-danger" onclick="downloadPDF('<?= htmlspecialchars($invoice_data['invoice_no']) ?>')">📄 Download PDF</button>
        </div>

    <?php
        $items_stmt->close();
    }
    ?>

<script>
/* pass PHP product array to JS safely */
let products = <?= json_encode($prod_array, JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>;

function makeOptionsHtml(){
    let out = '<option value="">-- Select product --</option>';
    products.forEach(p => {
        out += `<option value="${p.id}" data-stock="${p.stock}" data-unit="${escapeHtml(p.unit)}" data-price="${p.price}">${escapeHtml(p.name)} (Stock: ${p.stock} ${escapeHtml(p.unit)})</option>`;
    });
    return out;
}

function escapeHtml(s){
    if(!s && s!==0) return '';
    return String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;');
}

document.getElementById('add_row_btn').addEventListener('click', function(){
    const table = document.getElementById('invoice_table').getElementsByTagName('tbody')[0];
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>
                        <select name="product_id[]" class="form-select product_select" required>${makeOptionsHtml()}</select>
                    </td>
                    <td><input type="number" name="quantity[]" class="form-control qty_input" min="1" value="1" required></td>
                    <td><input type="number" name="price[]" class="form-control price_input" step="0.01" min="0" value="0.00" required></td>
                    <td class="line_total text-end">0.00</td>`;
    table.appendChild(tr);
    attachListenersToRow(tr);
});

document.getElementById('clear_rows_btn').addEventListener('click', function(){
    const tbody = document.getElementById('invoice_table').getElementsByTagName('tbody')[0];
    tbody.innerHTML = `<tr>
            <td>
                <select name="product_id[]" class="form-select product_select" required>
                    ${makeOptionsHtml()}
                </select>
            </td>
            <td><input type="number" name="quantity[]" class="form-control qty_input" min="1" value="1" required></td>
            <td><input type="number" name="price[]" class="form-control price_input" step="0.01" min="0" value="0.00" required></td>
            <td class="line_total text-end">0.00</td>
        </tr>`;
    attachAllRowListeners();
});

function attachListenersToRow(tr){
    const qtyInput = tr.querySelector('.qty_input');
    const priceInput = tr.querySelector('.price_input');
    const select = tr.querySelector('.product_select');

    function recalc(){
        const qty = parseFloat(qtyInput.value) || 0;
        const price = parseFloat(priceInput.value) || 0;
        tr.querySelector('.line_total').innerText = (qty * price).toFixed(2);
    }

    // when product selected, auto-fill price from master list
    select.addEventListener('change', function(){
        const pid = this.value;
        if(!pid) return;
        const opt = this.options[this.selectedIndex];
        const p_price = opt.getAttribute('data-price') || 0;
        priceInput.value = parseFloat(p_price).toFixed(2);
        recalc();
    });

    qtyInput.addEventListener('input', recalc);
    priceInput.addEventListener('input', recalc);
}

function attachAllRowListeners(){
    document.querySelectorAll('#invoice_table tbody tr').forEach(tr => attachListenersToRow(tr));
}

// attach on initial row(s)
attachAllRowListeners();

function printInvoice(){
    const element = document.getElementById('invoice_print');
    if(!element) return alert('No invoice to print yet.');
    const w = window.open('', '', 'height=800,width=1000');
    w.document.write('<html><head><title>Invoice</title>');
    w.document.write('<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">');
    w.document.write('</head><body>');
    w.document.write(element.innerHTML);
    w.document.write('</body></html>');
    w.document.close();
    w.print();
}

function downloadPDF(invoiceNo){
    const element = document.getElementById('invoice_print');
    if(!element) return alert('No invoice to download yet.');
    html2canvas(element).then(canvas => {
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jspdf.jsPDF('p','mm','a4');
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
        pdf.addImage(imgData,'PNG',0,0,pdfWidth,pdfHeight);
        pdf.save(`Invoice_${invoiceNo}.pdf`);
    });
}
function attachListenersToRow(tr){
    const qtyInput = tr.querySelector('.qty_input');
    const priceInput = tr.querySelector('.price_input');
    const select = tr.querySelector('.product_select');

    function recalc(){
        const qty = parseFloat(qtyInput.value) || 0;
        const price = parseFloat(priceInput.value) || 0;
        const lineTotal = qty * price;
        tr.querySelector('.line_total').innerText = lineTotal.toFixed(2);
        updateGrandTotal(); // সব রো এর যোগফল করবে
    }

    select.addEventListener('change', function(){
        const pid = this.value;
        if(!pid) return;
        const opt = this.options[this.selectedIndex];
        const p_price = opt.getAttribute('data-price') || 0;
        priceInput.value = parseFloat(p_price).toFixed(2);
        recalc();
    });

    qtyInput.addEventListener('input', recalc);
    priceInput.addEventListener('input', recalc);

    recalc(); // প্রথমেই কল হবে
}

function updateGrandTotal(){
    let total = 0;
    document.querySelectorAll('.line_total').forEach(td => {
        total += parseFloat(td.innerText) || 0;
    });
    document.getElementById('grand_total').innerText = total.toFixed(2);
}

</script>

</body>
</html>
