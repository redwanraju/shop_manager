<?php
session_start();
include("../includes/header.php");
include("../config/db.php");
require_once '../includes/auth.php';
start_secure_session();

if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// CSRF token
if (!isset($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(24));
$csrf_token = $_SESSION['csrf_token'];

$errors = $warnings = [];
$success = '';
$invoice_id = null;

// Fetch products (শুধু লগইনকৃত ইউজারের)
$prod_array = [];
$user_id = $_SESSION['user_id']; 
$stmt = $conn->prepare("SELECT id, name, stock, unit, price, min_stock 
                        FROM products 
                        WHERE user_id=? 
                        ORDER BY name ASC");
$stmt->bind_param("i", $user_id);
if ($stmt) {
    $stmt->execute();
    $res = $stmt->get_result();
    while ($r = $res->fetch_assoc()) $prod_array[] = $r;
    $stmt->close();
}

// Handle invoice form
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['create_invoice'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token']!==$_SESSION['csrf_token'])
        $errors[] = "Invalid CSRF token.";
    else {
        $product_ids = $_POST['product_id'] ?? [];
        $quantities = $_POST['quantity'] ?? [];
        $prices = $_POST['price'] ?? [];
        $n = count($product_ids);

        if ($n===0) $errors[]="Add at least one product.";
        else {
            $discount = floatval($_POST['discount'] ?? 0);
            $tax_percent = floatval($_POST['tax'] ?? 0);
            $paid = floatval($_POST['paid'] ?? 0);
            $items=[];

            for($i=0;$i<$n;$i++){
                $pid=intval($product_ids[$i]);
                $qty=intval($quantities[$i]);
                $price=floatval($prices[$i]);
                if($pid>0 && $qty>0) $items[]= ['product_id'=>$pid,'qty'=>$qty,'price'=>$price];
            }

            if(count($items)==0) $errors[]="No valid items provided.";
            else {
                $conn->begin_transaction();
                try {
                    $invoice_no="INV".time();
                    $user_id = $_SESSION['user_id']; // লগইন ইউজার
					$stmt = $conn->prepare("INSERT INTO invoices (invoice_no, created_at, user_id) VALUES (?, NOW(), ?)");
$stmt->bind_param("si", $invoice_no, $user_id); // শুধু এটিই যথেষ্ট
$stmt->execute();
$invoice_id = $conn->insert_id;
$stmt->close();


                 

                    $subtotal=0;
                    $select_product_stmt = $conn->prepare("SELECT stock, min_stock, name FROM products WHERE id=? FOR UPDATE");
                    $insert_item_stmt = $conn->prepare("INSERT INTO invoice_items (invoice_id, product_id, quantity, price) VALUES (?,?,?,?)");
                    $update_stock_stmt = $conn->prepare("UPDATE products SET stock=stock-? WHERE id=?");

                    foreach($items as $it){
                        $pid=$it['product_id']; $qty=$it['qty']; $price=$it['price'];
                        $select_product_stmt->bind_param("i",$pid); $select_product_stmt->execute();
                        $prod=$select_product_stmt->get_result()->fetch_assoc();
                        if(!$prod) throw new Exception("Product not found.");
                        $current_stock=intval($prod['stock']); $min_stock=intval($prod['min_stock']); $prod_name=$prod['name'];
                        if($qty>$current_stock){ $warnings[]="Quantity for '{$prod_name}' exceeds stock ({$current_stock}), adjusted."; $qty=$current_stock; }
                        if($qty<=0) continue;
                        $insert_item_stmt->bind_param("iiid",$invoice_id,$pid,$qty,$price); $insert_item_stmt->execute();
                        $update_stock_stmt->bind_param("ii",$qty,$pid); $update_stock_stmt->execute();
                        $remaining=$current_stock-$qty;
                        if($remaining<$min_stock) $warnings[]="Stock for '{$prod_name}' below minimum ({$min_stock}) after sale.";
                        $subtotal+=$qty*$price;
                    }

                    $select_product_stmt->close(); $insert_item_stmt->close(); $update_stock_stmt->close();
                    $tax_amount=($subtotal-$discount)*($tax_percent/100); $total=$subtotal-$discount+$tax_amount; $due=$total-$paid;
                    $stmt=$conn->prepare("UPDATE invoices SET subtotal=?, discount=?, tax=?, total=?, paid=?, due=? WHERE id=?");
                    $stmt->bind_param("ddddddi",$subtotal,$discount,$tax_amount,$total,$paid,$due,$invoice_id);
                    $stmt->execute(); $stmt->close();
                    $conn->commit();
                    $success="Invoice created successfully (Invoice No: {$invoice_no})";
                    $_SESSION['csrf_token']=bin2hex(random_bytes(24));
                    $csrf_token=$_SESSION['csrf_token'];
                } catch(Exception $e){
                    $conn->rollback();
                    $errors[]="Transaction failed: ".$e->getMessage();
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Create Invoice</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<style>.line_total{text-align:right;}</style>
</head>
<body class="container py-4">

<h2>🧾 Create Invoice</h2>

<?php if($success):?><div class="alert alert-success"><?=htmlspecialchars($success)?></div><?php endif;?>
<?php if($warnings):?><div class="alert alert-warning"><?php foreach($warnings as $w) echo htmlspecialchars($w)."<br>";?></div><?php endif;?>
<?php if($errors):?><div class="alert alert-danger"><?php foreach($errors as $e) echo htmlspecialchars($e)."<br>";?></div><?php endif;?>

<form method="POST" id="invoice_form">
<input type="hidden" name="csrf_token" value="<?=htmlspecialchars($csrf_token)?>">
<table class="table table-bordered" id="invoice_table">
<thead class="table-dark"><tr><th>Product</th><th>Qty</th><th>Unit Price</th><th>Line Total</th></tr></thead>
<tbody>
<tr>
<td>
<select name="product_id[]" class="form-select product_select" required>
    <option value="">-- Select product --</option>
    <?php
    // লগইনকৃত ইউজারের প্রোডাক্ট ফেচ করা
    $user_id = $_SESSION['user_id'];
    $stmt = $conn->prepare("SELECT id, name, stock, unit, price FROM products WHERE user_id=? ORDER BY name ASC");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($p = $result->fetch_assoc()):
    ?>
        <option value="<?= (int)$p['id'] ?>"
                data-price="<?= htmlspecialchars($p['price'], ENT_QUOTES) ?>"
                data-stock="<?= (int)$p['stock'] ?>"
                data-unit="<?= htmlspecialchars($p['unit'], ENT_QUOTES) ?>">
            <?= htmlspecialchars($p['name'], ENT_QUOTES) ?> 
            (Stock: <?= (int)$p['stock'] ?> <?= htmlspecialchars($p['unit'], ENT_QUOTES) ?>)
        </option>
    <?php endwhile; $stmt->close(); ?>
</select>

</td>
<td><input type="number" name="quantity[]" class="form-control qty_input" min="1" value="1" required></td>
<td><input type="number" name="price[]" class="form-control price_input" step="0.01" min="0" value="0.00" required></td>
<td class="line_total">0.00 </td>
</tr>
</tbody>
</table>

<div class="text-end mb-3"><h4>Grand Total: BDT <span id="grand_total">0.00</span></h4></div>
<div class="d-flex gap-2 mb-3">
<button type="button" class="btn btn-secondary" id="add_row_btn">➕ Add Product</button>
<button type="button" class="btn btn-outline-secondary" id="clear_rows_btn">Reset Rows</button>
</div>

<div class="row mb-3">
<div class="col-md-4"><label>Discount</label><input type="number" step="0.01" name="discount" class="form-control" value="0.00"></div>
<div class="col-md-4"><label>Tax %</label><input type="number" step="0.01" name="tax" class="form-control" value="0.00"></div>
<div class="col-md-4"><label>Paid Amount</label><input type="number" step="0.01" name="paid" class="form-control" value="0.00"></div>
</div>

<div class="text-end mb-3">
<button type="submit" name="create_invoice" class="btn btn-primary">Create Invoice</button>
<a href="./dashboard.php" class="btn btn-primary">Dashboard</a>
</div>
</form>

<?php if($invoice_id):
$inv_stmt=$conn->prepare("SELECT * FROM invoices WHERE id=?");
$inv_stmt->bind_param("i",$invoice_id); $inv_stmt->execute(); $invoice_data=$inv_stmt->get_result()->fetch_assoc(); $inv_stmt->close();
$items_stmt=$conn->prepare("SELECT ii.*, p.name, p.unit FROM invoice_items ii JOIN products p ON ii.product_id=p.id WHERE ii.invoice_id=?");
$items_stmt->bind_param("i",$invoice_id); $items_stmt->execute(); $items_res=$items_stmt->get_result();
?>
<div class="card mt-4" id="invoice_print">
<div class="card-body">
<h4>Invoice No: <?=htmlspecialchars($invoice_data['invoice_no'])?></h4>
<p>Date: <?=htmlspecialchars($invoice_data['created_at'])?></p>
<table class="table table-bordered">
<thead class="table-dark"><tr><th>Product</th><th>Qty</th><th>Unit</th><th class="text-end">Price</th><th class="text-end">Total</th></tr></thead>
<tbody>
<?php $grand=0; while($it=$items_res->fetch_assoc()): $line=$it['quantity']*$it['price']; $grand+=$line;?>
<tr>
<td><?=htmlspecialchars($it['name'])?></td>
<td><?= (int)$it['quantity']?></td>
<td><?=htmlspecialchars($it['unit'])?></td>
<td class="text-end"><?=number_format($it['price'],2)?></td>
<td class="text-end"><?=number_format($line,2)?></td>
</tr>
<?php endwhile;?>
</tbody>
</table>
<div class="text-end">
<p>Subtotal: <?=number_format($invoice_data['subtotal'],2)?></p>
<p>Discount: <?=number_format($invoice_data['discount'],2)?></p>
<p>Tax: <?=number_format($invoice_data['tax'],2)?></p>
<h4>Total: <?=number_format($invoice_data['total'],2)?></h4>
<p>Paid: <?=number_format($invoice_data['paid'],2)?></p>
<p>Due: <?=number_format($invoice_data['due'],2)?></p>
</div>
</div>
<div class="mt-3">
<button class="btn btn-success" onclick="printInvoice()">🖨️ Print Invoice</button>
<button class="btn btn-danger" onclick="downloadPDF('<?=htmlspecialchars($invoice_data['invoice_no'])?>')">📄 Download PDF</button>
</div>
<?php $items_stmt->close(); endif;?>

<script>
let products = <?= json_encode($prod_array, JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>;

function makeOptionsHtml(){
    let out='<option value="">-- Select product --</option>';
    products.forEach(p=>{
        out+=`<option value="${p.id}" data-price="${p.price}" data-stock="${p.stock}" data-unit="${p.unit}">${p.name} (Stock: ${p.stock} ${p.unit})</option>`;
    });
    return out;
}

function attachListenersToRow(tr){
    const qtyInput=tr.querySelector('.qty_input');
    const priceInput=tr.querySelector('.price_input');
    const select=tr.querySelector('.product_select');
    function recalc(){
        const qty=parseFloat(qtyInput.value)||0;
        const price=parseFloat(priceInput.value)||0;
        tr.querySelector('.line_total').innerText=(qty*price).toFixed(2);
        updateGrandTotal();
    }
    select.addEventListener('change',()=>{const pid=select.value;if(!pid) return; const opt=select.options[select.selectedIndex]; priceInput.value=parseFloat(opt.getAttribute('data-price')||0).toFixed(2); recalc();});
    qtyInput.addEventListener('input',recalc);
    priceInput.addEventListener('input',recalc);
    recalc();
}

function attachAllRowListeners(){document.querySelectorAll('#invoice_table tbody tr').forEach(tr=>attachListenersToRow(tr));}
attachAllRowListeners();

document.getElementById('add_row_btn').addEventListener('click',()=>{
    const tbody=document.getElementById('invoice_table').getElementsByTagName('tbody')[0];
    const tr=document.createElement('tr');
    tr.innerHTML=`<td><select name="product_id[]" class="form-select product_select" required>${makeOptionsHtml()}</select></td>
    <td><input type="number" name="quantity[]" class="form-control qty_input" min="1" value="1" required></td>
    <td><input type="number" name="price[]" class="form-control price_input" step="0.01" min="0" value="0.00" required></td>
    <td class="line_total">0.00</td>`;
    tbody.appendChild(tr); attachListenersToRow(tr);
});

document.getElementById('clear_rows_btn').addEventListener('click',()=>{
    const tbody=document.getElementById('invoice_table').getElementsByTagName('tbody')[0];
    tbody.innerHTML=`<tr><td><select name="product_id[]" class="form-select product_select" required>${makeOptionsHtml()}</select></td>
    <td><input type="number" name="quantity[]" class="form-control qty_input" min="1" value="1" required></td>
    <td><input type="number" name="price[]" class="form-control price_input" step="0.01" min="0" value="0.00" required></td>
    <td class="line_total">0.00</td></tr>`;
    attachAllRowListeners();
});

function updateGrandTotal(){
    let total=0;
    document.querySelectorAll('.line_total').forEach(td=>{total+=parseFloat(td.innerText)||0;});
    document.getElementById('grand_total').innerText=total.toFixed(2);
}

function printInvoice(){
    const element=document.getElementById('invoice_print'); if(!element)return alert('No invoice');
    const w=window.open('','','height=800,width=1000');
    w.document.write('<html><head><title>Invoice</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head><body>');
    w.document.write(element.innerHTML); w.document.write('</body></html>'); w.document.close(); w.print();
}

function downloadPDF(invoiceNo){
    const element=document.getElementById('invoice_print'); if(!element)return alert('No invoice');
    html2canvas(element).then(canvas=>{
        const imgData=canvas.toDataURL('image/png');
        const pdf=new jspdf.jsPDF('p','mm','a4');
        const pdfWidth=pdf.internal.pageSize.getWidth();
        const pdfHeight=(canvas.height*pdfWidth)/canvas.width;
        pdf.addImage(imgData,'PNG',0,0,pdfWidth,pdfHeight); pdf.save(`Invoice_${invoiceNo}.pdf`);
    });
}
</script>
<?php include("../includes/footer.php");  ?>
</body>
</html>
