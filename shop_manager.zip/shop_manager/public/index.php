<?php
//session_start();
//if(!isset($_SESSION['user_id'])) {
    //header("Location: login.php");
    //exit;
//}
include("../config/db.php");
include("../includes/header1.php");
?>
<div class="container mt-5">
    <h2>Welcome to your Shop Manager</h2>
    <p>Manage products, orders, and reports here.</p>

    <!-- Example AdSense placement -->
    <div class="mt-3 mb-3">
        <ins class="adsbygoogle"
             style="display:block"
             data-ad-client="ca-pub-XXXXXX"
             data-ad-slot="YYYYYY"
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
        <script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
    </div>
	
	<a class="btn btn-primary" href="signup.php">Register</a> 
	Or <a class="btn btn-primary" href="login.php">Login</a>
</div>
<?php include("../includes/footer.php"); ?>
