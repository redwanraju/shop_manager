<?php
// session_start();
// if(!isset($_SESSION['user_id'])) {
//     header("Location: login.php");
//     exit;
// }
include("../config/db.php");
include("../includes/header.php");
?>

<div class="container d-flex justify-content-center align-items-center" style="min-height: 80vh;">
    <div class="card shadow-lg border-0 rounded-4" style="max-width: 500px; width: 100%;">
        <div class="card-body text-center p-5">
            <!-- আইকন -->
            <div class="mb-4">
                <i class="bi bi-shop-window text-primary" style="font-size: 3rem;"></i>
            </div>

            <h2 class="fw-bold mb-3">Welcome to Shop Manager</h2>
            <p class="text-muted mb-4">
                Manage your products, orders, and reports all in one place.
            </p>

            <!-- বাটন -->
            <div class="d-grid gap-2 mb-4">
                <a class="btn btn-primary btn-lg rounded-pill" href="signup.php">
                    <i class="bi bi-person-plus-fill"></i> Register
                </a>
                <a class="btn btn-outline-primary btn-lg rounded-pill" href="login.php">
                    <i class="bi bi-box-arrow-in-right"></i> Login
                </a>
            </div>

            <!-- Example AdSense placement -->
            <div class="mt-4">
                <ins class="adsbygoogle"
                     style="display:block"
                     data-ad-client="ca-pub-XXXXXX"
                     data-ad-slot="YYYYYY"
                     data-ad-format="auto"
                     data-full-width-responsive="true"></ins>
                <script>
                     (adsbygoogle = window.adsbygoogle || []).push({});
                </script>
            </div>
        </div>
    </div>
</div>

<?php include("../includes/footer.php"); ?>