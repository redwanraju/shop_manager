<?php
session_start();
if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
include("../config/db.php");
include("../includes/header2.php");

$user_id = $_SESSION['user_id'];
$message = "";

// Form submit handling
if(isset($_POST['create_shop'])) {
    $shop_name = $conn->real_escape_string($_POST['shop_name']);
    $shop_address = $conn->real_escape_string($_POST['shop_address']);

    // Check if user already has a shop
    $check = $conn->query("SELECT id FROM shops WHERE user_id=$user_id LIMIT 1");
    if($check->num_rows > 0) {
        $message = "<div class='alert alert-warning'>আপনার আগে থেকেই একটি দোকান আছে।</div>";
    } else {
        $conn->query("INSERT INTO shops (user_id, name, address) VALUES ('$user_id','$shop_name','$shop_address')");
        $message = "<div class='alert alert-success'>Shop তৈরি হয়েছে!</div>";
    }
}
?>

<div class="container mt-5">
    <h2>Create Your Shop</h2>

    <?= $message; ?>

    <form method="POST" class="mt-3">
        <div class="mb-3">
            <label for="shop_name" class="form-label">Shop Name</label>
            <input type="text" name="shop_name" id="shop_name" class="form-control" placeholder="Shop Name" required>
        </div>
        <div class="mb-3">
            <label for="shop_address" class="form-label">Address</label>
            <input type="text" name="shop_address" id="shop_address" class="form-control" placeholder="Shop Address" required>
        </div>
        <button type="submit" name="create_shop" class="btn btn-primary">Create Shop</button>
    </form>
</div>

<?php include("../includes/footer.php"); ?>
