<?php
include("../config/db.php");
require_once '../includes/auth.php';
include("../includes/header2.php");
start_secure_session();
$csrf = generate_csrf_token();
// form: <input type="hidden" name="csrf_token" value="<?=htmlspecialchars($csrf)?>

<?php

if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}



$user_id = intval($_SESSION['user_id']);
$message = "";

// CSRF token
if(!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(24));
}
$csrf_token = $_SESSION['csrf_token'];

// Form submit handling
if(isset($_POST['create_shop'])) {
    // CSRF validation
    if(!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $message = "<div class='alert alert-danger'>Invalid request.</div>";
    } else {
        $shop_name = trim($_POST['shop_name'] ?? '');
        $shop_address = trim($_POST['shop_address'] ?? '');

        if($shop_name === "" || $shop_address === "") {
            $message = "<div class='alert alert-warning'>সব ফিল্ড পূরণ করুন।</div>";
        } else {
            // Check if user already has a shop
            $stmt = $conn->prepare("SELECT id FROM shops WHERE user_id = ? LIMIT 1");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $stmt->store_result();

            if($stmt->num_rows > 0) {
                $message = "<div class='alert alert-warning'>আপনার আগে থেকেই একটি দোকান আছে।</div>";
            } else {
                // Insert shop safely
                $insert_stmt = $conn->prepare("INSERT INTO shops (user_id, name, address) VALUES (?, ?, ?)");
                $insert_stmt->bind_param("iss", $user_id, $shop_name, $shop_address);
                if($insert_stmt->execute()) {
                    $message = "<div class='alert alert-success'>Shop তৈরি হয়েছে!</div>";
                    // Regenerate CSRF token
                    $_SESSION['csrf_token'] = bin2hex(random_bytes(24));
                    $csrf_token = $_SESSION['csrf_token'];
                } else {
                    $message = "<div class='alert alert-danger'>Error: ".$conn->error."</div>";
                }
                $insert_stmt->close();
            }
            $stmt->close();
        }
    }
}
?>

<div class="container mt-5">
    <h2>Create Your Shop</h2>

    <?= $message; ?>

    <form method="POST" class="mt-3">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">
        <div class="mb-3">
            <label for="shop_name" class="form-label">Shop Name</label>
            <input type="text" name="shop_name" id="shop_name" class="form-control" placeholder="Shop Name" required>
        </div>
        <div class="mb-3">
            <label for="shop_address" class="form-label">Address</label>
            <input type="text" name="shop_address" id="shop_address" class="form-control" placeholder="Shop Address" required>
        </div>
        <button type="submit" name="create_shop" class="btn btn-primary">Create Shop</button>
    </form>
</div>

<?php include("../includes/footer.php"); ?>
