<?php
session_start();
include("../includes/header.php");
include("../config/db.php");
require_once '../includes/auth.php';
start_secure_session();

if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// DB থেকে ড্যাশবোর্ডের ডেটা (আপনার মূল কোড হুবহু)
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// আজকের মোট বিক্রি
$stmt = $conn->prepare("SELECT SUM(total) as total_today FROM invoices WHERE user_id=? AND DATE(created_at)=CURDATE()");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$total_today = $stmt->get_result()->fetch_assoc()['total_today'] ?? 0;
$stmt->close();

// এ মাসের মোট বিক্রি
$stmt = $conn->prepare("SELECT SUM(total) as total_month FROM invoices WHERE user_id=? AND MONTH(created_at)=MONTH(CURDATE()) AND YEAR(created_at)=YEAR(CURDATE())");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$total_month = $stmt->get_result()->fetch_assoc()['total_month'] ?? 0;
$stmt->close();

// আজকের নগদ কালেকশন
$stmt = $conn->prepare("SELECT SUM(paid) as cash_today FROM invoices WHERE user_id=? AND DATE(created_at)=CURDATE()");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$cash_today = $stmt->get_result()->fetch_assoc()['cash_today'] ?? 0;
$stmt->close();

// আজকের ডিউ
$stmt = $conn->prepare("SELECT SUM(due) as due_today FROM invoices WHERE user_id=? AND DATE(created_at)=CURDATE()");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$due_today = $stmt->get_result()->fetch_assoc()['due_today'] ?? 0;
$stmt->close();

// মোট ইনভয়েস
$stmt = $conn->prepare("SELECT COUNT(*) as total_invoice FROM invoices WHERE user_id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$total_invoice = $stmt->get_result()->fetch_assoc()['total_invoice'] ?? 0;
$stmt->close();

// মোট পণ্য
$stmt = $conn->prepare("SELECT COUNT(*) as total_products FROM products WHERE user_id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$total_products = $stmt->get_result()->fetch_assoc()['total_products'] ?? 0;
$stmt->close();

// লো স্টক
$stmt = $conn->prepare("SELECT COUNT(*) as low_stock FROM products WHERE user_id=? AND stock <= min_stock");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$low_stock = $stmt->get_result()->fetch_assoc()['low_stock'] ?? 0;
$stmt->close();

// টোটাল বকেয়া
$stmt = $conn->prepare("SELECT SUM(due) as total_due FROM invoices WHERE user_id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$total_due = $stmt->get_result()->fetch_assoc()['total_due'] ?? 0;
$stmt->close();

// ইউজারের নাম
$user_name = $_SESSION['user_name'] ?? '';
if ($user_name === '') {
    $stmt = $conn->prepare("SELECT name FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $res = $stmt->get_result();
    if($res->num_rows > 0){
        $row = $res->fetch_assoc();
        $user_name = $row['name'];
        $_SESSION['user_name'] = $user_name;
    } else {
        $user_name = "User";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<style>
:root {
    --bg-light: #f4f6f9;
    --bg-dark: #1e1e2f;
    --text-light: #ffffff;
    --text-dark: #212529;
}

body {
    font-family: 'Segoe UI', sans-serif;
    background-color: var(--bg-light);
    color: var(--text-dark);
    transition: background-color 0.3s, color 0.3s;
}

.dark-mode {
    background-color: var(--bg-dark);
    color: var(--text-light);
}

.dashboard-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
}
.dashboard-header h2 { font-weight: 700; }
.logo { font-size: 1.8rem; font-weight: 700; color: #0d6efd; }

.card {
    border-radius: 1rem;
    box-shadow: 0 4px 15px rgba(0,0,0,0.08);
    transition: transform 0.2s, box-shadow 0.2s;
}
.card:hover { transform: translateY(-5px); box-shadow: 0 10px 25px rgba(0,0,0,0.15); }
.card .card-body { text-align: center; }
.card .card-title { font-size: 1.1rem; font-weight: 600; margin-bottom: 10px; }
.card .card-text { font-size: 1.6rem; font-weight: 700; }
.card i { font-size: 2rem; margin-bottom: 10px; color: rgba(255,255,255,0.8); }

.quick-actions { margin-top: 30px; display: flex; flex-wrap: wrap; gap: 15px; }
.quick-actions a {
    flex: 1 1 200px; text-align: center; border-radius: 0.6rem;
    padding: 0.75rem 1rem; font-weight: 600; transition: transform 0.2s;
}
.quick-actions a:hover { transform: translateY(-3px); }

.mode-toggle {
    cursor: pointer;
    font-size: 1.2rem;
    padding: 0.3rem 0.6rem;
    border-radius: 0.5rem;
    background-color: #0d6efd;
    color: white;
    transition: background-color 0.2s;
}
.mode-toggle:hover { background-color: #0b5ed7; }
</style>
</head>
<body class="container py-4">

<div class="d-flex justify-content-between align-items-center mb-3">
    <div class="logo"><i class="fa-solid fa-store"></i> MyDashboard</div>
    <div>
        <span class="mode-toggle" id="modeToggle"><i class="fa-solid fa-moon"></i> Dark Mode</span>
		
    </div>
	
</div>

<h2>👋 Welcome, <?= htmlspecialchars($user_name) ?>!</h2>
<p class="text-muted mb-4">আপনার ড্যাশবোর্ডে স্বাগতম। এখানে আপনার ইনভয়েস, পণ্য এবং অন্যান্য তথ্য দেখতে পারবেন।</p>

<div class="row g-4">

<!-- Dashboard Cards -->
<?php
$cards = [
    ['title'=>"Today's Sales",'value'=>$total_today,'icon'=>'fa-coins','bg'=>'bg-primary'],
    ['title'=>"This Month's Sales",'value'=>$total_month,'icon'=>'fa-calendar-days','bg'=>'bg-success'],
    ['title'=>"Today's Cash",'value'=>$cash_today,'icon'=>'fa-wallet','bg'=>'bg-warning'],
    ['title'=>"Today's Due",'value'=>$due_today,'icon'=>'fa-triangle-exclamation','bg'=>'bg-danger'],
    ['title'=>"Total Invoices",'value'=>$total_invoice,'icon'=>'fa-file-invoice','bg'=>'bg-info'],
    ['title'=>"Total Products",'value'=>$total_products,'icon'=>'fa-boxes-stacked','bg'=>'bg-secondary'],
    ['title'=>"Low Stock",'value'=>$low_stock,'icon'=>'fa-exclamation-circle','bg'=>'bg-dark'],
    ['title'=>"Total Due",'value'=>$total_due,'icon'=>'fa-money-bill-wave','bg'=>'bg-secondary'],
];

foreach($cards as $c): ?>
<div class="col-md-3 col-sm-6">
    <div class="card <?= $c['bg'] ?> text-white">
        <div class="card-body">
            <i class="fa-solid <?= $c['icon'] ?>"></i>
            <h5 class="card-title"><?= $c['title'] ?></h5>
            <p class="card-text"><?= is_numeric($c['value']) ? number_format($c['value'],2) : $c['value'] ?></p>
        </div>
    </div>
</div>
<?php endforeach; ?>

</div>



<script>
const toggle = document.getElementById('modeToggle');
toggle.addEventListener('click', ()=>{
    document.body.classList.toggle('dark-mode');
    toggle.innerHTML = document.body.classList.contains('dark-mode') ? '<i class="fa-solid fa-sun"></i> Light Mode' : '<i class="fa-solid fa-moon"></i> Dark Mode';
});
</script>

</body>
</html>