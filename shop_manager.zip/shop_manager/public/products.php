<?php
// Secure session + auth
session_start();
include("../includes/header.php");
include("../config/db.php");
require_once '../includes/auth.php';
start_secure_session();

if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// CSRF Token তৈরি
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['csrf_token'];

// ইউজার আইডি সেশন থেকে
$user_id = $_SESSION['user_id'] ?? 0;

// ---------------- Add Product ----------------
if (isset($_POST['add_product'])) {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        die("❌ Invalid form submission");
    }

    $name = trim($_POST['name']);
    $stock = intval($_POST['stock']);
    $unit = trim($_POST['unit']);
    $price = floatval($_POST['price']);
    $min_stock = intval($_POST['min_stock']);

    $stmt = $conn->prepare("INSERT INTO products (name, stock, unit, price, min_stock, user_id) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sisdis", $name, $stock, $unit, $price, $min_stock, $user_id);

    if ($stmt->execute()) {
        $msg = "✅ Product added successfully!";
    } else {
        $error = "❌ Error: " . $stmt->error;
    }
    $stmt->close();
}

// ---------------- Edit / Update Product ----------------
if (isset($_POST['edit_product'])) {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        die("❌ Invalid form submission");
    }

    $id = intval($_POST['id']);
    $name = trim($_POST['name']);
    $stock = intval($_POST['stock']);
    $unit = trim($_POST['unit']);
    $price = floatval($_POST['price']);
    $min_stock = intval($_POST['min_stock']);

    $stmt = $conn->prepare("UPDATE products 
        SET name=?, stock=?, unit=?, price=?, min_stock=? 
        WHERE id=? AND user_id=?");
    $stmt->bind_param("sisdiis", $name, $stock, $unit, $price, $min_stock, $id, $user_id);

    if ($stmt->execute()) {
        $msg = "✅ Product updated successfully!";
    } else {
        $error = "❌ Error: " . $stmt->error;
    }
    $stmt->close();
}

// ---------------- Delete Product ----------------
if (isset($_GET['delete_id']) && isset($_GET['confirm']) && $_GET['confirm'] === 'yes') {
    $delete_id = intval($_GET['delete_id']);
    $stmt = $conn->prepare("DELETE FROM products WHERE id=? AND user_id=?");
    $stmt->bind_param("ii", $delete_id, $user_id);
    $stmt->execute();
    $stmt->close();
    $msg = "✅ Product deleted successfully!";
}

// ---------------- Fetch products ----------------
$stmt = $conn->prepare("SELECT * FROM products WHERE user_id=? ORDER BY id DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$products = $stmt->get_result();

// Fetch product for edit
$edit_product = null;
if (isset($_GET['edit_id'])) {
    $id = intval($_GET['edit_id']);
    $stmt = $conn->prepare("SELECT * FROM products WHERE id=? AND user_id=?");
    $stmt->bind_param("ii", $id, $user_id);
    $stmt->execute();
    $edit_product = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Products</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script>
        function confirmDelete(id) {
            if (confirm("⚠️ Are you sure you want to delete this product?")) {
                window.location.href = "products.php?delete_id=" + id + "&confirm=yes";
            }
        }
    </script>
</head>
<body class="container mt-5">
<h2>🛒 Products</h2>

<?php if (!empty($msg)) echo "<div class='alert alert-success'>$msg</div>"; ?>
<?php if (!empty($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>

<!-- Add/Edit Form -->
<div class="card p-3 mb-4">
<form method="POST">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf) ?>">
    <?php if($edit_product): ?>
        <input type="hidden" name="id" value="<?= $edit_product['id'] ?>">
    <?php endif; ?>
    <div class="row mb-2">
        <div class="col-md-3">
            <input type="text" name="name" class="form-control" placeholder="Product Name" required value="<?= htmlspecialchars($edit_product['name'] ?? '') ?>">
        </div>
        <div class="col-md-2">
            <input type="number" name="stock" class="form-control" placeholder="Stock" min="0" required value="<?= htmlspecialchars($edit_product['stock'] ?? '') ?>">
        </div>
        <div class="col-md-2">
            <input type="text" name="unit" class="form-control" placeholder="Unit" required value="<?= htmlspecialchars($edit_product['unit'] ?? '') ?>">
        </div>
        <div class="col-md-2">
            <input type="number" name="price" class="form-control" placeholder="Price" step="0.01" min="0" required value="<?= htmlspecialchars($edit_product['price'] ?? '') ?>">
        </div>
        <div class="col-md-2">
            <input type="number" name="min_stock" class="form-control" placeholder="Min Stock" min="0" required value="<?= htmlspecialchars($edit_product['min_stock'] ?? '') ?>">
        </div>
        <div class="col-md-1">
            <button type="submit" name="<?= $edit_product ? 'edit_product' : 'add_product' ?>" class="btn btn-primary"><?= $edit_product ? 'Update' : 'Add' ?></button>
        </div>
    </div>
</form>
</div>

<!-- Product List -->
<table class="table table-bordered">
    <thead>
        <tr><th>Name</th><th>Stock</th><th>Unit</th><th>Price</th><th>Min Stock</th><th>Actions</th></tr>
    </thead>
    <tbody>
        <?php while($row=$products->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['name']) ?></td>
            <td><?= (int)$row['stock'] ?></td>
            <td><?= htmlspecialchars($row['unit']) ?></td>
            <td><?= number_format($row['price'],2) ?></td>
            <td><?= (int)$row['min_stock'] ?></td>
            <td>
                <a href="products.php?edit_id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                <button onclick="confirmDelete(<?= $row['id'] ?>)" class="btn btn-danger btn-sm">Delete</button>
            </td>
			
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>
    
      
       <div class="text-end mb-3">
<a href="dashboard.php" class="btn btn-primary">Dashboard</a>
<a href="invoice.php" class="btn btn-primary">Create Invoice</a>
</div>
        
    <?php include("../includes/footer.php");  ?>

    
</body>
</html>
