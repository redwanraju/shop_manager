<?php
// ডাটাবেজ কানেকশন
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shop_manager";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: ".$conn->connect_error);

include("../includes/header2.php");

// Check if shops table has any shop
$shop_check = $conn->query("SELECT id FROM shops LIMIT 1");
if($shop_check->num_rows > 0){
    $shop_row = $shop_check->fetch_assoc();
    $shop_id = $shop_row['id'];
} else {
    $conn->query("INSERT INTO shops (name) VALUES ('My Default Shop')");
    $shop_id = $conn->insert_id;
}

// ---------------- Add Product ----------------
if(isset($_POST['add_product'])){
    $name = $conn->real_escape_string($_POST['name']);
    $stock = intval($_POST['stock']);
    $unit = $conn->real_escape_string($_POST['unit']);
    $price = floatval($_POST['price']);
    $min_stock = intval($_POST['min_stock']);

    $sql = "INSERT INTO products (name, stock, unit, price, min_stock, shop_id)
            VALUES ('$name', $stock, '$unit', $price, $min_stock, $shop_id)";

    if($conn->query($sql)) $msg = "Product added successfully!";
    else $error = "Error: ".$conn->error;
}

// ---------------- Edit / Update Product ----------------
if(isset($_POST['edit_product'])){
    $id = intval($_POST['id']);
    $name = $conn->real_escape_string($_POST['name']);
    $stock = intval($_POST['stock']);
    $unit = $conn->real_escape_string($_POST['unit']);
    $price = floatval($_POST['price']);
    $min_stock = intval($_POST['min_stock']);

    $sql = "UPDATE products SET name='$name', stock=$stock, unit='$unit', price=$price, min_stock=$min_stock
            WHERE id=$id AND shop_id=$shop_id";

    if($conn->query($sql)) $msg = "Product updated successfully!";
    else $error = "Error: ".$conn->error;
}

// ---------------- Delete Product ----------------
if(isset($_GET['delete_id'])){
    $delete_id = intval($_GET['delete_id']);

    // Check usage in invoices
    $res = $conn->query("SELECT COUNT(*) as cnt FROM invoice_items WHERE product_id=$delete_id");
    $count = $res->fetch_assoc()['cnt'];

    if(isset($_GET['confirm']) && $_GET['confirm']=='yes'){
        $conn->query("DELETE FROM products WHERE id=$delete_id AND shop_id=$shop_id");
        $msg = "Product deleted successfully!";
    } else {
        if($count>0) $warn = "Warning: This product is used in $count invoices. It will be deleted along with related items. Continue?";
        else $warn = "Do you really want to delete this product?";

        echo "<script>
            if(confirm('$warn')){
                window.location.href='products.php?delete_id=$delete_id&confirm=yes';
            } else {
                window.location.href='products.php';
            }
        </script>";
    }
}

// ---------------- Fetch products ----------------
$products = $conn->query("SELECT * FROM products WHERE shop_id=$shop_id");

// Fetch product for edit
$edit_product = null;
if(isset($_GET['edit_id'])){
    $id = intval($_GET['edit_id']);
    $res = $conn->query("SELECT * FROM products WHERE id=$id AND shop_id=$shop_id");
    $edit_product = $res->fetch_assoc();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Products</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="container mt-5">
<h2>🛒 Products</h2>

<?php if(!empty($msg)) echo "<div class='alert alert-success'>$msg</div>"; ?>
<?php if(!empty($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>

<!-- Add/Edit Form -->
<div class="card p-3 mb-4">
<form method="POST">
    <?php if($edit_product): ?>
        <input type="hidden" name="id" value="<?= $edit_product['id'] ?>">
    <?php endif; ?>
    <div class="row mb-2">
        <div class="col-md-3">
            <input type="text" name="name" class="form-control" placeholder="Product Name" required value="<?= $edit_product['name'] ?? '' ?>">
        </div>
        <div class="col-md-2">
            <input type="number" name="stock" class="form-control" placeholder="Stock" min="0" required value="<?= $edit_product['stock'] ?? '' ?>">
        </div>
        <div class="col-md-2">
            <input type="text" name="unit" class="form-control" placeholder="Unit" required value="<?= $edit_product['unit'] ?? '' ?>">
        </div>
        <div class="col-md-2">
            <input type="number" name="price" class="form-control" placeholder="Price" step="0.01" min="0" required value="<?= $edit_product['price'] ?? '' ?>">
        </div>
        <div class="col-md-2">
            <input type="number" name="min_stock" class="form-control" placeholder="Min Stock" min="0" required value="<?= $edit_product['min_stock'] ?? '' ?>">
        </div>
        <div class="col-md-1">
            <button type="submit" name="<?= $edit_product ? 'edit_product' : 'add_product' ?>" class="btn btn-primary"><?= $edit_product ? 'Update' : 'Add' ?></button>
        </div>
    </div>
</form>
</div>

<!-- Product List -->
<table class="table table-bordered">
    <thead>
        <tr><th>Name</th><th>Stock</th><th>Unit</th><th>Price</th><th>Min Stock</th><th>Actions</th></tr>
    </thead>
    <tbody>
        <?php while($row=$products->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['name']) ?></td>
            <td><?= $row['stock'] ?></td>
            <td><?= htmlspecialchars($row['unit']) ?></td>
            <td><?= number_format($row['price'],2) ?></td>
            <td><?= $row['min_stock'] ?></td>
            <td>
                <a href="products.php?edit_id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                <a href="products.php?delete_id=<?= $row['id'] ?>" class="btn btn-danger btn-sm">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>

</body>
</html>
