<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Access Denied</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body {
    background: #f8d7da;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
}
.card {
    padding: 30px;
    border-radius: 1rem;
    box-shadow: 0 5px 20px rgba(0,0,0,0.1);
    text-align: center;
    max-width: 500px;
    background-color: #fff0f0;
}
.card h1 {
    font-size: 3rem;
    color: #721c24;
}
.card p {
    font-size: 1.2rem;
    margin-bottom: 20px;
}
.btn-home {
    background-color: #721c24;
    color: #fff;
    border-radius: 0.5rem;
    padding: 10px 20px;
    text-decoration: none;
    transition: 0.3s;
}
.btn-home:hover {
    background-color: #501217;
    color: #fff;
}
</style>
</head>
<body>
<div class="card">
    <h1><i class="bi bi-exclamation-triangle-fill"></i> Access Denied</h1>
    <p>আপনার এই পেজটি দেখার অনুমতি নেই।</p>
    <a class="btn-home" href="dashboard.php">Go Back to Dashboard</a>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Bootstrap Icons -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</body>
</html>