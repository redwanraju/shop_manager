<?php
session_start();
include("../config/db.php");
require_once '../includes/auth.php';
start_secure_session();

// Check if admin (assuming admin_id = 1)
if(!isset($_SESSION['user_id']) || $_SESSION['user_id'] != 1){
    header("Location: access_denied.php");
    exit;
}

// Handle Access toggle with Trial Start
if(isset($_GET['toggle']) && isset($_GET['user'])){
    $uid = intval($_GET['user']);

    // Get current access and trial_start
    $stmt = $conn->prepare("SELECT access, trial_start FROM users WHERE id=?");
    $stmt->bind_param("i",$uid);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    // Toggle access
    $new_access = $res['access']=='on' ? 'off' : 'on';

    // If turning on for first time, set trial_start
    $trial_start = $res['trial_start'];
    if($new_access=='on' && !$trial_start){
        $trial_start = date('Y-m-d H:i:s');
    }

    // Update user
    $stmt = $conn->prepare("UPDATE users SET access=?, trial_start=? WHERE id=?");
    $stmt->bind_param("ssi",$new_access,$trial_start,$uid);
    $stmt->execute();
    $stmt->close();

    header("Location: admin_users.php");
    exit;
}

// Fetch all users
$result = $conn->query("SELECT id, name, email, mobile, access, trial_start FROM users ORDER BY id DESC");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Admin Panel - User Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; }
        .container { margin-top:50px; }
        .access-btn { width:100px; }
    </style>
</head>
<body>
<div class="container">
    <h2>Admin Panel - User Management</h2>
    <table class="table table-bordered table-hover mt-3">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Mobile</th>
                <th>Access</th>
                <th>Trial Start</th>
                <th>Trial End</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while($user = $result->fetch_assoc()): 
                $trial_end = $user['trial_start'] ? date('Y-m-d H:i:s', strtotime($user['trial_start'].' +7 days')) : '';
            ?>
            <tr>
                <td><?= $user['id'] ?></td>
                <td><?= htmlspecialchars($user['name']) ?></td>
                <td><?= htmlspecialchars($user['email']) ?></td>
                <td><?= htmlspecialchars($user['mobile']) ?></td>
                <td><?= $user['access'] ?></td>
                <td><?= $user['trial_start'] ?></td>
                <td><?= $trial_end ?></td>
                <td>
                    <a class="btn btn-sm btn-<?= $user['access']=='on'?'danger':'success' ?> access-btn"
                       href="?toggle=1&user=<?= $user['id'] ?>">
                       <?= $user['access']=='on'?'Turn Off':'Turn On' ?>
                    </a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
    <a href="../public/dashboard.php" class="btn btn-dark mt-3">Back to Dashboard</a>
</div>
</body>
</html>
