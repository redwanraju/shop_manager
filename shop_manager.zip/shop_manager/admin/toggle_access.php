<?php
session_start();
include("../config/db.php");

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['user_id'],$_POST['access'])){
    $stmt = $conn->prepare("UPDATE users SET access=? WHERE id=?");
    $stmt->bind_param("si", $_POST['access'], $_POST['user_id']);
    $stmt->execute();
    $stmt->close();
    echo "success";
}
?>