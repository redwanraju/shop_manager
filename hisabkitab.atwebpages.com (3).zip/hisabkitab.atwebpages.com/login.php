<?php
require_once "db.php";
require_once "auth.php";
start_secure_session();

// CSRF Token
$csrf = generate_csrf_token();

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
        $errors[] = "Invalid form submission!";
    } else {
        $action = $_POST['action'] ?? '';

        // ================= Signup =================
        if ($action === 'signup') {
            $name = trim($_POST['name'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $mobile = trim($_POST['mobile'] ?? '');
            $password = $_POST['password'] ?? '';
            $confirm = $_POST['confirm_password'] ?? '';
            $whatsapp = trim($_POST['whatsapp'] ?? '');
            $facebook = trim($_POST['facebook'] ?? '');

            // Validate
            if ($name === '' || $email === '' || $mobile === '' || $password === '' || $confirm === '') {
                $errors[] = "সব ঘর পূরণ করুন।";
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors[] = "সঠিক ইমেইল দিন।";
            } elseif ($password !== $confirm) {
                $errors[] = "পাসওয়ার্ড মিলছে না।";
            } else {
                // Check existing email
                $stmt = $conn->prepare("SELECT id FROM users WHERE email=? LIMIT 1");
                $stmt->bind_param("s", $email);
                $stmt->execute();
                $resCheck = $stmt->get_result();
                $stmt->close();

                if ($resCheck->num_rows > 0) {
                    $errors[] = "ইমেইলটি ইতিমধ্যে রেজিস্টার্ড।";
                } else {
                    $password_hash = password_hash($password, PASSWORD_DEFAULT);
                    $role = 'user';
                    $trial_start = date("Y-m-d H:i:s");
                    $access = 'on';

                    // Logo upload
                    $logo_path = null;
                    if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
                        $ext = pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION);
                        $allowed = ['jpg','jpeg','png','webp'];
                        if (in_array(strtolower($ext), $allowed)) {
                            $upload_dir = __DIR__ . "/uploads/logos/";
                            if(!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
                            $new_name = "logo_".time().".".$ext;
                            $dest = $upload_dir.$new_name;
                            if(move_uploaded_file($_FILES['logo']['tmp_name'], $dest)){
                                $logo_path = "uploads/logos/".$new_name;
                            }
                        }
                    }

                    // Insert user
                    if (empty($errors)) {
                        $insert = $conn->prepare("
                            INSERT INTO users 
                            (name,email,mobile,role,trial_start,password_hash,access,logo_path,whatsapp,facebook,created_at) 
                            VALUES (?,?,?,?,?,?,?,?,?,?,NOW())
                        ");
                        $insert->bind_param(
                            "ssssssssss",
                            $name, $email, $mobile, $role, $trial_start, $password_hash, $access, $logo_path, $whatsapp, $facebook
                        );
                        if ($insert->execute()) {
                            $success = "রেজিস্ট্রেশন সফল। এখন লগইন করুন।";
                            $_POST = [];
                            $_SESSION['csrf_token'] = bin2hex(random_bytes(24));
                        } else {
                            $errors[] = "রেজিস্ট্রেশন ব্যর্থ।";
                        }
                        $insert->close();
                    }
                }
            }
        }

        // ================= Login =================
// ================= Login =================
if ($action === 'login') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $errors[] = "সব ঘর পূরণ করুন।";
    } else {
        $stmt = $conn->prepare("SELECT id,name,password_hash,role,access,trial_start FROM users WHERE email=? LIMIT 1");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($res && password_verify($password, $res['password_hash'])) {
            $current_access = $res['access'];
            $trial_ok = is_trial_active($res['role'], $res['trial_start']);

            // Admin সবসময় লগইন করতে পারবে
            if ($res['role'] === 'admin') {
                $allow_login = true;
            } else {
                // Access off → লগইন না হবে
                // Access on → ট্রায়াল শেষ হলেও লগইন সম্ভব
                $allow_login = ($current_access === 'on');
            }

            if (!$allow_login) {
                if ($current_access === 'off') {
                    $errors[] = "আপনার একাউন্টে access বন্ধ।";
                } elseif (!$trial_ok) {
                    $errors[] = "আপনার ট্রায়াল শেষ হয়েছে।";
                }
            }

            if (empty($errors)) {
                $_SESSION['user_id'] = $res['id'];
                $_SESSION['user_name'] = $res['name'];
                $_SESSION['user_role'] = $res['role'];
                $_SESSION['access'] = $current_access; // সর্বশেষ DB access
                header("Location: dashboard.php");
                exit;
            }
        } else {
            $errors[] = "ইমেইল বা পাসওয়ার্ড ভুল।";
        }
    }
}
    }
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login & Signup | MyERP</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
body { background: #f0f2f5; }
.card { border-radius: 1rem; }
</style>
</head>
<body>
<div class="container mt-5">
<div class="row justify-content-center">
<div class="col-md-6">
<div class="card shadow">
<div class="card-body p-4">
<h3 class="text-center mb-4"><i class="bi bi-person-circle me-2"></i>Login / Signup</h3>

<?php if(!empty($success)): ?>
    <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>
<?php if(!empty($errors)): ?>
    <div class="alert alert-danger">
        <?php foreach($errors as $e) echo htmlspecialchars($e)."<br>"; ?>
    </div>
<?php endif; ?>

<ul class="nav nav-tabs mb-3" id="authTab" role="tablist">
<li class="nav-item"><button class="nav-link active" id="login-tab" data-bs-toggle="tab" data-bs-target="#login" type="button">Login</button></li>
<li class="nav-item"><button class="nav-link" id="signup-tab" data-bs-toggle="tab" data-bs-target="#signup" type="button">Signup</button></li>
</ul>

<div class="tab-content">
<!-- Login -->
<div class="tab-pane fade show active" id="login">
<form method="POST">
<input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf) ?>">
<input type="hidden" name="action" value="login">
<div class="mb-3">
<label class="form-label">Email</label>
<input type="email" name="email" class="form-control" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
</div>
<div class="mb-3">
<label class="form-label">Password</label>
<input type="password" name="password" class="form-control" required>
</div>
<button type="submit" class="btn btn-primary w-100">Login</button>
</form>
</div>

<!-- Signup -->
<div class="tab-pane fade" id="signup">
<form method="POST" enctype="multipart/form-data">
<input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf) ?>">
<input type="hidden" name="action" value="signup">

<div class="mb-3">
<label class="form-label">Name / Shop Name</label>
<input type="text" name="name" class="form-control" required value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">
</div>

<div class="mb-3">
<label class="form-label">Email</label>
<input type="email" name="email" class="form-control" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
</div>

<div class="mb-3">
<label class="form-label">Mobile</label>
<input type="text" name="mobile" class="form-control" required value="<?= htmlspecialchars($_POST['mobile'] ?? '') ?>">
</div>

<div class="mb-3">
<label class="form-label">Password</label>
<input type="password" name="password" class="form-control" required>
</div>

<div class="mb-3">
<label class="form-label">Confirm Password</label>
<input type="password" name="confirm_password" class="form-control" required>
</div>

<div class="mb-3">
<label class="form-label">Shop Logo (Optional)</label>
<input type="file" name="logo" class="form-control" accept=".jpg,.jpeg,.png,.webp">
</div>

<div class="mb-3">
<label class="form-label">WhatsApp Number</label>
<input type="text" name="whatsapp" class="form-control" value="<?= htmlspecialchars($_POST['whatsapp'] ?? '') ?>">
</div>

<div class="mb-3">
<label class="form-label">Facebook Link</label>
<input type="text" name="facebook" class="form-control" value="<?= htmlspecialchars($_POST['facebook'] ?? '') ?>">
</div>

<button type="submit" class="btn btn-success w-100">Signup</button>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
