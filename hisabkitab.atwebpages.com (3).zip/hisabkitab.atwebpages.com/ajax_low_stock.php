<?php
session_start();
include("db.php");
require_once 'auth.php';
start_secure_session();
//$user_id = $_SESSION['user_id'] ?? 0;
if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$user_id = $_SESSION['user_id'];


$low_products = [];
$stmt = $conn->prepare("SELECT name, stock, min_stock FROM products WHERE user_id=? AND stock<=min_stock ORDER BY stock ASC LIMIT 5");
$stmt->bind_param("i",$user_id);
$stmt->execute();
$low_products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
  </head>
  <body>
    <div class="card">
  <div class="card-header bg-danger text-white">
    <h5 class="card-title">Low Stock Alerts</h5>
  </div>
  <div class="card-body table-responsive">
    <table class="table table-hover text-center">
      <thead><tr><th>Product</th><th>Stock</th><th>Min Stock</th></tr></thead>
      <tbody>
        <?php if(empty($low_products)): ?>
        <tr><td colspan="3">No low stock products ✅</td></tr>
        <?php else: foreach($low_products as $p): ?>
        <tr>
          <td><?=htmlspecialchars($p['name'])?></td>
          <td><?=$p['stock']?></td>
          <td><?=$p['min_stock']?></td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
  </body>
</html>














