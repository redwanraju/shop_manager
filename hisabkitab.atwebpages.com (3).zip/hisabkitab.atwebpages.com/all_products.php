<?php
session_start();
include("db.php");
require_once 'auth.php';
start_secure_session();

if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch all products
$products = [];
$stmt = $conn->prepare("SELECT * FROM products WHERE user_id=? ORDER BY name ASC");
$stmt->bind_param("i",$user_id);
$stmt->execute();
$res = $stmt->get_result();
while($row = $res->fetch_assoc()) $products[] = $row;
$stmt->close();

// Count total products
$stmt = $conn->prepare("SELECT COUNT(*) AS total FROM products WHERE user_id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$res = $stmt->get_result();
$row = $res->fetch_assoc();
$total_products = $row['total'];
$stmt->close();

// Today's purchase total
$stmt = $conn->prepare("SELECT SUM(stock*price) AS today_total FROM products WHERE user_id=? AND DATE(created_at)=CURDATE()");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$res = $stmt->get_result();
$row = $res->fetch_assoc();
$today_total = $row['today_total'] ?? 0;
$stmt->close();

// Previous purchase total
$stmt = $conn->prepare("SELECT SUM(stock*price) AS previous_total FROM products WHERE user_id=? AND DATE(created_at)<CURDATE()");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$res = $stmt->get_result();
$row = $res->fetch_assoc();
$previous_total = $row['previous_total'] ?? 0;
$stmt->close();

// Total purchase (Today + Previous)
$total_purchase = $today_total + $previous_total;

// ✅ Pagination setup (added at the end of PHP section)
$limit = 10; // প্রতি পেজে ১০টি প্রোডাক্ট দেখাবে
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $limit;

// পুনরায় products query pagination সহ
$stmt = $conn->prepare("SELECT * FROM products WHERE user_id=? ORDER BY name ASC LIMIT ?,?");
$stmt->bind_param("iii", $user_id, $offset, $limit);
$stmt->execute();
$res = $stmt->get_result();
$products = [];
while($row = $res->fetch_assoc()) $products[] = $row;
$stmt->close();

// মোট প্রোডাক্ট সংখ্যা বের করা
$total_pages = ceil($total_products / $limit);


?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>All Products</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="container py-4">


<div class="mb-3">
    <input type="text" id="product_search" class="form-control form-control-lg" placeholder="Search by name or unit...">
</div>

<!-- Today's / Previous / Total purchase -->
<div class="d-flex gap-3 flex-wrap mb-3">
    <div class="stats-box flex-fill text-center text-info">
        <h6>📅 Today's Purchase</h6>
        <h5>৳ <?= number_format($today_total,2) ?></h5>
    </div>
    <div class="stats-box flex-fill text-center text-secondary">
        <h6>📦 Previous Purchases</h6>
        <h5>৳ <?= number_format($previous_total,2) ?></h5>
    </div>
    <div class="stats-box flex-fill text-center text-success">
        <h6>💰 Total Purchase</h6>
        <h5>৳ <?= number_format($total_purchase,2) ?></h5>
    </div>
</div>

<button class="btn btn-primary btn-lg mb-3 btn-custom" data-bs-toggle="modal" data-bs-target="#addProductModal">➕ Add New Product</button>

<div class="table-responsive">
<table class="table table-hover table-bordered align-middle" id="products_table">
<thead class="table-dark text-center">
<tr>
<th>Name</th>
<th>Stock</th>
<th>Price (৳)</th>
<th>Unit</th>
<th>min stock</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<?php foreach($products as $p): ?>
<tr>
<td><?=htmlspecialchars($p['name'])?></td>
<td contenteditable="true" class="editable_stock text-center" data-id="<?=$p['id']?>"><?= (int)$p['stock'] ?></td>
<td contenteditable="true" class="editable_price text-end" data-id="<?=$p['id']?>"><?= number_format($p['price'],2) ?></td>
<td contenteditable="true" class="editable_unit text-center" data-id="<?=$p['id']?>"><?= htmlspecialchars($p['unit']) ?></td>
<td contenteditable="true" class="editable_unit text-center" data-id="<?=$p['id']?>"><?= htmlspecialchars($p['min_stock']) ?></td>
<td class="text-center">
<button class="btn btn-danger btn-sm delete_product_btn">🗑</button>
</td>
</tr>
<?php endforeach; ?>
        
</tbody>
 </table>
        </br>
</div>

<!-- ✅ Pagination -->
<?php if ($total_pages > 1): ?>
<nav aria-label="Page navigation">
  <ul class="pagination justify-content-center mt-3">
    <?php if ($page > 1): ?>
      <li class="page-item">
        <a class="page-link" href="?page=<?= $page - 1 ?>">« Prev</a>
      </li>
    <?php endif; ?>

    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
      <li class="page-item <?= $i == $page ? 'active' : '' ?>">
        <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
      </li>
    <?php endfor; ?>

    <?php if ($page < $total_pages): ?>
      <li class="page-item">
        <a class="page-link" href="?page=<?= $page + 1 ?>">Next »</a>
      </li>
    <?php endif; ?>
  </ul>
</nav>
<?php endif; ?>

</table>
</div>

<!-- Add Product Modal -->
<div class="modal fade" id="addProductModal" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <form id="add_product_form">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Add New Products</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div id="product_rows">
          <div class="row mb-2 product_row g-2">
            <div class="col-md-2"><input type="text" name="name[]" class="form-control" placeholder="Name" required></div>
            <div class="col-md-2"><input type="number" name="stock[]" class="form-control" placeholder="Stock" min="0" required></div>
			<div class="col-md-2"><input type="number" name="price[]" class="form-control" placeholder="Price" step="0.01" min="0" required></div>
			<div class="col-md-2"><input type="text" name="unit[]" class="form-control" placeholder="Unit" required></div>
			<div class="col-md-2"><input type="number" name="min_stock[]" class="form-control" placeholder="min stock" required></div>
            <div class="col-md-2"><button type="button" class="btn btn-danger w-50 remove_row_btn">🗑</button></div>
          </div>
        </div>
        <button type="button" id="add_more_product_btn" class="btn btn-secondary mt-3 btn-custom">➕ Add More Product</button>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-success btn-lg btn-custom">Save Products</button>
        <button type="button" class="btn btn-secondary btn-lg btn-custom" data-bs-dismiss="modal">Cancel</button>
      </div>
    </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Inline Edit Handlers
function ajaxUpdate(id, field, value){
    $.post('all_products_update.php', {id:id, field:field, value:value}, function(resp){
        if(resp.status != 1){ alert(resp.message); location.reload(); }
    }, 'json');
}

$(document).on('blur', '.editable_stock', function(){
    let td=$(this);
    ajaxUpdate(td.data('id'),'stock',parseInt(td.text())||0);
});

$(document).on('blur', '.editable_price', function(){
    let td=$(this);
    ajaxUpdate(td.data('id'),'price',parseFloat(td.text())||0);
});

$(document).on('blur', '.editable_unit', function(){
    let td=$(this);
    ajaxUpdate(td.data('id'),'unit',td.text().trim());
});

// Delete product
$(document).on('click', '.delete_product_btn', function(){
    if(!confirm('Are you sure you want to delete this product?')) return;
    let id=$(this).closest('tr').find('.editable_stock').data('id');
    $.post('all_products_delete.php',{id:id},function(resp){
        if(resp.status==1) location.reload();
        else alert(resp.message);
    },'json');
});

// Add multiple products
$(document).on('click', '.remove_row_btn', function(){
    $(this).closest('.product_row').remove();
});

$('#add_more_product_btn').click(function(){
    let html=`<div class="row mb-2 product_row g-2">
            <div class="col-md-2"><input type="text" name="name[]" class="form-control" placeholder="Name" required></div>
            <div class="col-md-2"><input type="number" name="stock[]" class="form-control" placeholder="Stock" min="0" required></div>
            <div class="col-md-2"><input type="number" name="price[]" class="form-control" placeholder="Price" step="0.01" min="0" required></div>
            <div class="col-md-2"><input type="text" name="unit[]" class="form-control" placeholder="Unit" required></div>
			<div class="col-md-2"><input type="number" name="min_stock[]" class="form-control" placeholder="min Stock" min="0" required></div>
            <div class="col-md-2"><button type="button" class="btn btn-danger w-50 remove_row_btn">🗑</button></div>
          </div>`;
    $('#product_rows').append(html);
});

// ✅ Submit multiple products with success message + same page reload
$('#add_product_form').submit(function(e){
    e.preventDefault();
    $.post('all_products_add_multiple.php', $(this).serialize(), function(resp){
        if(resp.status==1){
            const modal = bootstrap.Modal.getInstance(document.getElementById('addProductModal'));
            modal.hide();
            Swal.fire({
                icon: 'success',
                title: '✅ Success!',
                text: 'Products added successfully!',
                timer: 1500,
                showConfirmButton: false
            }).then(() => {
                location.reload(); // stay on same page
            });
        } else {
            Swal.fire('Error', resp.message, 'error');
        }
    }, 'json');
});

// Search/filter
$('#product_search').on('keyup', function(){
    let val = $(this).val().toLowerCase();
    $('#products_table tbody tr').filter(function(){
        $(this).toggle(
            $(this).find('td:first').text().toLowerCase().indexOf(val) > -1 ||
            $(this).find('td:eq(3)').text().toLowerCase().indexOf(val) > -1
        );
    });
});
</script>
</body>
</html>
