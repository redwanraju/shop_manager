<?php
include("db.php");
include("header.php");
?>

<!-- Page Container -->
<div class="container py-5">

  <div class="row g-4">

    <!-- Left Side: Welcome Section (smaller) -->
    <div class="col-lg-4 col-md-5">
      <div class="card border-0 shadow-sm rounded-4 sticky-top" style="top: 90px;">
        <div class="card-body text-center">
          <i class="bi bi-shop-window text-primary mb-3" style="font-size: 3rem;"></i>
          <h3 class="fw-bold">Welcome to <span class="text-primary">Shop Manager</span></h3>
          <p class="text-muted">
            Manage your products, sales, and reports easily — all in one smart dashboard.
          </p>
          <a href="login.php" class="btn btn-outline-primary rounded-pill px-4 mt-2">
            <i class="bi bi-box-arrow-in-right"></i> Register
          </a>
        </div>
      </div>
    </div>

    <!-- Right Side: Blog Posts Section -->
    <div class="col-lg-8 col-md-7">
      <h2 class="fw-bold mb-4"><i class="bi bi-journal-text"></i> Latest Updates</h2>

      <div class="row g-4">

        <!-- Blog Card 1 -->
        <div class="col-12">
          <div class="card shadow-sm border-0 rounded-4 overflow-hidden">
            <div class="row g-0 align-items-center">
           
              <div class="col-md-7">
                <div class="card-body">
                  <h5 class="card-title fw-semibold">Track Your Daily Sales</h5>
                  <p class="card-text text-muted">আপনার দোকানের প্রতিদিনের বিক্রয় এখন ট্র্যাক করা আরও সহজ। নতুন Shop Manager ড্যাশবোর্ডে আপনি দেখতে পারবেন প্রতিটি ইনভয়েস, মোট বিক্রয়, পণ্যের স্টক এবং লাভ-ক্ষতির পূর্ণ বিশ্লেষণ — একদম রিয়েল টাইমে।</p>
                  <a href="#" class="btn btn-sm btn-outline-primary rounded-pill">Read More</a>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Blog Card 2 -->
        <div class="col-12">
          <div class="card shadow-sm border-0 rounded-4 overflow-hidden">
            <div class="row g-0 align-items-center">
             
              <div class="col-md-7">
                <div class="card-body">
                  <h5 class="card-title fw-semibold">Simplify Product Management</h5>
                  <p class="card-text text-muted">আজকের প্রতিযোগিতামূলক ব্যবসা জগতে প্রতিদিন অসংখ্য পণ্যের হিসাব রাখা সময়সাপেক্ষ। Shop Manager এখন এই কাজটিকে করেছে সহজ— এক জায়গা থেকে সব পণ্য, স্টক ও মূল্যের আপডেট দেখা ও পরিবর্তন করুন সহজেই।</p>
                  <a href="#" class="btn btn-sm btn-outline-primary rounded-pill">Read More</a>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Blog Card 3 -->
        <div class="col-12">
          <div class="card shadow-sm border-0 rounded-4 overflow-hidden">
            <div class="row g-0 align-items-center">
             
              <div class="col-md-7">
                <div class="card-body">
                  <h5 class="card-title fw-semibold">Detailed Insights</h5>
                  <p class="card-text text-muted">Shop Manager-এর স্বয়ংক্রিয় রিপোর্টিং সিস্টেম প্রতিদিন, সাপ্তাহিক ও মাসিক ভিত্তিতে বিস্তারিত রিপোর্ট তৈরি করে। এতে দেখা যায় বিক্রয়, লাভ–ক্ষতি ও গ্রাহকের প্রবণতা— সব এক জায়গায়।</p>
                  <a href="#" class="btn btn-sm btn-outline-primary rounded-pill">Read More</a>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div> <!-- Blog Row End -->

    </div>
  </div>
</div>

<!-- Optional Ad Section -->
<section class="py-4 text-center">
  <div class="container">
    <ins class="adsbygoogle"
         style="display:block"
         data-ad-client="ca-pub-XXXXXX"
         data-ad-slot="YYYYYY"
         data-ad-format="auto"
         data-full-width-responsive="true"></ins>
    <script>
         (adsbygoogle = window.adsbygoogle || []).push({});
    </script>
  </div>
</section>
