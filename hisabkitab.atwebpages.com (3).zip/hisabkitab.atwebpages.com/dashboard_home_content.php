<?php
session_start();
include("db.php");
require_once 'auth.php';
start_secure_session();

if(!isset($_SESSION['user_id'])) {
    echo "<p>Please login first.</p>";
    exit;
}

$user_id = $_SESSION['user_id'] ?? 0;
$today = date("Y-m-d");

// ✅ Helper function
function queryValue($conn, $sql, $types = "", $params = []) {
    $stmt = $conn->prepare($sql);
    if ($types && $params) $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_row();
    $stmt->close();
    return $res[0] ?? 0;
}

// ✅ Dashboard Data (from invoices table)
$cash_today = queryValue($conn, "SELECT SUM(paid) FROM invoices WHERE user_id=? AND DATE(created_at)=?", "is", [$user_id, $today]);
$due_today = queryValue($conn, "SELECT SUM(due) FROM invoices WHERE user_id=? AND DATE(created_at)=?", "is", [$user_id, $today]);
$total_today = queryValue($conn, "SELECT SUM(total) FROM invoices WHERE user_id=? AND DATE(created_at)=?", "is", [$user_id, $today]);
$total_due_all = queryValue($conn, "SELECT SUM(due) FROM invoices WHERE user_id=?", "i", [$user_id]);

// ✅ Low stock alert (from products table)
$stmt = $conn->prepare("SELECT name, stock, min_stock FROM products WHERE user_id=? AND stock <= min_stock ORDER BY stock ASC LIMIT 5");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$low_products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<!-- ✅ Styles and Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
.dashboard-card {
    min-height: 130px;
    border-radius: 0.75rem;
    color: #fff;
    padding: 1.2rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 4px 10px rgba(0,0,0,0.15);
    transition: transform 0.2s, box-shadow 0.2s;
}
.dashboard-card .icon {
    font-size: 3rem;
    opacity: 0.3;
}
.dashboard-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 6px 15px rgba(0,0,0,0.25);
}
.bg-primary { background: #0d6efd !important; }
.bg-success { background: #198754 !important; }
.bg-danger  { background: #dc3545 !important; }
.bg-warning { background: #ffc107 !important; color:#212529 !important; }
.bg-info    { background: #0dcaf0 !important; color:#212529 !important; }
</style>

<!-- ✅ Dashboard Cards -->
<div id="dashboard_cards">
<div class="row g-3">

  <div class="col-lg-4 col-md-6 col-sm-12">
    <div class="dashboard-card bg-info">
      <div>
        <h6 class="mb-1">আজকের ক্যাশ</h6>
        <h4>৳ <?= number_format($cash_today,2) ?></h4>
      </div>
      <div class="icon"><i class="fas fa-wallet"></i></div>
    </div>
  </div>

  <div class="col-lg-4 col-md-6 col-sm-12">
    <div class="dashboard-card bg-danger">
      <div>
        <h6 class="mb-1">আজকের ডিউ</h6>
        <h4>৳ <?= number_format($due_today,2) ?></h4>
      </div>
      <div class="icon"><i class="fas fa-exclamation-triangle"></i></div>
    </div>
  </div>

  <div class="col-lg-4 col-md-6 col-sm-12">
    <div class="dashboard-card bg-primary">
      <div>
        <h6 class="mb-1">আজকের বিক্রি</h6>
        <h4>৳ <?= number_format($total_today,2) ?></h4>
      </div>
      <div class="icon"><i class="fas fa-coins"></i></div>
    </div>
  </div>

</div>
</div>

<!-- ✅ Low Stock Alerts -->
<div class="row mt-4">
  <div class="col-lg-6 col-md-12">
    <div class="card border-danger shadow">
      <div class="card-header bg-danger text-white">
        <h5 class="mb-0"><i class="fas fa-exclamation-circle"></i> লো স্টক প্রোডাক্ট</h5>
      </div>
      <div class="card-body table-responsive">
        <table class="table table-hover text-center mb-0">
          <thead class="table-light">
            <tr>
              <th>প্রোডাক্ট</th>
              <th>স্টক</th>
              <th>মিনিমাম স্টক</th>
            </tr>
          </thead>
          <tbody>
            <?php if(empty($low_products)): ?>
              <tr><td colspan="3" class="text-muted">সব প্রোডাক্ট পর্যাপ্ত আছে ✅</td></tr>
            <?php else: foreach($low_products as $p): ?>
              <tr>
                <td><?= htmlspecialchars($p['name']) ?></td>
                <td><?= $p['stock'] ?></td>
                <td><?= $p['min_stock'] ?></td>
              </tr>
            <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- ✅ Dashboard Refresh Script -->
<script>
function refreshDashboardCounts() {
    $("#dashboard_cards").load("dashboard_home_content.php #dashboard_cards > *");
}
</script>