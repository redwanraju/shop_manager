<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Shop Manager | Blog Details</title>

  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    body {
      background-color: #f8f9fa;
      font-family: "Poppins", sans-serif;
    }
    .hero {
      background: linear-gradient(135deg, #007bff, #6610f2);
      color: #fff;
      padding: 80px 0 60px;
      text-align: center;
    }
    .hero h1 {
      font-weight: 700;
      margin-bottom: 15px;
    }
    .hero p {
      opacity: 0.9;
    }
    .post-card {
      max-width: 900px;
      margin: 50px auto;
      background: white;
      border-radius: 15px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.1);
      overflow: hidden;
    }
    .post-img {
      width: 100%;
      height: 400px;
      object-fit: cover;
    }
    .post-body {
      padding: 35px;
    }
    .post-body p {
      color: #333;
      line-height: 1.8;
      margin-bottom: 20px;
    }
    .post-meta {
      color: gray;
      font-size: 15px;
      margin-bottom: 20px;
    }
    .author-box {
      display: flex;
      align-items: center;
      margin-top: 30px;
      border-top: 1px solid #eee;
      padding-top: 20px;
    }
    .author-box img {
      width: 60px;
      height: 60px;
      border-radius: 50%;
      margin-right: 15px;
    }
    .author-box h6 {
      margin: 0;
      font-weight: 600;
    }
    .back-btn {
      display: block;
      width: fit-content;
      margin: 40px auto;
      text-decoration: none;
      border: 2px solid #007bff;
      color: #007bff;
      padding: 10px 25px;
      border-radius: 30px;
      transition: 0.3s;
    }
    .back-btn:hover {
      background: #007bff;
      color: white;
    }
  </style>
</head>
<body>

  <!-- Hero Section -->
  <section class="hero">
    <div class="container">
      <h1>Track Your Daily Sales</h1>
      <p><i class="bi bi-calendar3"></i> ১৫ অক্টোবর, ২০২৫ | <i class="bi bi-person-circle"></i> Shop Manager Team</p>
    </div>
  </section>

  <!-- Blog Content -->
  <div class="post-card">
    <img src="https://source.unsplash.com/1000x600/?shop,business" alt="Blog Image" class="post-img">
    <div class="post-body">
      <div class="post-meta">
        <i class="bi bi-clock"></i> 10:30 AM · <i class="bi bi-tag"></i> Sales, Business Growth
      </div>
      
      <p>
        আপনার দোকানের প্রতিদিনের বিক্রয় এখন ট্র্যাক করা আরও সহজ। নতুন Shop Manager ড্যাশবোর্ডে
        আপনি দেখতে পারবেন প্রতিটি ইনভয়েস, মোট বিক্রয়, পণ্যের স্টক এবং লাভ-ক্ষতির পূর্ণ বিশ্লেষণ।
        আর সবচেয়ে ভালো ব্যাপার হলো — এই তথ্যগুলো একদম রিয়েল টাইমে আপডেট হয়।
      </p>

      <p>
        আমাদের লক্ষ্য হচ্ছে আপনার ব্যবসাকে ডিজিটালভাবে আরও শক্তিশালী করে তোলা। Shop Manager আপনাকে
        সাহায্য করবে দ্রুত সিদ্ধান্ত নিতে, সময় বাঁচাতে, এবং আপনার ব্যবসার অগ্রগতি মনিটর করতে।
        এখন থেকে হিসাব রাখা হবে স্মার্ট ও সহজ।
      </p>

      <p>
        যদি আপনি এখনও Shop Manager ব্যবহার না করে থাকেন, তাহলে আজই শুরু করুন।
        সহজ রেজিস্ট্রেশন করে আপনি পাবেন একটি সম্পূর্ণ ফ্রি ট্রায়াল, যেখানে সব ফিচার ব্যবহার করতে পারবেন।
      </p>

      <div class="author-box">
        <img src="https://randomuser.me/api/portraits/men/22.jpg" alt="Author">
        <div>
          <h6>Shop Manager Team</h6>
          <small>Smart Business Solutions</small>
        </div>
      </div>
    </div>
  </div>

  <a href="index.php" class="back-btn">⬅️ সব ব্লগে ফিরে যান</a>

  <footer class="text-center py-3 text-muted">
    © 2025 Shop Manager — All Rights Reserved
  </footer>

</body>
</html>
