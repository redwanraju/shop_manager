<?php
include("db.php");
require_once 'auth.php';
start_secure_session();

if (!isset($_GET['invoice_no'])) {
    die("❌ Invoice number not provided.");
}

$invoice_no = $_GET['invoice_no'];

// ✅ Ajax update request (একই ফাইলের ভিতরে হ্যান্ডল)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_field') {
    $field = $_POST['field'];
    $value = trim($_POST['value']);

    $allowed = ['name', 'phone', 'address'];
    if (!in_array($field, $allowed)) {
        exit('❌ Invalid field');
    }

    $map = [
        'name' => 'customer_name',
        'phone' => 'phone',
        'address' => 'customer_address'
    ];

    $column = $map[$field];

    $stmt = $conn->prepare("UPDATE invoices SET $column = ? WHERE invoice_no = ?");
    $stmt->bind_param("ss", $value, $invoice_no);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "✅ Updated successfully";
    } else {
        echo "⚠️ No change";
    }
    exit;
}

// Fetch invoice
$stmt = $conn->prepare("SELECT * FROM invoices WHERE invoice_no = ?");
$stmt->bind_param("s", $invoice_no);
$stmt->execute();
$invoice = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$invoice) {
    die("❌ Invoice not found.");
}

// Fetch user/shop info (name + logo_path + whatsapp)
$user_stmt = $conn->prepare("SELECT name, logo_path, whatsapp FROM users WHERE id = ?");
$user_stmt->bind_param("i", $invoice['user_id']);
$user_stmt->execute();
$user = $user_stmt->get_result()->fetch_assoc();
$user_stmt->close();

// Fetch items
$item_stmt = $conn->prepare("SELECT ii.*, p.name, p.unit 
                             FROM invoice_items ii 
                             JOIN products p ON ii.product_id = p.id 
                             WHERE ii.invoice_id = ?");
$item_stmt->bind_param("i", $invoice['id']);
$item_stmt->execute();
$items = $item_stmt->get_result();
$item_stmt->close();

$delivery_date = $invoice['delivery_date'] ?? null;

if (!empty($delivery_date) && $delivery_date !== '0000-00-00') {
    $display_delivery = date("d M, Y", strtotime($delivery_date));
} else {
    $display_delivery = date("d M, Y");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Invoice <?= htmlspecialchars($invoice['invoice_no']) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<style>
  /* তোমার আগের সব স্টাইল একই রাখা হয়েছে */
  #invoice_view { width: 500px; margin: auto; padding: 10px 15px; }
  .card-body { padding: 5px 0; }
  .invoice-header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 10px; }
  .logo img { height: 80px; }
  table.table { margin-top: 0; padding-top: 0; }
  .info-table td { padding: 2px 8px; }
  .address-box { font-size: 14px; margin-top: 0; padding-top: 0; margin-bottom: 0; }
  [contenteditable="true"] { border-bottom: 1px dashed #999; cursor: text; }
  [contenteditable="true"]:focus { outline: 2px solid #007bff; border-radius: 4px; }
  .signatures { display: flex; justify-content: space-between; margin-top: 30px; }
  .sign-box { width: 30%; text-align: center; border-top: 1px dashed #000; padding-top: 5px; font-size: 14px; }
  @media print { [contenteditable="true"] { border: none !important; outline: none !important; } button, a.btn { display: none !important; } }
</style>

</head>
<body class="container py-4">

<div class="card" id="invoice_view" style="font-size: 12px;">
  <div class="card-body">

    <!-- ===== HEADER SECTION ===== -->
    <div class="invoice-header">
        <div class="logo">
            <?php if (!empty($user['logo_path'])): ?>
                <img src="logo.php?file=<?= urlencode($user['logo_path']) ?>" alt="Logo">
            <?php else: ?>
                <p><b>No Logo</b></p>
            <?php endif; ?>
        </div>

        <div class="text-center">
            <h3 class="mb-0">
                <?php 
                $shop_name = htmlspecialchars($user['name']);
                $shop_name = preg_replace_callback('/\b(B|K)/i', function($matches) {
                    return '<span style="color:red; font-weight:bold;">'.$matches[0].'</span>';
                }, $shop_name);
                echo $shop_name;
                ?>
            </h3>
            <p style="font-size: 14px; color: #555;">
                মগবাজার ,ঢাকা </br>
                WhatsApp: <?= htmlspecialchars($user['whatsapp'] ?? 'Not Available') ?>
            </p>
        </div>

        <div>
            <table class="table table-sm table-bordered info-table mb-0" style="font-size:12px;">
                <tr><td><b>Invoice No:</b></td><td><?= htmlspecialchars($invoice['invoice_no']) ?></td></tr>
                <tr><td><b>Date:</b></td><td><?= htmlspecialchars(date("d M, Y", strtotime($invoice['created_at']))) ?></td></tr>
                <tr><td><b>Delivery:</b></td><td><?= htmlspecialchars($display_delivery) ?></td></tr>
                <tr><td><b>Time:</b></td>
  				<td><input type="time" id="invoice_time" class="form-control form-control-sm" value="<?= date('H:i') ?>"></td></tr>
            </table>
        </div>
    </div>

    <!-- ===== CUSTOMER INFO ===== -->
    <div class="row mb-3">
      <div class="col-md-12">
        <h6>Customer Info:</h6>
        <p class="address-box">
          <b>Name:</b> 
          <span id="cust_name" contenteditable="true">
            <?= htmlspecialchars($invoice['customer_name']); ?>
          </span>
          &nbsp;|&nbsp; 
          <b>Phone:</b> 
          <span id="cust_phone" contenteditable="true">
            <?= htmlspecialchars($invoice['phone']); ?>
          </span>
          <br>
          <b>Address:</b> 
          <span id="cust_address" contenteditable="true">
            <?= htmlspecialchars($invoice['customer_address']); ?>
          </span>
        </p>
      </div>
    </div>

    <!-- ===== ITEMS TABLE (unchanged) ===== -->
    <table class="table table-bordered">
      <thead class="table-info">
        <tr>
          <th>Product</th>
          <th>Qty</th>
          <th>Unit</th>
          <th class="text-end">Price</th>
          <th class="text-end">Total</th>
        </tr>
      </thead>
      <tbody>
        <?php 
        $grand = 0;
        while($row = $items->fetch_assoc()): 
            $line_total = $row['quantity'] * $row['price'];
            $grand += $line_total;
        ?>
        <tr>
          <td><?= htmlspecialchars($row['name']) ?></td>
          <td><?= (int)$row['quantity'] ?></td>
          <td><?= htmlspecialchars($row['unit']) ?></td>
          <td class="text-end">৳<?= number_format($row['price'],2) ?></td>
          <td class="text-end">৳<?= number_format($line_total,2) ?></td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>

    <!-- ===== TOTALS & SIGNATURES (unchanged) ===== -->
    <table class="table table-sm" style="width: 100%; margin-top: 15px;">
        <tbody>
            <tr style="background-color: #f8f9fa;">
                <td><b>Subtotal</b></td>
                <td class="text-end">৳<?= number_format($invoice['subtotal'],2) ?></td>
            </tr>
            <tr style="background-color: #e9ecef;">
                <td><b>Discount</b></td>
                <td class="text-end">৳<?= number_format($invoice['discount'],2) ?></td>
            </tr>
            <tr style="background-color: #e9ecef;">
                <td><b>Total</b></td>
                <td class="text-end"><b>৳<?= number_format($invoice['total'],2) ?></b></td>
            </tr>
            <tr style="background-color: #f8f9fa;">
                <td><b>Advanced/Paid</b></td>
                <td class="text-end">৳<?= number_format($invoice['paid'],2) ?></td>
            </tr>
            <tr style="background-color: #e9ecef;">
                <td><b>Due</b></td>
                <td class="text-end">৳<?= number_format($invoice['due'],2) ?></td>
            </tr>
        </tbody>
    </table>

    <div class="signatures">
        <div class="sign-box">Delivery man</div>
        <div class="sign-box">Manager</div>
        <div class="sign-box">Receiver</div>
    </div>
  </div>

  <div class="mt-3">
      <button class="btn btn-success" onclick="printInvoice()">🖨️ Print</button>
      <button class="btn btn-danger" onclick="downloadPDF('<?= htmlspecialchars($invoice['invoice_no']) ?>')">📄 PDF</button>
      <a href="dashboard.php" class="btn btn-secondary">Dashboard</a>
          <a href="invoice.php" class="btn btn-secondary">create new invoice</a>
  </div>
</div>

<script>
// ✅ Inline Editable Live Update (same file)
const editableFields = ['cust_name', 'cust_phone', 'cust_address'];

editableFields.forEach(id => {
  $('#' + id).on('blur', function() {
    const field = id.replace('cust_', ''); // name / phone / address
    const value = $(this).text().trim();
    $.post('', { action: 'update_field', field: field, value: value }, function(resp) {
      console.log(resp);
    });
  });
});

function printInvoice() {
    const element = document.getElementById('invoice_view');
    const w = window.open('', '', 'height=800,width=1000');
    w.document.write('<html><head><title>Print Invoice</title>');
    w.document.write('<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">');
    w.document.write('</head><body>');
    w.document.write(element.innerHTML);
    w.document.write('</body></html>');
    w.document.close();
    w.print();
}

function downloadPDF(invoiceNo) {
    const element = document.getElementById('invoice_view');
    html2canvas(element).then(canvas => {
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jspdf.jsPDF('p', 'mm', 'a4');
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
        pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
        pdf.save(`Invoice_${invoiceNo}.pdf`);
    });
}
</script>

</body>
</html>
