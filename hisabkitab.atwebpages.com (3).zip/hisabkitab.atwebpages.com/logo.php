<?php
if (!isset($_GET['file'])) exit;

$file = basename($_GET['file']); // সেফটি
$path = __DIR__ . '/uploads/logos/' . $file;

if (file_exists($path)) {
    $ext = pathinfo($file, PATHINFO_EXTENSION);
    if ($ext === 'png') header('Content-Type: image/png');
    elseif ($ext === 'jpg' || $ext === 'jpeg') header('Content-Type: image/jpeg');
    else header('Content-Type: application/octet-stream');
    readfile($path);
    exit;
} else {
    http_response_code(404);
    echo 'No Logo';
}
?>
