<?php
session_start();
include("db.php");
require_once 'auth.php';
start_secure_session();

if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'] ?? 'User';

// ================= USER INFO =================
$stmt = $conn->prepare("SELECT role, trial_start, access FROM users WHERE id=? LIMIT 1");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$res = $stmt->get_result()->fetch_assoc();
$stmt->close();

$user_role = $res['role'] ?? 'user';
$trial_start = $res['trial_start'] ?? null;
$access = $res['access'] ?? 'off';

// ================= TRIAL DAYS FUNCTION =================
function get_trial_days_left($role, $trial_start, $trial_period = 7, $access = 'on') {
    if ($role === 'admin' || $access === 'on') {
        return null; // কোন ট্রায়াল দিন দেখাবে না
    }

    if (!$trial_start) return 0;

    $start = new DateTime($trial_start);
    $now = new DateTime();
    $diff = $now->diff($start)->days;
    $days_left = $trial_period - $diff;
    return ($days_left > 0) ? $days_left : 0;
}

$trial_days_left = get_trial_days_left($user_role, $trial_start, 7, $access);

// ================= DASHBOARD SUMMARY =================
function fetch_value($conn, $query, $user_id) {
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i",$user_id);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return array_values($res)[0] ?? 0;
}

// Fetch all products
$products = [];
$stmt = $conn->prepare("SELECT * FROM products WHERE user_id=? ORDER BY name ASC");
$stmt->bind_param("i",$user_id);
$stmt->execute();
$res = $stmt->get_result();
while($row = $res->fetch_assoc()) $products[] = $row;
$stmt->close();

// Dashboard values
$total_today = fetch_value($conn, "SELECT SUM(total) FROM invoices WHERE user_id=? AND DATE(created_at)=CURDATE()", $user_id);
$cash_today = fetch_value($conn, "SELECT SUM(paid) FROM invoices WHERE user_id=? AND DATE(created_at)=CURDATE()", $user_id);
$due_today = fetch_value($conn, "SELECT SUM(due) FROM invoices WHERE user_id=? AND DATE(created_at)=CURDATE()", $user_id);
$total_invoice = fetch_value($conn,"SELECT COUNT(*) FROM invoices WHERE user_id=?", $user_id);
$total_products = fetch_value($conn,"SELECT COUNT(*) FROM products WHERE user_id=?", $user_id);
$total_all   = fetch_value($conn,"SELECT SUM(total) FROM invoices WHERE user_id=?", $user_id);
$sales_month = fetch_value($conn,"SELECT SUM(total) FROM invoices WHERE user_id=? AND MONTH(created_at)=MONTH(CURDATE()) AND YEAR(created_at)=YEAR(CURDATE())", $user_id);
$invoice_today = fetch_value($conn,"SELECT COUNT(*) FROM invoices WHERE user_id=? AND DATE(created_at)=CURDATE()", $user_id);
?>

<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<title>Dashboard | MyERP</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>

<style>
:root { --main-bg: #f4f6f9; --text-color: #222; --card-bg: #ffffff; }
.dark-mode { --main-bg: #181a1b; --text-color: #e6e6e6; --card-bg: #242526; }
body { background-color: var(--main-bg); color: var(--text-color); transition: all 0.3s ease; }
.navbar-custom { background-color: var(--card-bg); border-bottom: 1px solid #ddd; }
</style>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

<?php include("sidebar.php"); ?>

<!-- ======= Top Navbar ======= -->
<nav class="main-header navbar navbar-expand navbar-light navbar-custom">
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
    </li>
    <li class="nav-item d-none d-sm-inline-block">
      <span class="nav-link">👋 স্বাগতম, <?= htmlspecialchars($user_name) ?></span>
    </li>
  </ul>
  <ul class="navbar-nav ml-auto align-items-center">
    <?php if($trial_days_left !== null): ?>
    <li class="nav-item trial-countdown">
      Free Trial: <?= $trial_days_left ?> দিন বাকি
    </li>
    <?php endif; ?>
  </ul>
  <ul class="navbar-nav ml-auto">
    <li class="nav-item">
      <a class="nav-link" href="#" id="themeToggle" title="থিম পরিবর্তন করুন">
        <i class="fas fa-moon"></i>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="profile.php" title="প্রোফাইল">
        <i class="fas fa-user"></i>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link text-danger" href="logout.php" title="লগআউট">
        <i class="fas fa-sign-out-alt"></i>
      </a>
    </li>
  </ul>
</nav>

<!-- ======= Content ======= -->
<div class="content-wrapper">
  <section class="content">
    <div class="container-fluid">
      <!-- Dashboard Summary -->
      <div class="row">
        <div class="col-lg-3 col-6">
          <div class="small-box bg-info">
            <div class="inner"><h3>৳<?=number_format($cash_today,2)?></h3><p>আজকের ক্যাশ</p></div>
            <div class="icon"><i class="fas fa-wallet"></i></div>
          </div>
        </div>

        <div class="col-lg-3 col-6">
          <div class="small-box bg-danger">
            <div class="inner"><h3>৳<?=number_format($due_today,2)?></h3><p>আজকের ডিউ</p></div>
            <div class="icon"><i class="fas fa-exclamation-triangle"></i></div>
          </div>
        </div>

        <div class="col-lg-3 col-6">
          <div class="small-box bg-primary">
            <div class="inner"><h3>৳<?=number_format($total_today,2)?></h3><p>আজকের বিক্রি</p></div>
            <div class="icon"><i class="fas fa-coins"></i></div>
          </div>
        </div>

        <div class="col-lg-3 col-6">
          <div class="small-box bg-primary">
            <div class="inner"><h3>৳<?=number_format($sales_month,2)?></h3><p>এ মাসের বিক্রি</p></div>
            <div class="icon"><i class="fas fa-chart-bar"></i></div>
          </div>
        </div>

        <div class="col-lg-3 col-6">
          <div class="small-box bg-success">
            <div class="inner"><h3>৳<?=number_format($total_all,2)?></h3><p>সর্বমোট বিক্রি</p></div>
            <div class="icon"><i class="fas fa-chart-line"></i></div>
          </div>
        </div>

        <div class="col-lg-3 col-6">
          <div class="small-box bg-dark">
            <div class="inner"><h3><?=number_format($invoice_today)?></h3><p>আজকের ইনভয়েস</p></div>
            <div class="icon"><i class="fas fa-file-invoice"></i></div>
          </div>
        </div>

        <div class="col-lg-3 col-6">
          <div class="small-box bg-secondary">
            <div class="inner"><h3><?=number_format($total_invoice)?></h3><p>মোট ইনভয়েস</p></div>
            <div class="icon"><i class="fas fa-file-invoice-dollar"></i></div>
          </div>
        </div>

        <div class="col-lg-3 col-6">
          <div class="small-box bg-secondary">
            <div class="inner"><h3><?=number_format($total_products)?></h3><p>মোট পণ্য</p></div>
            <div class="icon"><i class="fas fa-box"></i></div>
          </div>
        </div>
      </div>

      <!-- Dynamic Section -->
      <div id="dynamic_content"></div>

    </div>
  </section>
</div>

<!-- ======= Theme System ======= -->
<script>
document.addEventListener('DOMContentLoaded', function() {
  const body = document.body;
  const themeToggle = document.getElementById('themeToggle');
  const currentTheme = localStorage.getItem('theme') || 'light';
  if (currentTheme === 'dark') body.classList.add('dark-mode');

  themeToggle.addEventListener('click', () => {
    body.classList.toggle('dark-mode');
    const newTheme = body.classList.contains('dark-mode') ? 'dark' : 'light';
    localStorage.setItem('theme', newTheme);
  });
});

// Dynamic content load functions
function showProducts() { $('#dynamic_content').load('all_products.php'); }
function showInvoiceForm() { $('#dynamic_content').load('invoice.php'); }
function showAllInvoices() { $('#dynamic_content').load('ajax_all_invoices.php'); }
function totalInvoices() { $('#dynamic_content').load('invoice_list.php'); }
function stockLow() { $('#dynamic_content').load('ajax_low_stock.php'); }
function charts() { $('#dynamic_content').load('charts.php'); }
</script>

</body>
</html>