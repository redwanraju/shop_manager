<?php
session_start();
require_once "db.php";

// শুধুমাত্র Admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] != 1) {
    header("Location: access_denied.php");
    exit;
}

if (!isset($_GET['id'])) {
    header("Location: admin_index.php");
    exit;
}

$user_id = intval($_GET['id']);

// Current access fetch
$stmt = $conn->prepare("SELECT access FROM users WHERE id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($row) {
    $new_status = (strcasecmp($row['access'], "on") === 0) ? "off" : "on";

    $stmt = $conn->prepare("UPDATE users SET access=? WHERE id=?");
    $stmt->bind_param("si", $new_status, $user_id);
    $stmt->execute();
    $stmt->close();
}

// Redirect back
header("Location: admin_index.php?msg=access_toggled");
exit;
