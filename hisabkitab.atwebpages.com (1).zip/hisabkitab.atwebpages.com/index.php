<?php
include("db.php");
include("header2.php");
?>

<!-- Hero Section -->
<section class="py-5 text-center bg-light">
  <div class="container">
    <i class="bi bi-shop-window text-primary mb-3" style="font-size: 3.5rem;"></i>
    <h1 class="fw-bold mb-3">Welcome to <span class="text-primary">Shop Manager</span></h1>
    <p class="text-muted mb-4">
      Manage your products, sales, and reports easily — all in one smart dashboard.
    </p>
    <div class="d-flex justify-content-center gap-3">
      <a href="login.php" class="btn btn-outline-primary rounded-pill px-4">
        <i class="bi bi-box-arrow-in-right"></i> Login
      </a>
    </div>
  </div>
</section>

<!-- Blog / Info Section -->
<section class="py-5 bg-white">
  <div class="container">
    <h2 class="fw-bold text-center mb-4"><i class="bi bi-journal-text"></i> Latest Updates</h2>
    <div class="row g-4">

      <!-- Blog Card 1 -->
      <div class="col-md-4">
        <div class="card shadow-sm border-0 h-100 rounded-4">
          <img src="https://source.unsplash.com/500x300/?shop,business" class="card-img-top rounded-top-4" alt="Shop update">
          <div class="card-body">
            <h5 class="card-title fw-semibold">Track Your Daily Sales</h5>
            <p class="card-text text-muted">Stay updated with your shop’s performance. Manage stock and view detailed reports instantly.</p>
            <a href="single_blog.php" class="btn btn-sm btn-outline-primary rounded-pill">Read More</a>
          </div>
        </div>
      </div>

      <!-- Blog Card 2 -->
      <div class="col-md-4">
        <div class="card shadow-sm border-0 h-100 rounded-4">
          <img src="https://source.unsplash.com/500x300/?inventory,warehouse" class="card-img-top rounded-top-4" alt="Inventory">
          <div class="card-body">
            <h5 class="card-title fw-semibold">Simplify Product Management</h5>
            <p class="card-text text-muted">Add, edit, and monitor all your shop products easily from one dashboard.</p>
            <a href="single_blog.php" class="btn btn-sm btn-outline-primary rounded-pill">Read More</a>
          </div>
        </div>
      </div>

      <!-- Blog Card 3 -->
      <div class="col-md-4">
        <div class="card shadow-sm border-0 h-100 rounded-4">
          <img src="https://source.unsplash.com/500x300/?report,analytics" class="card-img-top rounded-top-4" alt="Reports">
          <div class="card-body">
            <h5 class="card-title fw-semibold">Detailed Insights</h5>
            <p class="card-text text-muted">Generate automatic reports to analyze profit, loss, and customer trends effectively.</p>
            <a href="single_blog.php" class="btn btn-sm btn-outline-primary rounded-pill">Read More</a>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- Optional Ad Section -->
<section class="py-4 text-center">
  <div class="container">
    <ins class="adsbygoogle"
         style="display:block"
         data-ad-client="ca-pub-XXXXXX"
         data-ad-slot="YYYYYY"
         data-ad-format="auto"
         data-full-width-responsive="true"></ins>
    <script>
         (adsbygoogle = window.adsbygoogle || []).push({});
    </script>
  </div>
</section>

<?php include("footer.php"); ?>