<?php
include("db.php");
include("header.php");

// ডেমো হিসেবে এখন স্ট্যাটিক ব্লগ ডাটা ব্যবহার করছি
// পরবর্তীতে তুমি GET দিয়ে ?id= পাঠিয়ে ডাটাবেজ থেকে লোড করতে পারবে
$blog = [
    "title" => "Track Your Daily Sales Effectively",
    "author" => "Admin",
    "date" => "October 8, 2025",
    "image" => "https://source.unsplash.com/1200x600/?business,analytics",
    "content" => "
        Running a business without tracking sales is like sailing without a compass.
        With <strong>Shop Manager</strong>, you can easily monitor your daily sales,
        track profits, and adjust your strategy in real time.

        <br><br>
        💡 <b>Key Features:</b>
        <ul>
            <li>Instant sales updates and profit tracking</li>
            <li>Comprehensive reports with graphical insights</li>
            <li>Easy export to PDF or Excel</li>
        </ul>

        <br>
        Consistent tracking helps identify top-performing products and seasonal trends.
        This allows better decision-making, reduces losses, and improves profitability.
        <br><br>
        So what are you waiting for? Start managing your business smarter, not harder!
    "
];
?>

<!-- Single Blog Page -->
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-9">
            <div class="card shadow-lg border-0 rounded-4 overflow-hidden">
                <img src="<?= htmlspecialchars($blog['image']) ?>" class="card-img-top" alt="Blog Image">

                <div class="card-body p-4">
                    <h1 class="fw-bold mb-3"><?= htmlspecialchars($blog['title']) ?></h1>

                    <div class="d-flex align-items-center text-muted mb-4">
                        <i class="bi bi-person-circle me-2"></i> <?= htmlspecialchars($blog['author']) ?>
                        <span class="mx-2">|</span>
                        <i class="bi bi-calendar3 me-2"></i> <?= htmlspecialchars($blog['date']) ?>
                    </div>

                    <div class="blog-content fs-6 lh-lg">
                        <?= $blog['content'] ?>
                    </div>

                    <div class="mt-5 d-flex justify-content-between">
                        <a href="index.php" class="btn btn-outline-primary rounded-pill">
                            <i class="bi bi-arrow-left"></i> Back to Blogs
                        </a>

                        <div>
                            <a href="#" class="btn btn-outline-secondary rounded-circle"><i class="bi bi-facebook"></i></a>
                            <a href="#" class="btn btn-outline-secondary rounded-circle"><i class="bi bi-twitter"></i></a>
                            <a href="#" class="btn btn-outline-secondary rounded-circle"><i class="bi bi-whatsapp"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include("footer.php"); ?>

<style>
.blog-content ul {
    margin-left: 20px;
}
.blog-content strong {
    color: #0d6efd;
}
</style>