<?php
session_start();
include("db.php");
require_once 'auth.php';
start_secure_session();

if(!isset($_SESSION['user_id'])) {
    echo "<p>Please login first.</p>";
    exit;
}

$user_id = $_SESSION['user_id'] ?? 0;
$user_name = $_SESSION['user_name'] ?? 'User';

// Helper function
function fetch_value($conn, $query, $user_id) {
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return array_values($res)[0] ?? 0;
}

// ---------------- Summary Values ----------------
$total_today   = fetch_value($conn, "SELECT SUM(total) FROM invoices WHERE user_id=? AND DATE(created_at)=CURDATE()", $user_id);
$cash_today    = fetch_value($conn, "SELECT SUM(paid) FROM invoices WHERE user_id=? AND DATE(created_at)=CURDATE()", $user_id);
$due_today     = fetch_value($conn, "SELECT SUM(due) FROM invoices WHERE user_id=? AND DATE(created_at)=CURDATE()", $user_id);
$today_purchase    = fetch_value($conn, "SELECT SUM(stock * price) FROM products WHERE user_id=? AND DATE(created_at)=CURDATE()", $user_id);
$previous_purchase = fetch_value($conn, "SELECT SUM(stock * price) FROM products WHERE user_id=? AND DATE(created_at) < CURDATE()", $user_id);
$total_purchase    = fetch_value($conn, "SELECT SUM(stock * price) FROM products WHERE user_id=?", $user_id);
$total_products    = fetch_value($conn, "SELECT COUNT(*) FROM products WHERE user_id=?", $user_id);
$total_invoice     = fetch_value($conn, "SELECT COUNT(*) FROM invoices WHERE user_id=?", $user_id);

// ---------------- Low Stock Products ----------------
$low_products = [];
$stmt = $conn->prepare("SELECT name, stock, min_stock FROM products WHERE user_id=? AND stock <= min_stock ORDER BY stock ASC LIMIT 5");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$low_products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
.dashboard-card {
    min-height: 130px;
    border-radius: 0.75rem;
    color: #fff;
    padding: 1.2rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 4px 10px rgba(0,0,0,0.15);
    transition: transform 0.2s, box-shadow 0.2s;
}
.dashboard-card .icon {
    font-size: 3rem;
    opacity: 0.3;
}
.dashboard-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 6px 15px rgba(0,0,0,0.25);
}
.bg-primary { background: #0d6efd !important; }
.bg-success { background: #198754 !important; }
.bg-danger  { background: #dc3545 !important; }
.bg-warning { background: #ffc107 !important; color:#212529 !important; }
.bg-info    { background: #0dcaf0 !important; color:#212529 !important; }
.bg-secondary { background: #6c757d !important; }
.bg-dark { background: #343a40 !important; }
</style>

<div class="row g-3">
  <div class="col-lg-2 col-md-4 col-sm-6">
    <div class="dashboard-card bg-info">
      <div>
        <h6 class="mb-1">আজকের ক্যাশ</h6>
        <h4>৳ <?= number_format($cash_today,2) ?></h4>
      </div>
      <div class="icon"><i class="fas fa-wallet"></i></div>
    </div>
  </div>

  <div class="col-lg-2 col-md-4 col-sm-6">
    <div class="dashboard-card bg-danger">
      <div>
        <h6 class="mb-1">আজকের ডিউ</h6>
        <h4>৳ <?= number_format($due_today,2) ?></h4>
      </div>
      <div class="icon"><i class="fas fa-exclamation-triangle"></i></div>
    </div>
  </div>

  <div class="col-lg-2 col-md-4 col-sm-6">
    <div class="dashboard-card bg-primary">
      <div>
        <h6 class="mb-1">আজকের মোট</h6>
        <h4>৳ <?= number_format($total_today,2) ?></h4>
      </div>
      <div class="icon"><i class="fas fa-coins"></i></div>
    </div>
  </div>

  <div class="col-lg-2 col-md-4 col-sm-6">
    <div class="dashboard-card bg-warning">
      <div>
        <h6 class="mb-1">আজকের পারচেজ</h6>
        <h4>৳ <?= number_format($today_purchase,2) ?></h4>
      </div>
      <div class="icon"><i class="fas fa-truck"></i></div>
    </div>
  </div>

  <div class="col-lg-2 col-md-4 col-sm-6">
    <div class="dashboard-card bg-secondary">
      <div>
        <h6 class="mb-1">আগের পারচেজ</h6>
        <h4>৳ <?= number_format($previous_purchase,2) ?></h4>
      </div>
      <div class="icon"><i class="fas fa-history"></i></div>
    </div>
  </div>

  <div class="col-lg-2 col-md-4 col-sm-6">
    <div class="dashboard-card bg-success">
      <div>
        <h6 class="mb-1">মোট পারচেজ</h6>
        <h4>৳ <?= number_format($total_purchase,2) ?></h4>
      </div>
      <div class="icon"><i class="fas fa-coins"></i></div>
    </div>
  </div>

  <div class="col-lg-3 col-md-6 col-sm-6 mt-3">
    <div class="dashboard-card bg-primary">
      <div>
        <h6 class="mb-1">মোট প্রোডাক্ট</h6>
        <h4><?= (int)$total_products ?></h4>
      </div>
      <div class="icon"><i class="fas fa-boxes"></i></div>
    </div>
  </div>

  <div class="col-lg-3 col-md-6 col-sm-6 mt-3">
    <div class="dashboard-card bg-dark">
      <div>
        <h6 class="mb-1">মোট ইনভয়েস</h6>
        <h4><?= (int)$total_invoice ?></h4>
      </div>
      <div class="icon"><i class="fas fa-file-invoice"></i></div>
    </div>
  </div>
</div>

<!-- Low Stock Alerts -->
<div class="row mt-3">
  <div class="col-lg-6 col-md-12">
    <div class="card border-danger shadow">
      <div class="card-header bg-danger text-white">
        <h5 class="mb-0">Low Stock Alerts</h5>
      </div>
      <div class="card-body table-responsive">
        <table class="table table-hover text-center mb-0">
          <thead>
            <tr><th>Product</th><th>Stock</th><th>Min Stock</th></tr>
          </thead>
          <tbody>
            <?php if(empty($low_products)): ?>
              <tr><td colspan="3">No low stock products</td></tr>
            <?php else: foreach($low_products as $p): ?>
              <tr>
                <td><?= htmlspecialchars($p['name']) ?></td>
                <td><?= $p['stock'] ?></td>
                <td><?= $p['min_stock'] ?></td>
              </tr>
            <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>