<?php
// Start secure session
function start_secure_session() {
    if(session_status() === PHP_SESSION_NONE){
        session_start();
    }
}

// Generate CSRF token
function generate_csrf_token() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(24));
    }
    return $_SESSION['csrf_token'];
}

// Verify CSRF token
function verify_csrf_token($token) {
    if (!isset($_SESSION['csrf_token'])) return false;
    return hash_equals($_SESSION['csrf_token'], $token);
}

// Check if a user's trial is active (role-based)
function is_trial_active($user_role, $trial_start, $trial_days = 7) {
    // Admin role or special roles have no trial
    if ($user_role === 'admin') {
        return true; // always active
    }

    if (!$trial_start) return false;

    $trial_start_dt = new DateTime($trial_start);
    $trial_end = (clone $trial_start_dt)->modify("+$trial_days days");
    $today = new DateTime();

    return $today <= $trial_end;
}

// Get remaining trial days (for normal users)
function get_trial_days_left($user_role, $trial_start, $trial_days = 7) {
    if ($user_role === 'admin') return -1; // -1 indicates unlimited

    if (!$trial_start) return 0;

    $trial_start_dt = new DateTime($trial_start);
    $trial_end = (clone $trial_start_dt)->modify("+$trial_days days");
    $today = new DateTime();

    $interval = $today->diff($trial_end);
    return ($today <= $trial_end) ? $interval->days : 0;
}
?>