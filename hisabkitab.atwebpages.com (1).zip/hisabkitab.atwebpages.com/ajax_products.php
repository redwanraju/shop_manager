<?php
session_start();
include("db.php");
require_once 'auth.php';
start_secure_session();

if(!isset($_SESSION['user_id'])) exit("Unauthorized");
$user_id = $_SESSION['user_id'];

$conn = new mysqli($servername, $username, $password, $dbname);
$stmt = $conn->prepare("SELECT name, stock, min_stock, price FROM products WHERE user_id=? ORDER BY id DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

echo '<table class="table table-bordered table-hover text-center"><thead><tr><th>Name</th><th>Stock</th><th>Min Stock</th><th>Price</th></tr></thead><tbody>';
if(empty($products)) echo '<tr><td colspan="4">No products</td></tr>';
else foreach($products as $p) echo '<tr><td>'.htmlspecialchars($p['name']).'</td><td>'.$p['stock'].'</td><td>'.$p['min_stock'].'</td><td>৳ '.number_format($p['price'],2).'</td></tr>';
echo '</tbody></table>';
?>