<?php
session_start();

// সব সেশন ভেরিয়েবল মুছে ফেলুন
$_SESSION = [];

// সেশন কুকি মুছে ফেলুন
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// সেশন ধ্বংস করুন
session_destroy();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Logged Out</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: #f8f9fa;
        }
        .card {
            max-width: 400px;
            width: 100%;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
    </style>
    <script>
        // ৩ সেকেন্ড পরে login.php এ redirect
        setTimeout(function(){
            window.location.href = "index.php";
        }, 3000);
    </script>
</head>
<body>
    <div class="card text-center p-4">
        <div class="card-body">
            <h3 class="text-success mb-3">✅ Logged Out</h3>
            <p class="mb-3">You have successfully logged out.</p>
            <p class="text-muted">Redirecting to login page...</p>
            <a href="login.php" class="btn btn-primary mt-3">Go to Login Now</a>
        </div>
    </div>
</body>
</html>