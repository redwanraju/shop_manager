<?php
session_start();
include("db.php");
require_once 'auth.php';
start_secure_session();

if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'] ?? 'User';

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// ---------------- Fetch role and trial_start ----------------
$stmt = $conn->prepare("SELECT role, trial_start FROM users WHERE id=? LIMIT 1");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$res = $stmt->get_result()->fetch_assoc();
$stmt->close();

$user_role = $res['role'] ?? 'user';
$trial_start = $res['trial_start'] ?? NULL;
$trial_days_left = get_trial_days_left($user_role, $trial_start, 7);

// ---------------- Helper function ----------------
function fetch_value($conn, $query, $user_id) {
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return array_values($res)[0] ?? 0;
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="utf-8">
<title>Dashboard | MyERP</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
.card .card-body h3 { font-size: 1.6rem; }
body.dark-mode { background-color: #1e1e2f; color: #dcdcdc; }
body.dark-mode .main-sidebar { background-color: #2b2b3a; }
body.dark-mode .small-box, body.dark-mode .card, body.dark-mode table { color: #fff; }
.navbar .trial-countdown { font-weight: bold; margin-left: 10px; color: #ffdd57; }
</style>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
  <ul class="navbar-nav">
    <li class="nav-item"><a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a></li>
    <li class="nav-item d-none d-sm-inline-block"><a href="#" class="nav-link">Home</a></li>
  </ul>
  <ul class="navbar-nav ml-auto align-items-center">
    <?php if($user_role !== 'admin' && $trial_days_left >=0): ?>
    <li class="nav-item trial-countdown">
      Free Trial: <?= $trial_days_left ?> দিন বাকি
    </li>
    <?php endif; ?>
    <li class="nav-item"><a class="nav-link" href="#" id="toggleTheme"><i class="fas fa-adjust"></i></a></li>
    <li class="nav-item"><a class="nav-link" href="profile.php"><i class="fas fa-user"></i></a></li>
    <li class="nav-item"><a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt"></i></a></li>
  </ul>
</nav>

<!-- Sidebar -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
  <a href="#" class="brand-link text-center">
    <span class="brand-text font-weight-light"><i class="fa-solid fa-store"></i> MyERP</span>
  </a>
  <div class="sidebar">
    <div class="user-panel mt-3 pb-3 mb-3 d-flex align-items-center">
      <div class="image mr-2"><i class="fa-solid fa-user-circle fa-2x text-white"></i></div>
      <div class="info"><a href="#" class="d-block"><?= htmlspecialchars($user_name) ?></a></div>
    </div>
    <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column" role="menu">
        <li class="nav-item"><a href="#" class="nav-link active" id="loadDashboard"><i class="nav-icon fas fa-tachometer-alt"></i><p>Dashboard</p></a></li>
        <li class="nav-item"><a href="#" class="nav-link" id="loadProducts"><i class="nav-icon fas fa-box"></i><p>Products List</p></a></li>
        <li class="nav-item"><a href="#" class="nav-link" id="loadInvoices"><i class="nav-icon fas fa-file-invoice"></i><p>Invoice List</p></a></li>
      </ul>
    </nav>
  </div>
</aside>

<!-- Main Content -->
<div class="content-wrapper">
  <div class="content-header">
    <div class="container-fluid">
      <h3 class="mb-2">👋 Welcome, <?= htmlspecialchars($user_name) ?></h3>
      <p class="text-muted">আপনার ব্যবসার সারসংক্ষেপ নিচে দেখানো হয়েছে।</p>
    </div>
  </div>

  <section class="content">
    <div class="container-fluid" id="ajaxContent">
      <!-- AJAX দিয়ে এখানে Dashboard / Products / Invoice লোড হবে -->
    </div>
  </section>
</div>

<footer class="main-footer text-center">
  <strong>&copy; <?= date("Y") ?> MyERP.</strong> All rights reserved.
</footer>
</div>

<!-- JS -->
<script>
document.addEventListener('DOMContentLoaded', function() {
  const body = document.body;
  const toggleBtn = document.getElementById('toggleTheme');

  // Apply saved theme
  if(localStorage.getItem('theme') === 'dark') body.classList.add('dark-mode');

  // Theme toggle
  toggleBtn.addEventListener('click', function(e){
    e.preventDefault();
    body.classList.toggle('dark-mode');
    localStorage.setItem('theme', body.classList.contains('dark-mode') ? 'dark' : 'light');
  });

  // Ensure sidebar toggle works on mobile
  $('[data-widget="pushmenu"]').PushMenu();

  // Load Dashboard by default
  $("#ajaxContent").load("dashboard_home_content.php");

  // Sidebar AJAX handlers
  $("#loadDashboard").click(function(e){
    e.preventDefault();
    $(".nav-link").removeClass("active");
    $(this).addClass("active");
    $("#ajaxContent").load("dashboard_home_content.php");
  });

  $("#loadProducts").click(function(e){
    e.preventDefault();
    $(".nav-link").removeClass("active");
    $(this).addClass("active");
    $("#ajaxContent").load("all_products.php");
  });

  $("#loadInvoices").click(function(e){
    e.preventDefault();
    $(".nav-link").removeClass("active");
    $(this).addClass("active");
    $("#ajaxContent").load("invoice_list.php");
  });
});
</script>

</body>
</html>