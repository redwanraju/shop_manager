<?php
// =====================================
// Invoice List
// =====================================

// আউটপুট বাফারিং শুরু
ob_start();

// Secure session + auth
session_start();
include("db.php");
require_once 'auth.php';
start_secure_session();

// লগইন চেক
if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// ============================
// Delete Request Handle
// ============================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_invoice'])) {
    $invoice_no = $_POST['delete_invoice'];

    // প্রথমে invoice_id বের করুন
    $stmt = $conn->prepare("SELECT id FROM invoices WHERE invoice_no=? AND user_id=?");
    $stmt->bind_param("si", $invoice_no, $user_id);
    $stmt->execute();
    $res = $stmt->get_result();
    if($row = $res->fetch_assoc()){
        $invoice_id = $row['id'];

        // প্রথমে invoice_items ডিলিট
        $del_items = $conn->prepare("DELETE FROM invoice_items WHERE invoice_id=?");
        $del_items->bind_param("i", $invoice_id);
        $del_items->execute();
        $del_items->close();

        // তারপর invoices ডিলিট
        $del_invoice = $conn->prepare("DELETE FROM invoices WHERE id=? AND user_id=?");
        $del_invoice->bind_param("ii", $invoice_id, $user_id);
        $del_invoice->execute();
        $del_invoice->close();

        header("Location: invoice_list.php?msg=deleted");
        exit;
    } else {
        // ইনভয়েস পাওয়া যায়নি
        header("Location: invoice_list.php?msg=notfound");
        exit;
    }
}

// ============================
// Filter/Search
// ============================
$search = $_GET['search'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to   = $_GET['date_to'] ?? '';

// ============================
// Query বানানো
// ============================
$sql = "SELECT * FROM invoices WHERE user_id = ?";
$params = [$user_id];
$types = "i";

if ($search !== '') {
    $sql .= " AND invoice_no LIKE ?";
    $params[] = "%$search%";
    $types .= "s";
}
if ($date_from !== '' && $date_to !== '') {
    $sql .= " AND DATE(created_at) BETWEEN ? AND ?";
    $params[] = $date_from;
    $params[] = $date_to;
    $types .= "ss";
} elseif ($date_from !== '') {
    $sql .= " AND DATE(created_at) >= ?";
    $params[] = $date_from;
    $types .= "s";
} elseif ($date_to !== '') {
    $sql .= " AND DATE(created_at) <= ?";
    $params[] = $date_to;
    $types .= "s";
}

$sql .= " ORDER BY created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$res = $stmt->get_result();
$stmt->close();

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Invoice List</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container py-4">

<h2 class="mb-4">📋 My Invoices</h2>

<!-- Filter Form -->
<form class="row g-3 mb-4" method="get">
    <div class="col-md-3">
        <input type="text" name="search" value="<?=htmlspecialchars($search)?>" class="form-control" placeholder="Search Invoice No">
    </div>
    <div class="col-md-3">
        <input type="date" name="date_from" value="<?=htmlspecialchars($date_from)?>" class="form-control">
    </div>
    <div class="col-md-3">
        <input type="date" name="date_to" value="<?=htmlspecialchars($date_to)?>" class="form-control">
    </div>
    <div class="col-md-3">
        <button type="submit" class="btn btn-primary">🔍 Filter</button>
        <a href="invoice_list.php" class="btn btn-secondary">Reset</a>
    </div>
</form>

<?php if (isset($_GET['msg']) && $_GET['msg'] === 'deleted'): ?>
    <div class="alert alert-success">✅ Invoice deleted successfully!</div>
<?php endif; ?>

<table class="table table-bordered table-striped">
  <thead class="table-dark">
    <tr>
      <th>Invoice No</th>
      <th>Date</th>
      <th class="text-end">Total</th>
      <th class="text-end">Paid</th>
      <th class="text-end">Due</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
    <?php if ($res->num_rows > 0): ?>
        <?php while($row = $res->fetch_assoc()): ?>
        <tr>
          <td><?= htmlspecialchars($row['invoice_no']) ?></td>
          <td><?= htmlspecialchars($row['created_at']) ?></td>
          <td class="text-end"><?= number_format($row['total'],2) ?></td>
          <td class="text-end"><?= number_format($row['paid'],2) ?></td>
          <td class="text-end"><?= number_format($row['due'],2) ?></td>
          <td class="d-flex gap-1">
            <a href="view_invoice.php?invoice_no=<?= urlencode($row['invoice_no']) ?>" class="btn btn-sm btn-primary">👁 View</a>
            <form method="post" onsubmit="return confirm('Are you sure you want to delete this invoice?');">
                <input type="hidden" name="delete_invoice" value="<?= htmlspecialchars($row['invoice_no']) ?>">
                <button type="submit" class="btn btn-sm btn-danger">🗑 Delete</button>
            </form>
          </td>
        </tr>
        <?php endwhile; ?>
    <?php else: ?>
        <tr>
            <td colspan="6" class="text-center text-danger">No invoices found</td>
        </tr>
    <?php endif; ?>
  </tbody>
</table>
</body>
</html>

<?php
// আউটপুট বাফার ক্লিয়ার
ob_end_flush();
?>