<?php
include("db.php");
require_once 'auth.php';
start_secure_session();

if (!isset($_GET['invoice_no'])) {
    die("❌ Invoice number not provided.");
}

$invoice_no = $_GET['invoice_no'];

// Fetch invoice
$stmt = $conn->prepare("SELECT * FROM invoices WHERE invoice_no = ?");
$stmt->bind_param("s", $invoice_no);
$stmt->execute();
$invoice = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$invoice) {
    die("❌ Invoice not found.");
}

// Fetch items
$item_stmt = $conn->prepare("SELECT ii.*, p.name, p.unit 
                             FROM invoice_items ii 
                             JOIN products p ON ii.product_id = p.id 
                             WHERE ii.invoice_id = ?");
$item_stmt->bind_param("i", $invoice['id']);
$item_stmt->execute();
$items = $item_stmt->get_result();
$item_stmt->close();
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Invoice <?= htmlspecialchars($invoice['invoice_no']) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
</head>
<body class="container py-4">

<div class="card" id="invoice_view">
  <div class="card-body">
    <h3>🧾 Invoice: <?= htmlspecialchars($invoice['invoice_no']) ?></h3>
    <p>Date: <?= htmlspecialchars($invoice['created_at']) ?></p>

    <table class="table table-bordered">
      <thead class="table-dark">
        <tr>
          <th>Product</th>
          <th>Qty</th>
          <th>Unit</th>
          <th class="text-end">Price</th>
          <th class="text-end">Total</th>
        </tr>
      </thead>
      <tbody>
        <?php 
        $grand = 0;
        while($row = $items->fetch_assoc()): 
            $line_total = $row['quantity'] * $row['price'];
            $grand += $line_total;
        ?>
        <tr>
          <td><?= htmlspecialchars($row['name']) ?></td>
          <td><?= (int)$row['quantity'] ?></td>
          <td><?= htmlspecialchars($row['unit']) ?></td>
          <td class="text-end"><?= number_format($row['price'],2) ?></td>
          <td class="text-end"><?= number_format($line_total,2) ?></td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>

    <div class="text-end">
      <p>Subtotal: <?= number_format($invoice['subtotal'],2) ?></p>
      <p>Discount: <?= number_format($invoice['discount'],2) ?></p>
      <p>Tax: <?= number_format($invoice['tax'],2) ?></p>
      <h4>Total: <?= number_format($invoice['total'],2) ?></h4>
      <p>Paid: <?= number_format($invoice['paid'],2) ?></p>
      <p>Due: <?= number_format($invoice['due'],2) ?></p>
    </div>
  </div>
</div>

<div class="mt-3">
  <button class="btn btn-success" onclick="printInvoice()">🖨️ Print</button>
  <button class="btn btn-danger" onclick="downloadPDF('<?= htmlspecialchars($invoice['invoice_no']) ?>')">📄 PDF</button>
  <a href="dashboard.php" class="btn btn-secondary">Dashboard</a>
</div>

<script>
function printInvoice() {
    const element = document.getElementById('invoice_view');
    const w = window.open('', '', 'height=800,width=1000');
    w.document.write('<html><head><title>Print Invoice</title>');
    w.document.write('<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">');
    w.document.write('</head><body>');
    w.document.write(element.innerHTML);
    w.document.write('</body></html>');
    w.document.close();
    w.print();
}

function downloadPDF(invoiceNo) {
    const element = document.getElementById('invoice_view');
    html2canvas(element).then(canvas => {
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jspdf.jsPDF('p', 'mm', 'a4');
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
        pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
        pdf.save(`Invoice_${invoiceNo}.pdf`);
    });
}
</script>

</body>
</html>
