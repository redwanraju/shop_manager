<?php
session_start();
include("db.php");
require_once 'auth.php';
start_secure_session();

if(!isset($_SESSION['user_id'])) exit("Unauthorized");
$user_id = $_SESSION['user_id'];

$conn = new mysqli($servername, $username, $password, $dbname);
$stmt = $conn->prepare("SELECT id, customer_name, total, paid, due, created_at FROM invoices WHERE user_id=? ORDER BY id DESC LIMIT 20");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$invoices = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

echo '<table class="table table-bordered table-hover text-center"><thead><tr><th>ID</th><th>Customer</th><th>Total</th><th>Paid</th><th>Due</th><th>Date</th></tr></thead><tbody>';
if(empty($invoices)) echo '<tr><td colspan="6">No invoices</td></tr>';
else foreach($invoices as $i) echo '<tr><td>'.$i['id'].'</td><td>'.htmlspecialchars($i['customer_name']).'</td><td>৳ '.number_format($i['total'],2).'</td><td>৳ '.number_format($i['paid'],2).'</td><td>৳ '.number_format($i['due'],2).'</td><td>'.$i['created_at'].'</td></tr>';
echo '</tbody></table>';
?>