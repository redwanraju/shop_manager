<?php
ob_start();
include("header.php");
include("db.php");
session_start();
require_once 'auth.php';

$errors = [];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // CSRF token verification
    if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
        $errors[] = "Invalid form submission!";
    } else {
        $email    = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($email === '' || $password === '') {
            $errors[] = "সব ঘর পূরণ করুন।";
        } else {
            $stmt = $conn->prepare("SELECT id, name, email, password_hash, access, trial_start FROM users WHERE email = ? LIMIT 1");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($user = $result->fetch_assoc()) {
                if (password_verify($password, $user['password_hash'])) {

                    // ট্রায়াল লজিক
                    $trial_days = 7; // ৭ দিনের ট্রায়াল
                    if ($user['trial_start']) {
                        $trial_end = strtotime($user['trial_start'] . " +{$trial_days} days");
                        if (time() > $trial_end && $user['access'] !== 'on') {
                            $errors[] = "আপনার ট্রায়াল শেষ হয়েছে। Admin এর সাথে যোগাযোগ করুন।";
                        }
                    }

                    if (empty($errors)) {
                        if ($user['access'] !== 'on') {
                            $errors[] = "আপনার অ্যাকাউন্ট বন্ধ আছে। Admin এর সাথে যোগাযোগ করুন।";
                        } else {
                            // সিকিওর সেশন শুরু
                            session_regenerate_id(true);
                            $_SESSION['user_id']   = $user['id'];
                            $_SESSION['user_name'] = $user['name'];
                            header("Location: dashboard.php");
                            exit;
                        }
                    }

                } else {
                    $errors[] = "পাসওয়ার্ড সঠিক নয়!";
                }
            } else {
                $errors[] = "কোনো ইউজার পাওয়া যায়নি!";
            }
            $stmt->close();
        }
    }
}

// CSRF token
$csrf = generate_csrf_token();
?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow-lg border-0 rounded-3">
                <div class="card-header text-center bg-primary text-white py-3">
                    <h4><i class="bi bi-person-circle me-2"></i> Login</h4>
                </div>
                <div class="card-body p-4">

                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger">
                            <?php foreach($errors as $e) echo htmlspecialchars($e) . "<br>"; ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" class="mt-2">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf) ?>">

                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                                <input type="email" name="email" class="form-control" placeholder="Enter your email" required>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="bi bi-lock"></i></span>
                                <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
                            </div>
                        </div>

                        <button class="btn btn-primary w-100">
                            <i class="bi bi-box-arrow-in-right me-1"></i> Login
                        </button>
                        <div class="text-center mt-3">
                            <small class="text-muted">Don't have an account?</small><br>
                            <a class="btn btn-outline-secondary btn-sm mt-2" href="signup.php">
                                <i class="bi bi-person-plus"></i> Register
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap Icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
<?php ob_end_flush(); ?>
<?php include("footer.php"); ?>