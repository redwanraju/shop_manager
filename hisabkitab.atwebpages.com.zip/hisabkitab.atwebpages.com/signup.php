<?php
session_start();
include("header.php");
include("db.php");
require_once 'auth.php';

$errors = [];
$success = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
        $errors[] = "Invalid form submission!";
    } else {
        $name     = trim($_POST['name'] ?? '');
        $email    = trim($_POST['email'] ?? '');
        $mobile   = trim($_POST['mobile'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm  = $_POST['confirm_password'] ?? '';

        if ($name === '' || $email === '' || $mobile === '' || $password === '' || $confirm === '') {
            $errors[] = "সব ঘর পূরণ করুন।";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "সঠিক ইমেইল দিন।";
        } elseif ($password !== $confirm) {
            $errors[] = "পাসওয়ার্ড মিলছে না।";
        } else {
            $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $res = $stmt->get_result();

            if ($res->num_rows > 0) {
                $errors[] = "ইমেইলটি ইতিমধ্যে রেজিস্টার্ড।";
            } else {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $insert = $conn->prepare("INSERT INTO users (name, email, mobile, access, trial_start, password_hash, created_at) VALUES (?, ?, ?, 'off', NOW(), ?, NOW())");
                $insert->bind_param("ssss", $name, $email, $mobile, $hash);
                if ($insert->execute()) {
                    $success = "রেজিস্ট্রেশন সফল। এখন লগইন করুন।";
                    $_POST = [];
                    $_SESSION['csrf_token'] = bin2hex(random_bytes(24));
                } else {
                    $errors[] = "রেজিস্ট্রেশন ব্যর্থ।";
                }
                $insert->close();
            }
            $stmt->close();
        }
    }
}

$csrf = generate_csrf_token();
?>

<div class="container mt-5">
    <div class="card mx-auto shadow" style="max-width: 500px; border-radius: 1rem;">
        <div class="card-header bg-primary text-white text-center py-4">
            <h3><i class="bi bi-person-plus-fill me-2"></i>Register</h3>
        </div>
        <div class="card-body p-4">
            <?php if (!empty($success)): ?>
                <div class="alert alert-success">
                    <i class="bi bi-check-circle-fill me-2"></i><?= htmlspecialchars($success) ?>
                </div>
            <?php endif; ?>
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <?php foreach($errors as $e) echo '<i class="bi bi-exclamation-triangle-fill me-2"></i>'.htmlspecialchars($e)."<br>"; ?>
                </div>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf) ?>">

                <div class="mb-3">
                    <label class="form-label"><i class="bi bi-shop me-1"></i> দোকানের নাম</label>
                    <input type="text" name="name" class="form-control" placeholder="আপনার দোকানের নাম" required value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label"><i class="bi bi-envelope-fill me-1"></i> ইমেইল</label>
                    <input type="email" name="email" class="form-control" placeholder="আপনার ইমেইল" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label"><i class="bi bi-telephone-fill me-1"></i> মোবাইল নাম্বার</label>
                    <input type="text" name="mobile" class="form-control" placeholder="মোবাইল নাম্বার" required value="<?= htmlspecialchars($_POST['mobile'] ?? '') ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label"><i class="bi bi-lock-fill me-1"></i> পাসওয়ার্ড</label>
                    <input type="password" name="password" class="form-control" placeholder="পাসওয়ার্ড" required>
                </div>

                <div class="mb-3">
                    <label class="form-label"><i class="bi bi-lock-fill me-1"></i> পুনরায় পাসওয়ার্ড</label>
                    <input type="password" name="confirm_password" class="form-control" placeholder="পুনরায় পাসওয়ার্ড" required>
                </div>

                <button type="submit" class="btn btn-primary w-100 mb-2"><i class="bi bi-person-plus-fill me-2"></i>Register</button>

                <div class="text-center">
                    <small class="text-muted">Or</small><br>
                    <a class="btn btn-outline-secondary btn-sm mt-2" href="login.php"><i class="bi bi-box-arrow-in-right me-1"></i>Login</a>
                </div>
            </form>
        </div>
    </div>
</div>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
<?php include("footer.php"); ?>