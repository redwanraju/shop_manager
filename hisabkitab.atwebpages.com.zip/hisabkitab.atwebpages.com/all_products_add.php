<?php
session_start();
include("db.php");
require_once 'auth.php';
start_secure_session();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch all products
$stmt = $conn->prepare("SELECT id, name, price, stock, unit FROM products WHERE user_id=? ORDER BY name ASC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$res = $stmt->get_result();
$products = [];
while ($row = $res->fetch_assoc()) $products[] = $row;
$stmt->close();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Purchase Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body class="container py-4">

<h2>🧾 Add Purchase</h2>

<form id="purchase_form">
    <div class="mb-3">
        <label><strong>Supplier Name:</strong></label>
        <input type="text" name="supplier_name" class="form-control" required>
    </div>

    <table class="table table-bordered" id="purchase_table">
        <thead class="table-dark">
            <tr>
                <th>Product</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Total</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody></tbody>
    </table>

    <button type="button" class="btn btn-primary" id="add_row">➕ Add Product</button>

    <div class="text-end mt-3">
        <h4>Total Amount: <span id="grand_total">0.00</span></h4>
    </div>

    <button type="submit" class="btn btn-success mt-3">💾 Save Purchase</button>
</form>

<script>
let products = <?= json_encode($products) ?>;
let rowCount = 0;

// Add row
$('#add_row').on('click', function(){
    let options = products.map(p => <option value="${p.id}" data-price="${p.price}">${p.name}</option>).join('');
    let row = `
    <tr>
        <td><select name="product_id[]" class="form-select product_select" required><option value="">Select</option>${options}</select></td>
        <td><input type="number" name="quantity[]" class="form-control quantity" min="1" value="1" required></td>
        <td><input type="number" name="price[]" class="form-control price" step="0.01" min="0" required></td>
        <td class="line_total">0.00</td>
        <td><button type="button" class="btn btn-danger btn-sm remove_row">🗑</button></td>
    </tr>`;
    $('#purchase_table tbody').append(row);
    updateTotal();
});

// Remove row
$(document).on('click', '.remove_row', function(){
    $(this).closest('tr').remove();
    updateTotal();
});

// Auto price fill
$(document).on('change', '.product_select', function(){
    let price = $(this).find(':selected').data('price') || 0;
    $(this).closest('tr').find('.price').val(price);
    updateTotal();
});

// Quantity or price change
$(document).on('input', '.quantity, .price', updateTotal);

function updateTotal(){
    let grand = 0;
    $('#purchase_table tbody tr').each(function(){
        let qty = parseFloat($(this).find('.quantity').val()) || 0;
        let price = parseFloat($(this).find('.price').val()) || 0;
        let total = qty * price;
        $(this).find('.line_total').text(total.toFixed(2));
        grand += total;
    });
    $('#grand_total').text(grand.toFixed(2));
}

// Submit form
$('#purchase_form').submit(function(e){
    e.preventDefault();
    $.post('purchase_save.php', $(this).serialize(), function(resp){
        if(resp.status==1){
            alert('✅ Purchase saved successfully!');
            location.reload();
        } else {
            alert('❌ '+resp.message);
        }
    }, 'json');
});
</script>
</body>
</html>