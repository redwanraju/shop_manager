<?php
include("db.php");
require_once 'auth.php';
start_secure_session();

// ইউজার লগইন চেক
if(!isset($_SESSION['user_id'])) {
    echo json_encode([]);
    exit;
}

$user_id = $_SESSION['user_id'];
$today = date('Y-m-d');
$this_month_start = date('Y-m-01');
$this_month_end = date('Y-m-t');



// সেফ ফাংশন: prepared statement ব্যবহার
function queryValue($conn, $sql, $types, $params, $default=0){
    $stmt = $conn->prepare($sql);
    if($stmt){
        if(!empty($params)){
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return array_values($res)[0] ?? $default;
    }
    return $default;
}

// ইউজার-বেসড ড্যাশবোর্ড ডেটা
$data = [
    'today_sales' => floatval(queryValue($conn, "SELECT SUM(total) FROM invoices WHERE user_id=? AND DATE(created_at)=?", "is", [$user_id, $today])),
    'month_sales' => floatval(queryValue($conn, "SELECT SUM(total) FROM invoices WHERE user_id=? AND DATE(created_at) BETWEEN ? AND ?", "iss", [$user_id, $this_month_start, $this_month_end])),
    'today_cash' => floatval(queryValue($conn, "SELECT SUM(paid) FROM invoices WHERE user_id=? AND DATE(created_at)=?", "is", [$user_id, $today])),
    'today_due' => floatval(queryValue($conn, "SELECT SUM(due) FROM invoices WHERE user_id=? AND DATE(created_at)=?", "is", [$user_id, $today])),
    'total_invoices' => intval(queryValue($conn, "SELECT COUNT(*) FROM invoices WHERE user_id=?", "i", [$user_id])),
    'total_products' => intval(queryValue($conn, "SELECT COUNT(*) FROM products WHERE user_id=?", "i", [$user_id])),
    'low_stock' => intval(queryValue($conn, "SELECT COUNT(*) FROM products WHERE user_id=? AND stock < min_stock", "i", [$user_id])),
    'total_due' => floatval(queryValue($conn, "SELECT SUM(due) FROM invoices WHERE user_id=?", "i", [$user_id]))
];



?>
