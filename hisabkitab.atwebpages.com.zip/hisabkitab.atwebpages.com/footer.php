<?php
// includes/footer.php
?>
</div> <!-- .container -->
<footer>
    <div class="container">
        <p class="mb-0">© <?= date("Y") ?> Shop Manager | Developed with ❤</p>
    </div>
</footer>

<!-- Bootstrap JS -->


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="/js/main.js"></script>
</body>
</html>
