<?php
$servername = "fdb1033.awardspace.net";  // Database Host
$username   = "4691882_shop";            // Database Username
$password   = "Mdredwan@001"; // Database Password
$dbname     = "4691882_shop";            // Database Name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("❌ Connection failed: " . $conn->connect_error);
}
?>