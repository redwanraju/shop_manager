<?php
// === Database Information (AwardSpace থেকে কপি করো) ===
$servername = "fdb1033.awardspace.net";  // Database Host
$username   = "4691882_shop";            // Database Username
$password   = "Mdredwan@001"; // Database Password
$dbname     = "4691882_shop";            // Database Name

echo "<h2>🔍 AwardSpace Database Connection Test</h2>";

try {
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        throw new Exception("❌ Connection failed: " . $conn->connect_error);
    } else {
        echo "<p style='color:green;'>✅ Database connected successfully!</p>";
    }

    // Try to fetch something (optional)
    $result = $conn->query("SHOW TABLES");
    if ($result && $result->num_rows > 0) {
        echo "<p>📋 Tables found in your database:</p><ul>";
        while ($row = $result->fetch_array()) {
            echo "<li>" . htmlspecialchars($row[0]) . "</li>";
        }
        echo "</ul>";
    } else {
        echo "<p style='color:gray;'>ℹ No tables found yet in your database.</p>";
    }

    $conn->close();

} catch (Exception $e) {
    echo "<p style='color:red;'>" . $e->getMessage() . "</p>";
}

echo "<hr><small>Made for AwardSpace by ChatGPT 🧠</small>";
?>