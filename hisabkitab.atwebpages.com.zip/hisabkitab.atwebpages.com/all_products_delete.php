<?php
session_start();
include("db.php");
require_once 'auth.php';
start_secure_session();
header('Content-Type: application/json');
if(!isset($_SESSION['user_id'])) exit(json_encode(['status'=>0,'message'=>'Not logged in']));

$user_id=$_SESSION['user_id'];
$id=intval($_POST['id']??0);
if($id<=0) exit(json_encode(['status'=>0,'message'=>'Invalid product ID']));

$stmt=$conn->prepare("DELETE FROM products WHERE id=? AND user_id=?");
$stmt->bind_param("ii",$id,$user_id);
if($stmt->execute()) echo json_encode(['status'=>1,'message'=>'Deleted']);
else echo json_encode(['status'=>0,'message'=>'Database error']);
$stmt->close();