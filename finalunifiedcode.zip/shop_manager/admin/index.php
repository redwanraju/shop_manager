<?php
session_start();
require_once "../config/db.php";

// শুধুমাত্র এডমিন (id=1) প্রবেশ করতে পারবে
if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] != 1) {
    header("Location: ../admin/access_denied.php");
    exit;
}

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("DB Connection Failed: " . $conn->connect_error);

$result = $conn->query("SELECT id, name, email, mobile, access, trial_start FROM users ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - User Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; }
        .navbar { background: linear-gradient(45deg, #0d6efd, #0b5ed7); }
        .navbar-brand, .nav-link { color: #fff !important; }
        .card { border-radius: 1rem; }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="index.php">
            <i class="bi bi-shield-lock"></i> Admin Panel
        </a>
		<a class="navbar-brand" href="../public/dashboard.php">
            <i class="bi bi-shield-lock"></i> dashboard
        </a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link text-danger" href="../public/logout.php">
                        <i class="bi bi-box-arrow-right"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <div class="card shadow-sm">
        <div class="card-body">
            <h4 class="mb-3"><i class="bi bi-people"></i> All Users</h4>

            <table class="table table-striped table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Mobile</th>
                        <th>Trial Start</th>
                        <th>Trial End</th>
                        <th>Days Left</th>
                        <th>Access</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php while($row = $result->fetch_assoc()): 
                    $trial_start = $row['trial_start'];
                    $trial_end = $trial_start ? date("Y-m-d", strtotime($trial_start . " +7 days")) : "N/A";
                    $days_left = "N/A";

                    if ($trial_start) {
                        $today = new DateTime();
                        $end = new DateTime($trial_end);
                        $interval = $today->diff($end);
                        $days_left = ($end >= $today) ? $interval->days . " days" : "Expired";
                    }
                ?>
                    <tr>
                        <td><?= $row['id'] ?></td>
                        <td><?= htmlspecialchars($row['name']) ?></td>
                        <td><?= htmlspecialchars($row['email']) ?></td>
                        <td><?= htmlspecialchars($row['mobile']) ?></td>
                        <td><?= $trial_start ?: 'N/A' ?></td>
                        <td><?= $trial_end ?></td>
                        <td>
                            <?php if ($days_left === "Expired"): ?>
                                <span class="badge bg-danger">Expired</span>
                            <?php else: ?>
                                <span class="badge bg-primary"><?= $days_left ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($row['access'] == "on"): ?>
                                <span class="badge bg-success">ON</span>
                            <?php else: ?>
                                <span class="badge bg-danger">OFF</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="toggle_access.php?id=<?= $row['id'] ?>" 
                               class="btn btn-sm btn-warning">
                               <i class="bi bi-toggle-on"></i> Toggle
                            </a>
                        </td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>