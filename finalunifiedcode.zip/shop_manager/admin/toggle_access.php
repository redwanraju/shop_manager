<?php
session_start();
require_once "../config/db.php";

// শুধু এডমিন (id=1) প্রবেশ করতে পারবে
if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] != 1) {
    header("Location: ../admin/access_denied.php");
    exit;
}

if (isset($_GET['id'])) {
    $user_id = intval($_GET['id']);

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) die("DB Connection Failed: " . $conn->connect_error);

    // ইউজারের বর্তমান access অবস্থা বের করা
    $stmt = $conn->prepare("SELECT access FROM users WHERE id=?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($res) {
        $new_status = ($res['access'] === "on") ? "off" : "on";

        $stmt = $conn->prepare("UPDATE users SET access=? WHERE id=?");
        $stmt->bind_param("si", $new_status, $user_id);
        $stmt->execute();
        $stmt->close();
    }

    $conn->close();
}

// কাজ শেষে আবার admin/index.php তে ফেরত পাঠানো হবে
header("Location: index.php");
exit;