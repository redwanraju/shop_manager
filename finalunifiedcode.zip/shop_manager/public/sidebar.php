<?php
//session_start();
include("../config/db.php");
require_once '../includes/auth.php';
start_secure_session();
//$user_id = $_SESSION['user_id'] ?? 0;
if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$user_id = $_SESSION['user_id'];

 ?>

<aside class="main-sidebar sidebar-dark-primary elevation-4">
  <a href="#" class="brand-link text-center">
    <span class="brand-text font-weight-light"><i class="fa-solid fa-store"></i> MyERP</span>
  </a>
  <div class="sidebar">
    <div class="user-panel mt-3 pb-3 mb-3 d-flex">
      <div class="info"><a href="#" class="d-block"><?= htmlspecialchars($_SESSION['user_name'] ?? 'User') ?></a></div>
    </div>
    <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column">
        <li class="nav-item"><a href="javascript:void(0)" class="nav-link active" onclick="AjaxSummary()"><i class="nav-icon fas fa-tachometer-alt"></i><p>Dashboard</p></a></li>
        <li class="nav-item"><a href="javascript:void(0)" onclick="showProducts()" class="nav-link"><i class="nav-icon fas fa-box"></i><p>Products</p></a></li>
        <li class="nav-item"><a href="javascript:void(0)" onclick="showInvoiceForm()" class="nav-link"><i class="nav-icon fas fa-file-invoice"></i><p>Create Invoice</p></a></li>
        <li class="nav-item"><a href="javascript:void(0)" onclick="totalInvoices()" class="nav-link"><i class="nav-icon fas fa-file-invoice"></i><p>All Invoices</p></a></li>
		<li class="nav-item"><a href="javascript:void(0)" onclick="stockLow()" class="nav-link"><i class="nav-icon fas fa-file-invoice"></i><p>Stock Low Products</p></a></li>
      </ul>
    </nav>
  </div>
</aside>