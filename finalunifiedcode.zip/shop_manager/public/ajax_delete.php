<?php
session_start();
include("../config/db.php");
require_once '../includes/auth.php';
start_secure_session();

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access!']);
    exit;
}

$user_id = $_SESSION['user_id'];
$invoice_no = $_POST['delete_invoice'] ?? '';

if ($invoice_no == '') {
    echo json_encode(['success' => false, 'message' => 'Invalid invoice number.']);
    exit;
}

// ✅ প্রথমে invoice id বের করা
$stmt = $conn->prepare("SELECT id FROM invoices WHERE invoice_no=? AND user_id=?");
$stmt->bind_param("si", $invoice_no, $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Invoice not found or not authorized.']);
    exit;
}
$invoice = $result->fetch_assoc();
$invoice_id = $invoice['id'];
$stmt->close();

// ✅ invoice_items মুছে ফেলা
$stmt_items = $conn->prepare("DELETE FROM invoice_items WHERE invoice_id=?");
$stmt_items->bind_param("i", $invoice_id);
$stmt_items->execute();
$stmt_items->close();

// ✅ invoices থেকে মুছে ফেলা
$stmt_inv = $conn->prepare("DELETE FROM invoices WHERE id=? AND user_id=?");
$stmt_inv->bind_param("ii", $invoice_id, $user_id);
$deleted = $stmt_inv->execute();
$stmt_inv->close();

if ($deleted) {
    echo json_encode(['success' => true, 'message' => 'Invoice deleted successfully.']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to delete invoice.']);
}
?>
