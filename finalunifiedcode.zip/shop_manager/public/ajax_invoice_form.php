<?php
session_start();
include("../config/db.php");
require_once '../includes/auth.php';
start_secure_session();
//$user_id = $_SESSION['user_id'] ?? 0;
if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

//$user_id = $_SESSION['user_id'] ?? 0;
$csrf_token = $_POST['csrf_token'] ?? '';

if (!isset($_SESSION['csrf_token']) || $csrf_token !== $_SESSION['csrf_token']) {
    echo json_encode(['success' => false, 'message' => 'Invalid CSRF token']);
    exit;
}

$customer_name = trim($_POST['customer_name'] ?? '');
$product_ids   = $_POST['product_id'] ?? [];
$quantities    = $_POST['quantity'] ?? [];
$prices        = $_POST['price'] ?? [];

if ($customer_name === '' || count($product_ids) === 0) {
    echo json_encode(['success' => false, 'message' => 'Customer name and products are required.']);
    exit;
}

// গণনা (subtotal + total)
$subtotal = 0;
for ($i = 0; $i < count($product_ids); $i++) {
    $subtotal += floatval($prices[$i]) * intval($quantities[$i]);
}
$total = $subtotal;

// ইনভয়েস নাম্বার
$invoice_no = "INV-" . time();

$conn->begin_transaction();

try {
    // ইনভয়েস ইনসার্ট
    $stmt = $conn->prepare("INSERT INTO invoice (user_id, invoice_no, date, subtotal, total, created_at) VALUES (?, ?, NOW(), ?, ?, NOW())");
    $stmt->bind_param("isdd", $user_id, $invoice_no, $subtotal, $total);
    $stmt->execute();
    $invoice_id = $stmt->insert_id;
    $stmt->close();

    // ইনভয়েস আইটেম ইনসার্ট
    $stmt2 = $conn->prepare("INSERT INTO invoice_item (invoice_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
    for ($i = 0; $i < count($product_ids); $i++) {
        $pid = intval($product_ids[$i]);
        $qty = intval($quantities[$i]);
        $price = floatval($prices[$i]);
        $stmt2->bind_param("iiid", $invoice_id, $pid, $qty, $price);
        $stmt2->execute();

        // প্রোডাক্ট স্টক কমানো
        $conn->query("UPDATE products SET stock = stock - $qty WHERE id=$pid AND user_id=$user_id");
    }
    $stmt2->close();

    $conn->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Invoice created successfully!',
        'invoice_no' => $invoice_no
    ]);
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}
?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  // আগের সব ফাংশন, যেমন makeOptionsHtml(), attachListeners() ইত্যাদি থাকবে এখানে

  // 👇 এই অংশটা একদম নিচে থাকবে
  $('#invoice_form').submit(function(e){
    e.preventDefault(); // ফর্ম সাবমিট থামাও
    $.post('ajax_save_invoice.php', $(this).serialize(), function(data){
      alert(data.message);
      if(data.success){
        $('#invoice_form')[0].reset();
        $('#invoice_table tbody').html('');
        updateGrandTotal();
      }
    }, 'json');
  });
</script>