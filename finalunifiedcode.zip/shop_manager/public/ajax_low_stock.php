<?php
session_start();
include("../config/db.php");
require_once '../includes/auth.php';
start_secure_session();
//$user_id = $_SESSION['user_id'] ?? 0;
if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$user_id = $_SESSION['user_id'];


$low_products = [];
$stmt = $conn->prepare("SELECT name, stock, min_stock FROM products WHERE user_id=? AND stock<=min_stock ORDER BY stock ASC LIMIT 5");
$stmt->bind_param("i",$user_id);
$stmt->execute();
$low_products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<div class="card">
  <div class="card-header bg-danger text-white">
    <h5 class="card-title">Low Stock Alerts</h5>
  </div>
  <div class="card-body table-responsive">
    <table class="table table-hover text-center">
      <thead><tr><th>Product</th><th>Stock</th><th>Min Stock</th></tr></thead>
      <tbody>
        <?php if(empty($low_products)): ?>
        <tr><td colspan="3">No low stock products ✅</td></tr>
        <?php else: foreach($low_products as $p): ?>
        <tr>
          <td><?=htmlspecialchars($p['name'])?></td>
          <td><?=$p['stock']?></td>
          <td><?=$p['min_stock']?></td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>