<?php
session_start();
include("../config/db.php");
require_once '../includes/auth.php';
start_secure_session();
//$user_id = $_SESSION['user_id'] ?? 0;
if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$user_id = $_SESSION['user_id'];

//$user_id = $_SESSION['user_id'] ?? 0;

// Validate request method
if($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success'=>false,'message'=>'Invalid request method']);
    exit;
}

// Validate CSRF
if(!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']){
    echo json_encode(['success'=>false,'message'=>'Invalid CSRF token']);
    exit;
}

// Collect data
$customer_name = trim($_POST['customer_name'] ?? '');
$product_ids = $_POST['product_id'] ?? [];
$quantities = $_POST['quantity'] ?? [];
$prices = $_POST['price'] ?? [];
$discount = floatval($_POST['discount'] ?? 0);
$paid = floatval($_POST['paid'] ?? 0);

if($customer_name === ''){
    echo json_encode(['success'=>false,'message'=>'Customer name is required']);
    exit;
}

$n = count($product_ids);
if($n === 0){
    echo json_encode(['success'=>false,'message'=>'Add at least one product']);
    exit;
}

$items = [];
for($i=0; $i<$n; $i++){
    $pid = intval($product_ids[$i]);
    $qty = intval($quantities[$i]);
    $price = floatval($prices[$i]);
    if($pid > 0 && $qty > 0) $items[] = ['product_id'=>$pid,'qty'=>$qty,'price'=>$price];
}

if(count($items) == 0){
    echo json_encode(['success'=>false,'message'=>'No valid items provided']);
    exit;
}

$conn->begin_transaction();

try {
    // Create invoice
    $invoice_no = "INV".time();
    $stmt = $conn->prepare("INSERT INTO invoices (invoice_no, created_at, user_id, customer_name) VALUES (?, NOW(), ?, ?)");
    $stmt->bind_param("sis", $invoice_no, $user_id, $customer_name);
    $stmt->execute();
    $invoice_id = $conn->insert_id;
    $stmt->close();

    $subtotal = 0;

    // Prepare statements
    $select_product_stmt = $conn->prepare("SELECT stock, min_stock, name FROM products WHERE id=? FOR UPDATE");
    $insert_item_stmt = $conn->prepare("INSERT INTO invoice_items (invoice_id, product_id, quantity, price) VALUES (?,?,?,?)");
    $update_stock_stmt = $conn->prepare("UPDATE products SET stock=stock-? WHERE id=?");

    foreach($items as $it){
        $pid = $it['product_id'];
        $qty = $it['qty'];
        $price = $it['price'];

        $select_product_stmt->bind_param("i",$pid);
        $select_product_stmt->execute();
        $prod = $select_product_stmt->get_result()->fetch_assoc();
        if(!$prod) throw new Exception("Product not found: $pid");

        $current_stock = intval($prod['stock']);
        $min_stock = intval($prod['min_stock']);
        if($qty > $current_stock) $qty = $current_stock;

        if($qty <= 0) continue;

        // Insert invoice item
        $insert_item_stmt->bind_param("iiid",$invoice_id,$pid,$qty,$price);
        $insert_item_stmt->execute();

        // Update product stock
        $update_stock_stmt->bind_param("ii",$qty,$pid);
        $update_stock_stmt->execute();

        $subtotal += $qty * $price;
    }

    $select_product_stmt->close();
    $insert_item_stmt->close();
    $update_stock_stmt->close();

    // Calculate totals
    $total = max($subtotal - $discount, 0);
    $due = max($total - $paid, 0);

    // Update invoice totals
    $stmt = $conn->prepare("UPDATE invoices SET subtotal=?, discount=?, total=?, paid=?, due=? WHERE id=?");
    $stmt->bind_param("dddddi",$subtotal,$discount,$total,$paid,$due,$invoice_id);
    $stmt->execute();
    $stmt->close();

    $conn->commit();

    // Reset CSRF token
    $_SESSION['csrf_token'] = bin2hex(random_bytes(24));

    echo json_encode([
        'success'=>true,
        'message'=>"Invoice created successfully (Invoice No: $invoice_no)",
        'invoice_id'=>$invoice_id,
        'invoice_no'=>$invoice_no
    ]);

} catch(Exception $e){
    $conn->rollback();
    echo json_encode(['success'=>false,'message'=>"Transaction failed: ".$e->getMessage()]);
}
?>
