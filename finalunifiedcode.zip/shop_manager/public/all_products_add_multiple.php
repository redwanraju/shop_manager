<?php
session_start();
include("../config/db.php");
require_once '../includes/auth.php';
start_secure_session();
header('Content-Type: application/json');

if(!isset($_SESSION['user_id'])) exit(json_encode(['status'=>0,'message'=>'Not logged in']));
$user_id = $_SESSION['user_id'];

$names = $_POST['name'] ?? [];
$stocks = $_POST['stock'] ?? [];
$prices = $_POST['price'] ?? [];
$units = $_POST['unit'] ?? [];

if(count($names)==0) exit(json_encode(['status'=>0,'message'=>'No products to add']));

$conn->begin_transaction();
try {
    $stmt = $conn->prepare("INSERT INTO products (user_id,name,stock,price,unit) VALUES (?,?,?,?,?)");
    foreach($names as $i=>$name){
        $stock = intval($stocks[$i]??0);
        $price = floatval($prices[$i]??0);
        $unit = trim($units[$i]??'');
        $stmt->bind_param("isdds", $user_id, $name, $stock, $price, $unit);
        $stmt->execute();
    }
    $stmt->close();
    $conn->commit();
    echo json_encode(['status'=>1,'message'=>'Products added successfully']);
} catch(Exception $e){
    $conn->rollback();
    echo json_encode(['status'=>0,'message'=>'Database error: '.$e->getMessage()]);
}