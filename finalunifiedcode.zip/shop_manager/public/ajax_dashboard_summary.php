<?php
session_start();
include("../config/db.php");
require_once '../includes/auth.php';
start_secure_session();

if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$user_id = $_SESSION['user_id'];

// 🔹 Helper function
function fetch_value($conn,$query,$user_id){
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i",$user_id);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_row();
    $stmt->close();
    return $res[0] ?? 0;
}

// 🔹 বিক্রির হিসাব (invoices)
$total_today = fetch_value($conn,"SELECT SUM(total) FROM invoices WHERE user_id=? AND DATE(created_at)=CURDATE()", $user_id);
$cash_today  = fetch_value($conn,"SELECT SUM(paid) FROM invoices WHERE user_id=? AND DATE(created_at)=CURDATE()", $user_id);
$due_today   = fetch_value($conn,"SELECT SUM(due) FROM invoices WHERE user_id=? AND DATE(created_at)=CURDATE()", $user_id);
$total_all   = fetch_value($conn,"SELECT SUM(total) FROM invoices WHERE user_id=?", $user_id);

// 🔹 এ মাসের বিক্রি
$sales_month = fetch_value($conn,"SELECT SUM(total) FROM invoices WHERE user_id=? AND MONTH(created_at)=MONTH(CURDATE()) AND YEAR(created_at)=YEAR(CURDATE())", $user_id);

// 🔹 পারচেজ হিসাব (products টেবিল থেকে)
$purchase_today = fetch_value($conn,"SELECT SUM(quantity * price) FROM products WHERE user_id=? AND DATE(created_at)=CURDATE()", $user_id);
$purchase_prev  = fetch_value($conn,"SELECT SUM(quantity * price) FROM products WHERE user_id=? AND DATE(created_at)<CURDATE()", $user_id);
$purchase_month = fetch_value($conn,"SELECT SUM(quantity * price) FROM products WHERE user_id=? AND MONTH(created_at)=MONTH(CURDATE()) AND YEAR(created_at)=YEAR(CURDATE())", $user_id);
$total_purchase = fetch_value($conn,"SELECT SUM(quantity * price) FROM products WHERE user_id=?", $user_id);
// 🔹 ইনভয়েস সংখ্যা (invoices টেবিল)
$invoice_today = fetch_value($conn,"SELECT COUNT(*) FROM invoices WHERE user_id=? AND DATE(created_at)=CURDATE()", $user_id);
$total_invoice = fetch_value($conn,"SELECT COUNT(*) FROM invoices WHERE user_id=?", $user_id);
?>

<!-- 🔹 বিক্রির সারাংশ -->
<div class="row">
  <div class="col-lg-3 col-6">
    <div class="small-box bg-info">
      <div class="inner">
        <h3>৳<?=number_format($cash_today,2)?></h3>
        <p>আজকের ক্যাশ</p>
      </div>
      <div class="icon"><i class="fas fa-wallet"></i></div>
    </div>
  </div>

  <div class="col-lg-3 col-6">
    <div class="small-box bg-danger">
      <div class="inner">
        <h3>৳<?=number_format($due_today,2)?></h3>
        <p>আজকের ডিউ</p>
      </div>
      <div class="icon"><i class="fas fa-exclamation-triangle"></i></div>
    </div>
  </div>

  <div class="col-lg-3 col-6">
    <div class="small-box bg-primary">
      <div class="inner">
        <h3>৳<?=number_format($total_today,2)?></h3>
        <p>আজকের বিক্রি</p>
      </div>
      <div class="icon"><i class="fas fa-coins"></i></div>
    </div>
  </div>
  <div class="col-lg-3 col-6">
    <div class="small-box bg-primary">
      <div class="inner">
        <h3>৳<?=number_format($sales_month,2)?></h3>
        <p>এ মাসের বিক্রি</p>
      </div>
      <div class="icon"><i class="fas fa-chart-bar"></i></div>
    </div>
  </div>
  <div class="col-lg-3 col-6">
    <div class="small-box bg-success">
      <div class="inner">
        <h3>৳<?=number_format($total_all,2)?></h3>
        <p>সর্বমোট বিক্রি</p>
      </div>
      <div class="icon"><i class="fas fa-chart-line"></i></div>
    </div>
  </div>


<!-- 🔹 পারচেজ সারাংশ -->

  <div class="col-lg-3 col-6">
    <div class="small-box bg-warning">
      <div class="inner">
        <h3>৳<?=number_format($purchase_today,2)?></h3>
        <p>আজকের পারচেজ</p>
      </div>
      <div class="icon"><i class="fas fa-shopping-cart"></i></div>
    </div>
  </div>

  <div class="col-lg-3 col-6">
    <div class="small-box bg-secondary">
      <div class="inner">
        <h3>৳<?=number_format($purchase_prev,2)?></h3>
        <p>আগের পারচেজ</p>
      </div>
      <div class="icon"><i class="fas fa-history"></i></div>
    </div>
  </div>

  <div class="col-lg-3 col-6">
    <div class="small-box bg-info">
      <div class="inner">
        <h3>৳<?=number_format($purchase_month,2)?></h3>
        <p>এ মাসের পারচেজ</p>
      </div>
      <div class="icon"><i class="fas fa-calendar-day"></i></div>
    </div>
  </div>

  <div class="col-lg-3 col-6">
    <div class="small-box bg-success">
      <div class="inner">
        <h3>৳<?=number_format($total_purchase,2)?></h3>
        <p>মোট পারচেজ</p>
      </div>
      <div class="icon"><i class="fas fa-layer-group"></i></div>
    </div>
  </div>
  <!-- 🔹 ইনভয়েস সারাংশ -->

  <div class="col-lg-3 col-6">
    <div class="small-box bg-dark">
      <div class="inner">
        <h3><?=number_format($invoice_today)?></h3>
        <p>আজকের ইনভয়েস</p>
      </div>
      <div class="icon"><i class="fas fa-file-invoice"></i></div>
    </div>
  </div>

  <div class="col-lg-3 col-6">
    <div class="small-box bg-secondary">
      <div class="inner">
        <h3><?=number_format($total_invoice)?></h3>
        <p>মোট ইনভয়েস</p>
      </div>
      <div class="icon"><i class="fas fa-file-invoice-dollar"></i></div>
    </div>
  </div>

</div>
