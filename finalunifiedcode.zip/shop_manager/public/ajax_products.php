<?php
session_start();
include("../config/db.php");
require_once '../includes/auth.php';
start_secure_session();
//$user_id = $_SESSION['user_id'] ?? 0;
if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$user_id = $_SESSION['user_id'];

//$user_id = $_SESSION['user_id'] ?? 0;

// Fetch all products for this user
$products = [];
$stmt = $conn->prepare("SELECT id, name, stock, unit, price, min_stock FROM products WHERE user_id=? ORDER BY name ASC");
$stmt->bind_param("i",$user_id);
$stmt->execute();
$products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<div class="card">
  <div class="card-header bg-info text-white">
    <h5 class="card-title">All Products</h5>
  </div>
  <div class="card-body table-responsive">
    <table class="table table-bordered table-hover">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Price</th>
          <th>Stock</th>
          <th>Unit</th>
          <th>Min Stock</th>
        </tr>
      </thead>
      <tbody>
        <?php if(empty($products)): ?>
          <tr><td colspan="6" class="text-center">No products found</td></tr>
        <?php else: foreach($products as $p): ?>
          <tr>
            <td><?= $p['id'] ?></td>
            <td><?= htmlspecialchars($p['name']) ?></td>
            <td><?= number_format($p['price'],2) ?></td>
            <td><?= $p['stock'] ?></td>
            <td><?= htmlspecialchars($p['unit']) ?></td>
            <td><?= $p['min_stock'] ?></td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>