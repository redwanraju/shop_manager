let products = <?= json_encode($prod_array, JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>;

function makeOptionsHtml(){
    let out='<option value="">-- Select product --</option>';
    products.forEach(p=>{
        out+=`<option value="${p.id}" data-price="${p.price}" data-stock="${p.stock}" data-unit="${p.unit}">${p.name} (Stock: ${p.stock} ${p.unit})</option>`;
    });
    return out;
}