<?php
session_start();
include("../config/db.php");
include("../includes/header.php");
require_once '../includes/auth.php';
start_secure_session();

if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$stmt = $conn->prepare("SELECT name, email FROM users WHERE id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$res = $stmt->get_result();
if($res->num_rows > 0){
    $user = $res->fetch_assoc();
} else {
    die("User not found");
}
$stmt->close();

$success_msg = '';
$error_msg = '';

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $name = $_POST['name'] ?? '';

    // Profile Pic Upload
    if(isset($_FILES['profile_pic']) && $_FILES['profile_pic']['size'] > 0){
        $target_dir = "../uploads/profile/";
        if(!is_dir($target_dir)) mkdir($target_dir, 0755, true);

        $file_ext = strtolower(pathinfo($_FILES['profile_pic']['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg','jpeg','png','gif'];
        if(!in_array($file_ext, $allowed)){
            $error_msg = "Invalid file type for profile picture";
        } else {
            $filename = "user_".$user_id.".".$file_ext;
            $target_file = $target_dir.$filename;
            if(move_uploaded_file($_FILES['profile_pic']['tmp_name'], $target_file)){
                $profile_pic_path = "uploads/profile/".$filename;
                $stmt = $conn->prepare("UPDATE users SET profile_pic=? WHERE id=?");
                $stmt->bind_param("si",$profile_pic_path,$user_id);
                $stmt->execute();
                $stmt->close();
                $_SESSION['profile_pic'] = $profile_pic_path;
                $user['profile_pic'] = $profile_pic_path;
            } else {
                $error_msg = "Failed to upload profile picture";
            }
        }
    }

    // Password Update
    if(!empty($_POST['new_password']) && !empty($_POST['current_password'])){
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];

        $stmt = $conn->prepare("SELECT password_hash FROM users WHERE id=?");
        $stmt->bind_param("i",$user_id);
        $stmt->execute();
        $res2 = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if(password_verify($current_password,$res2['password_hash'])){
            $hashed = password_hash($new_password,PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET password_hash=? WHERE id=?");
            $stmt->bind_param("si",$hashed,$user_id);
            $stmt->execute();
            $stmt->close();
            $success_msg = "Profile and password updated successfully!";
        } else {
            $error_msg = "Current password is incorrect";
        }
    } else {
        $success_msg = "Profile updated successfully!";
    }

    // Name Update
    $stmt = $conn->prepare("UPDATE users SET name=? WHERE id=?");
    $stmt->bind_param("si",$name,$user_id);
    $stmt->execute();
    $stmt->close();

    $user['name'] = $name;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Profile</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<style>
body { background-color: #f4f6f9; font-family: 'Segoe UI', sans-serif; transition: background 0.3s, color 0.3s;}
.dark-mode { background-color: #1e1e2f; color: #e4e6eb; }
.profile-wrapper { max-width: 800px; margin: 60px auto; }
.profile-card { padding: 30px; border-radius: 1rem; background: #fff; box-shadow:0 6px 25px rgba(0,0,0,0.1); transition: 0.3s; }
.dark-mode .profile-card { background: #2c2c3e; }
.profile-img { width:130px; height:130px; border-radius:50%; object-fit:cover; border:4px solid #0d6efd; }
.theme-toggle { position:fixed; top:20px; right:20px; cursor:pointer; font-size:1.5rem; }
label.upload-btn { cursor:pointer; }
.upload-btn:hover { background:#0d6efd; color:#fff; }
.btn-save { width:100%; }
</style>
</head>
<body>

<i class="fas fa-moon theme-toggle" id="themeToggle" title="Toggle Dark Mode"></i>

<div class="profile-wrapper">
    <div class="profile-card">
        <div class="d-flex align-items-center mb-4">
     
            <div>
                <h3 class="mb-1"><?= htmlspecialchars($user['name']) ?></h3>
                <p class="text-muted mb-2"><i class="fa-solid fa-envelope"></i> <?= htmlspecialchars($user['email']) ?></p>
                <label class="btn btn-outline-primary btn-sm upload-btn">
                    <i class="fa-solid fa-camera"></i> Change Photo
                    <input type="file" name="profile_pic" form="profileForm" hidden>
                </label>
            </div>
        </div>

        <?php if($success_msg): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success_msg) ?></div>
        <?php endif; ?>
        <?php if($error_msg): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error_msg) ?></div>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data" id="profileForm">
            <div class="mb-3">
                <label class="form-label fw-semibold">Name</label>
                <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($user['name']) ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Email</label>
                <input type="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" readonly>
            </div>

            <hr>
            <h5 class="mb-3"><i class="fa-solid fa-lock"></i> Change Password</h5>
            <div class="mb-3">
                <label class="form-label">Current Password</label>
                <input type="password" name="current_password" class="form-control" placeholder="Enter current password">
            </div>
            <div class="mb-3">
                <label class="form-label">New Password</label>
                <input type="password" name="new_password" class="form-control" placeholder="Enter new password">
            </div>

            <button type="submit" class="btn btn-primary btn-save"><i class="fa-solid fa-floppy-disk"></i> Save Changes</button>
        </form>

        <div class="d-flex justify-content-between mt-4">
            <a href="dashboard.php" class="btn btn-dark"><i class="fa-solid fa-home"></i> Dashboard</a>
            <a href="invoice.php" class="btn btn-success"><i class="fa-solid fa-file-invoice"></i> Create Invoice</a>
        </div>
    </div>
</div>

<script>
const themeToggle = document.getElementById('themeToggle');
themeToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
});
</script>
</body>
</html>