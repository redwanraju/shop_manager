<?php
session_start();
include("../config/db.php");
require_once '../includes/auth.php';
start_secure_session();

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// CSRF Token
if(!isset($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(24));
$csrf_token = $_SESSION['csrf_token'];

// Fetch products
$prod_array = [];
$stmt = $conn->prepare("SELECT id, name, stock, unit, price FROM products WHERE user_id=? ORDER BY name ASC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$res = $stmt->get_result();
while($r = $res->fetch_assoc()) $prod_array[] = $r;
$stmt->close();

// Fetch shop info (name only)
$shop_info = $conn->query("SELECT name FROM users WHERE id=$user_id")->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Create Invoice</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
</head>
<body class="container py-4">

<form id="invoice_form">
    <input type="hidden" name="csrf_token" value="<?=$csrf_token?>">
    <div class="mb-3">
        <label>Customer Name</label>
        <input type="text" name="customer_name" class="form-control" placeholder="Enter Customer Name" required>
    </div>

    <table class="table table-bordered" id="invoice_table">
        <thead class="table-dark">
            <tr>
                <th>Product</th>
                <th>Qty</th>
                <th>Unit Price</th>
                <th>Line Total</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    <select name="product_id[]" class="form-select product_select" required>
                        <option value="">-- Select product --</option>
                        <?php foreach($prod_array as $p): ?>
                        <option value="<?=$p['id']?>" data-price="<?=$p['price']?>" data-stock="<?=$p['stock']?>" data-unit="<?=$p['unit']?>">
                            <?=$p['name']?> (Stock: <?=$p['stock']?> <?=$p['unit']?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </td>
                <td><input type="number" name="quantity[]" class="form-control qty_input" min="1" value="1" required></td>
                <td><input type="number" name="price[]" class="form-control price_input" step="0.01" min="0" value="0.00" required></td>
                <td class="line_total">0.00</td>
                <td class="text-center"><span class="text-danger delete_row_btn" style="cursor:pointer;">🗑</span></td>
            </tr>
        </tbody>
    </table>

    <button type="button" class="btn btn-secondary" id="add_row_btn">➕ Add Product</button>
    <button type="button" class="btn btn-outline-secondary" id="clear_rows_btn">Reset Rows</button>

    <div class="text-end mt-3">
        <h4>Grand Total: BDT <span id="grand_total">0.00</span></h4>
    </div>

    <div class="row mt-3">
        <div class="col-md-4">
            <label>Discount</label>
            <input type="number" id="discount" name="discount" class="form-control" min="0" step="0.01" value="0">
        </div>
        <div class="col-md-4">
            <label>Paid</label>
            <input type="number" id="paid" name="paid" class="form-control" min="0" step="0.01" value="0">
        </div>
        <div class="col-md-4 text-end mt-2">
            <h5>Net Total: BDT <span id="net_total">0.00</span></h5>
            <h6 class="text-danger">Due: BDT <span id="due_amount">0.00</span></h6>
        </div>
    </div>

    <div class="text-end mt-3">
        <button type="submit" class="btn btn-primary">Create Invoice</button>
    </div>
</form>

<div class="mt-4" id="invoice_buttons" style="display:none;">
    <button class="btn btn-outline-primary" id="print_btn">🖨️ Print</button>
    <button class="btn btn-outline-success" id="pdf_btn">📄 Download PDF</button>
</div>

<script>
let products = <?= json_encode($prod_array, JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>;

function makeOptionsHtml(){
    let out = '<option value="">-- Select product --</option>';
    products.forEach(p=>{
        out += `<option value="${p.id}" data-price="${p.price}" data-stock="${p.stock}" data-unit="${p.unit}">${p.name} (Stock: ${p.stock} ${p.unit})</option>`;
    });
    return out;
}

function attachListeners(tr){
    const qty = tr.querySelector('.qty_input');
    const price = tr.querySelector('.price_input');
    const select = tr.querySelector('.product_select');
    const del = tr.querySelector('.delete_row_btn');

    function recalc(){
        const total = (parseFloat(qty.value)||0)*(parseFloat(price.value)||0);
        tr.querySelector('.line_total').innerText = total.toFixed(2);
        updateGrandTotal();
    }

    select.addEventListener('change', ()=>{
        const opt = select.options[select.selectedIndex];
        if(opt) price.value = parseFloat(opt.getAttribute('data-price')||0).toFixed(2);
        recalc();
    });

    qty.addEventListener('input', recalc);
    price.addEventListener('input', recalc);

    del.addEventListener('click', ()=>{
        tr.remove();
        updateGrandTotal();
    });

    recalc();
}

function attachAllRows(){
    document.querySelectorAll('#invoice_table tbody tr').forEach(attachListeners);
}
attachAllRows();

document.getElementById('add_row_btn').addEventListener('click', ()=>{
    const tr = document.createElement('tr');
    tr.innerHTML = `<td><select name="product_id[]" class="form-select product_select" required>${makeOptionsHtml()}</select></td>
    <td><input type="number" name="quantity[]" class="form-control qty_input" min="1" value="1" required></td>
    <td><input type="number" name="price[]" class="form-control price_input" min="0" step="0.01" value="0.00" required></td>
    <td class="line_total">0.00</td>
    <td class="text-center"><span class="text-danger delete_row_btn" style="cursor:pointer;">🗑</span></td>`;
    document.querySelector('#invoice_table tbody').appendChild(tr);
    attachListeners(tr);
});

document.getElementById('clear_rows_btn').addEventListener('click', ()=>{
    const tbody = document.querySelector('#invoice_table tbody');
    tbody.innerHTML = `<tr>
        <td><select name="product_id[]" class="form-select product_select" required>${makeOptionsHtml()}</select></td>
        <td><input type="number" name="quantity[]" class="form-control qty_input" min="1" value="1" required></td>
        <td><input type="number" name="price[]" class="form-control price_input" min="0" step="0.01" value="0.00" required></td>
        <td class="line_total">0.00</td>
        <td class="text-center"><span class="text-danger delete_row_btn" style="cursor:pointer;">🗑</span></td>
    </tr>`;
    attachAllRows();
});

function updateGrandTotal(){
    let sum = 0;
    document.querySelectorAll('.line_total').forEach(td=>{
        sum += parseFloat(td.innerText)||0;
    });
    $('#grand_total').text(sum.toFixed(2));
    updatePaymentSummary();
}

function updatePaymentSummary(){
    const grand = parseFloat($('#grand_total').text()) || 0;
    const discount = parseFloat($('#discount').val()) || 0;
    const paid = parseFloat($('#paid').val()) || 0;
    const net = Math.max(grand - discount, 0);
    const due = Math.max(net - paid, 0);
    $('#net_total').text(net.toFixed(2));
    $('#due_amount').text(due.toFixed(2));
}

// Trigger live calculation
$(document).on('input', '.qty_input, .price_input, #discount, #paid', function(){
    updateGrandTotal();
});

// ===== AJAX Submit =====
$('#invoice_form').submit(function(e){
    e.preventDefault();
    $.ajax({
        url: 'ajax_save_invoice.php',
        method: 'POST',
        data: $(this).serialize(),
        dataType: 'json',
        success: function(resp){
            alert(resp.message);
            if(resp.success){
                $('#invoice_buttons').show();
            }
        },
        error: function(xhr){
            console.log(xhr.responseText);
            alert("Error saving invoice. Check console.");
        }
    });
});

// ===== Print =====
$('#print_btn').on('click', function(){
    const content = `<div style="text-align:center;">
        <h3><?=$shop_info['name']?></h3>
    </div>` + document.getElementById('invoice_table').outerHTML;
    const win = window.open('', '', 'width=900,height=650');
    win.document.write('<html><head><title>Invoice</title>');
    win.document.write('<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">');
    win.document.write('</head><body class="p-4">' + content + '</body></html>');
    win.document.close();
    win.print();
});

// ===== PDF =====
$('#pdf_btn').on('click', async function(){
    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF('p', 'pt', 'a4');
    const content = document.createElement('div');
    content.innerHTML = `<div style="text-align:center;">
        <h3><?=$shop_info['name']?></h3>
    </div>` + document.getElementById('invoice_table').outerHTML;

    await pdf.html(content, {
        callback: function(doc){
            doc.save("Invoice.pdf");
        },
        margin:[20,20,20,20],
        html2canvas:{scale:0.7}
    });
});
</script>

</body>
</html>
