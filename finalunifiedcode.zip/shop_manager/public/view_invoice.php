<?php
include("../config/db.php");
require_once '../includes/auth.php';
start_secure_session();

if (!isset($_GET['invoice_no'])) {
    die("❌ Invoice number not provided.");
}

$invoice_no = $_GET['invoice_no'];

// Fetch invoice
$stmt = $conn->prepare("SELECT * FROM invoices WHERE invoice_no = ?");
$stmt->bind_param("s", $invoice_no);
$stmt->execute();
$invoice = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$invoice) {
    die("❌ Invoice not found.");
}

// Fetch items
$item_stmt = $conn->prepare("SELECT ii.*, p.name, p.unit 
                             FROM invoice_items ii 
                             JOIN products p ON ii.product_id = p.id 
                             WHERE ii.invoice_id = ?");
$item_stmt->bind_param("i", $invoice['id']);
$item_stmt->execute();
$items = $item_stmt->get_result();
$item_stmt->close();
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="utf-8">
<title>Invoice <?= htmlspecialchars($invoice['invoice_no']) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<style>
body { background: #f9f9f9; }
.invoice-card {
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
    padding: 40px;
    max-width: 850px;
    margin: auto;
    font-family: 'Segoe UI', sans-serif;
}
.invoice-header {
    border-bottom: 2px solid #007bff;
    padding-bottom: 15px;
    margin-bottom: 20px;
}
.invoice-header h2 {
    font-weight: bold;
    color: #007bff;
}
.company-info p, .customer-info p {
    margin: 0;
    font-size: 14px;
}
.table th {
    background: #007bff;
    color: white;
    text-align: center;
}
.table td {
    vertical-align: middle;
}
.summary-table th {
    text-align: right;
    width: 150px;
}
.footer {
    text-align: center;
    font-size: 13px;
    color: #666;
    border-top: 1px dashed #ccc;
    margin-top: 20px;
    padding-top: 10px;
}
.print-btns {
    text-align: center;
    margin-top: 25px;
}
</style>
</head>
<body class="py-5">

<div class="invoice-card" id="invoice_view">
  <!-- Header -->
  <div class="invoice-header d-flex justify-content-between align-items-center">
    <div class="company-info">
      <h2>MyERP Invoice</h2>
      <p>🏢 Business Name</p>
      <p>📞 +8801XXXXXXXXX</p>
      <p>📧 info@yourbusiness.com</p>
    </div>
    <div class="text-end">
      <h5>Invoice #: <?= htmlspecialchars($invoice['invoice_no']) ?></h5>
      <p>Date: <?= date('d M, Y', strtotime($invoice['created_at'])) ?></p>
    </div>
  </div>

  <!-- Customer Info -->
  <div class="customer-info mb-3">
    <h5 class="mb-2 text-primary">Customer Information</h5>
    <p><strong>Name:</strong> <?= htmlspecialchars($invoice['customer_name']) ?></p>
  </div>

  <!-- Product Table -->
  <table class="table table-bordered align-middle text-center">
    <thead>
      <tr>
        <th>#</th>
        <th>Product</th>
        <th>Qty</th>
        <th>Unit</th>
        <th>Price</th>
        <th>Total</th>
      </tr>
    </thead>
    <tbody>
      <?php 
      $i = 1;
      $grand = 0;
      while($row = $items->fetch_assoc()): 
          $line_total = $row['quantity'] * $row['price'];
          $grand += $line_total;
      ?>
      <tr>
        <td><?= $i++ ?></td>
        <td><?= htmlspecialchars($row['name']) ?></td>
        <td><?= (int)$row['quantity'] ?></td>
        <td><?= htmlspecialchars($row['unit']) ?></td>
        <td class="text-end"><?= number_format($row['price'],2) ?></td>
        <td class="text-end"><?= number_format($line_total,2) ?></td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>

  <!-- Summary -->
  <div class="row justify-content-end mt-3">
    <div class="col-md-6">
      <table class="table summary-table table-borderless">
        <tr><th>Subtotal:</th><td class="text-end"><?= number_format($invoice['subtotal'],2) ?></td></tr>
        <tr><th>Discount:</th><td class="text-end">-<?= number_format($invoice['discount'],2) ?></td></tr>
        <tr><th>Tax:</th><td class="text-end"><?= number_format($invoice['tax'],2) ?></td></tr>
        <tr class="table-light"><th><strong>Total:</strong></th><td class="text-end"><strong><?= number_format($invoice['total'],2) ?></strong></td></tr>
        <tr><th>Paid:</th><td class="text-end"><?= number_format($invoice['paid'],2) ?></td></tr>
        <tr><th>Due:</th><td class="text-end text-danger"><?= number_format($invoice['due'],2) ?></td></tr>
      </table>
    </div>
  </div>

  <!-- Footer -->
  <div class="footer">
    <p>Thank you for your business!</p>
    <p><em>This is a computer generated invoice.</em></p>
  </div>
</div>

<!-- Buttons -->
<div class="print-btns">
  <button class="btn btn-success px-4" onclick="printInvoice()">🖨️ Print</button>
  <button class="btn btn-danger px-4" onclick="downloadPDF('<?= htmlspecialchars($invoice['invoice_no']) ?>')">📄 Download PDF</button>
  <a href="dashboard.php" class="btn btn-secondary px-4">🏠 Dashboard</a>
</div>

<script>
function printInvoice() {
    const element = document.getElementById('invoice_view');
    const w = window.open('', '', 'height=800,width=1000');
    w.document.write('<html><head><title>Print Invoice</title>');
    w.document.write('<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">');
    w.document.write('<style>body{padding:40px;font-family:Segoe UI;} .table th{background:#007bff;color:white;}</style>');
    w.document.write('</head><body>');
    w.document.write(element.innerHTML);
    w.document.write('</body></html>');
    w.document.close();
    w.print();
}

function downloadPDF(invoiceNo) {
    const element = document.getElementById('invoice_view');
    html2canvas(element).then(canvas => {
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jspdf.jsPDF('p', 'mm', 'a4');
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
        pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
        pdf.save(`Invoice_${invoiceNo}.pdf`);
    });
}
</script>
</body>
</html>
