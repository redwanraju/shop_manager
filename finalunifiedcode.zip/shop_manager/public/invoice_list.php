<?php

// Secure session + auth
session_start();
include("../config/db.php");
require_once '../includes/auth.php';
start_secure_session();

if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// 🔹 ডিফল্ট মান দিয়ে ভেরিয়েবল ডিফাইন করা
$search = $_GET['search'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to   = $_GET['date_to'] ?? '';

// ✅ Query বানানো
$sql = "SELECT * FROM invoices WHERE user_id = ?";
$params = [$user_id];
$types = "i";

if ($search !== '') {
    $sql .= " AND invoice_no LIKE ?";
    $params[] = "%$search%";
    $types .= "s";
}

if ($date_from !== '' || $date_to !== '') {
    if ($date_from === '') $date_from = '1970-01-01';
    if ($date_to === '') $date_to = date('Y-m-d');
    $sql .= " AND DATE(created_at) BETWEEN ? AND ?";
    $params[] = $date_from;
    $params[] = $date_to;
    $types .= "ss";
}

$sql .= " ORDER BY created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$res = $stmt->get_result();
$stmt->close();

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Invoice List</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body class="container py-4">
<div id="alert_placeholder"></div>

<table class="table table-bordered table-striped">
  <thead class="table-dark">
    <tr>
      <th>Invoice No</th>
      <th>Date</th>
      <th class="text-end">Total</th>
      <th class="text-end">Paid</th>
      <th class="text-end">Due</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody id="invoice_table_body">
    <?php if ($res->num_rows > 0): ?>
        <?php while($row = $res->fetch_assoc()): ?>
        <tr id="invoice_row_<?= htmlspecialchars($row['invoice_no']) ?>">
          <td><?= htmlspecialchars($row['invoice_no']) ?></td>
          <td><?= htmlspecialchars($row['created_at']) ?></td>
          <td class="text-end"><?= number_format($row['total'],2) ?></td>
          <td class="text-end"><?= number_format($row['paid'],2) ?></td>
          <td class="text-end"><?= number_format($row['due'],2) ?></td>
          <td class="d-flex gap-1">
            <a href="view_invoice.php?invoice_no=<?= urlencode($row['invoice_no']) ?>" class="btn btn-sm btn-primary">👁 View</a>
            <button class="btn btn-sm btn-danger delete_invoice_btn" data-invoice="<?= htmlspecialchars($row['invoice_no']) ?>">🗑 Delete</button>
          </td>
        </tr>
        <?php endwhile; ?>
    <?php else: ?>
        <tr>
            <td colspan="6" class="text-center text-danger">No invoices found</td>
        </tr>
    <?php endif; ?>
  </tbody>
</table>

<script>
$(document).ready(function(){

    $('.delete_invoice_btn').on('click', function(){
        if(!confirm('Are you sure you want to delete this invoice?')) return;

        let invoice_no = $(this).data('invoice');
        let row = $('#invoice_row_' + invoice_no);

        $.ajax({
            url: 'ajax_delete.php',
            type: 'POST',
            data: { delete_invoice: invoice_no },
            success: function(response){
                if(response.success){
                    row.remove();
                    $('#alert_placeholder').html('<div class="alert alert-success">✅ Invoice deleted successfully!</div>');
                } else {
                    $('#alert_placeholder').html('<div class="alert alert-danger">'+response.message+'</div>');
                }
            },
            error: function(){
                $('#alert_placeholder').html('<div class="alert alert-danger">❌ Error deleting invoice.</div>');
            }
        });
    });

});
</script>

</body>
</html>
