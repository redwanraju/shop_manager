<!-- Products Table -->
<table class="table table-bordered table-striped" id="products_table">
<thead class="table-dark">
<tr>
    <th>Name</th>
    <th>Stock</th>
    <th>Price</th>
    <th>Unit</th>
    <th>Action</th>
</tr>
</thead>
<tbody>
<?php foreach($products as $p): ?>
<tr>
    <td contenteditable="true" class="editable_name" data-id="<?=$p['id']?>"><?= htmlspecialchars($p['name']) ?></td>
    <td contenteditable="true" class="editable_stock" data-id="<?=$p['id']?>"><?= (int)$p['stock'] ?></td>
    <td contenteditable="true" class="editable_price" data-id="<?=$p['id']?>"><?= number_format($p['price'],2) ?></td>
    <td contenteditable="true" class="editable_unit" data-id="<?=$p['id']?>"><?= htmlspecialchars($p['unit']) ?></td>
    <td>
        <button class="btn btn-danger btn-sm delete_product_btn" data-id="<?=$p['id']?>">🗑 Delete</button>
    </td>
</tr>
<?php endforeach; ?>
</tbody>
</table>

<script>
// Inline Edit Function
function ajaxUpdate(id, field, value){
    $.post('all_products_update.php', {id:id, field:field, value:value}, function(resp){
        if(resp.status != 1){ 
            alert(resp.message); 
            location.reload(); 
        }
    }, 'json');
}

$(document).on('blur', '.editable_name', function(){
    ajaxUpdate($(this).data('id'), 'name', $(this).text().trim());
});

$(document).on('blur', '.editable_stock', function(){
    ajaxUpdate($(this).data('id'), 'stock', parseInt($(this).text()) || 0);
});

$(document).on('blur', '.editable_price', function(){
    ajaxUpdate($(this).data('id'), 'price', parseFloat($(this).text()) || 0);
});

$(document).on('blur', '.editable_unit', function(){
    ajaxUpdate($(this).data('id'), 'unit', $(this).text().trim());
});

// Delete product
$(document).on('click', '.delete_product_btn', function(){
    if(!confirm('Are you sure you want to delete this product?')) return;
    let id = $(this).data('id');
    $.post('all_products_delete.php', {id:id}, function(resp){
        if(resp.status == 1) location.reload();
        else alert(resp.message);
    }, 'json');
});

// Search/filter
$('#product_search').on('keyup', function(){
    let val = $(this).val().toLowerCase();
    $('#products_table tbody tr').filter(function(){
        $(this).toggle(
            $(this).find('td:first').text().toLowerCase().indexOf(val) > -1 ||
            $(this).find('td:eq(3)').text().toLowerCase().indexOf(val) > -1
        );
    });
});
</script>