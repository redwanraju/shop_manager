<?php
session_start();
include("../includes/header.php");
include("../config/db.php");
require_once '../includes/auth.php';

$errors = [];
$success = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // CSRF token verification
    if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
        $errors[] = "Invalid form submission!";
    } else {
        $name     = trim($_POST['name'] ?? '');
        $email    = trim($_POST['email'] ?? '');
        $mobile   = trim($_POST['mobile'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm  = $_POST['confirm_password'] ?? '';

        if ($name === '' || $email === '' || $mobile === '' || $password === '' || $confirm === '') {
            $errors[] = "সব ঘর পূরণ করুন।";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "সঠিক ইমেইল দিন।";
        } elseif ($password !== $confirm) {
            $errors[] = "পাসওয়ার্ড মিলছে না।";
        } else {
            // check if user exists
            $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $res = $stmt->get_result();

            if ($res->num_rows > 0) {
                $errors[] = "ইমেইলটি ইতিমধ্যে রেজিস্টার্ড।";
            } else {
                // hash password
                $hash = password_hash($password, PASSWORD_DEFAULT);

                $insert = $conn->prepare("INSERT INTO users (name, email, mobile, access, trial_start, password_hash, created_at) VALUES (?, ?, ?, 'off', NOW(), ?, NOW())");
                $insert->bind_param("ssss", $name, $email, $mobile, $hash);
                if ($insert->execute()) {
                    $success = "রেজিস্ট্রেশন সফল। এখন লগইন করুন।";
                    $_POST = [];
                    $_SESSION['csrf_token'] = bin2hex(random_bytes(24));
                } else {
                    $errors[] = "রেজিস্ট্রেশন ব্যর্থ।";
                }
                $insert->close();
            }
            $stmt->close();
        }
    }
}

// generate CSRF token
$csrf = generate_csrf_token();
?>

<div class="container mt-5">
    <div class="card mx-auto" style="max-width: 500px; padding: 30px; border-radius: 1rem; box-shadow: 0 5px 20px rgba(0,0,0,0.1);">
        <h2 class="mb-4 text-center"><i class="fa-solid fa-user-plus"></i> Register</h2>

        <?php if (!empty($success)): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <?php foreach($errors as $e) echo htmlspecialchars($e) . "<br>"; ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="mt-3">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf) ?>">

            <input type="text" name="name" class="form-control mb-2" placeholder="Full Name" required value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">
            <input type="email" name="email" class="form-control mb-2" placeholder="Email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
            <input type="text" name="mobile" class="form-control mb-2" placeholder="Mobile Number" required value="<?= htmlspecialchars($_POST['mobile'] ?? '') ?>">

            <input type="password" name="password" class="form-control mb-2" placeholder="Password" required>
            <input type="password" name="confirm_password" class="form-control mb-2" placeholder="Confirm Password" required>

            <button class="btn btn-primary w-100"><i class="fa-solid fa-user-plus"></i> Register</button>
            <div class="text-center mt-3">
                Or <a class="btn btn-outline-secondary btn-sm" href="login.php">Login</a>
            </div>
        </form>
    </div>
</div>

<?php include("../includes/footer.php"); ?>