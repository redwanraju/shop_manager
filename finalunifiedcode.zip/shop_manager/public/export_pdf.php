<?php
//ini_set('memory_limit', '1024M'); // 1GB memory
//require('../public/export_pdf.php');
// ডাটাবেজ কানেকশন
session_start();
include("../config/db.php");
require_once '../includes/auth.php';
start_secure_session();
//$user_id = $_SESSION['user_id'] ?? 0;
if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$user_id = $_SESSION['user_id'];


$warning = '';
$invoice_id = '';

if(isset($_POST['create_invoice'])){
    $invoice_no = "INV".time();
    $products = $_POST['product_id'];
    $quantities = $_POST['quantity'];
    $prices = $_POST['price'];
    $discount = floatval($_POST['discount']);
    $tax_percent = floatval($_POST['tax']);
    $paid = floatval($_POST['paid']);
    $subtotal = 0;

    // Insert invoice
    $conn->query("INSERT INTO invoices (invoice_no) VALUES ('$invoice_no')");
    $invoice_id = $conn->insert_id;

    foreach($products as $i => $product_id){
        $qty = (int)$quantities[$i];
        $price = (float)$prices[$i];

        $res = $conn->query("SELECT stock, min_stock, name, unit FROM products WHERE id=$product_id");
        $row = $res->fetch_assoc();
        $current_stock = $row['stock'];
        $min_stock = $row['min_stock'];
        $product_name = $row['name'];
        $unit = $row['unit'];

        if($qty > $current_stock){
            $warning .= "Warning: Stock of $product_name is insufficient.<br>";
            $qty = $current_stock;
        }

        $conn->query("INSERT INTO invoice_items (invoice_id, product_id, quantity, price) 
                      VALUES ($invoice_id, $product_id, $qty, $price)");

        $new_stock = $current_stock - $qty;
        $conn->query("UPDATE products SET stock=$new_stock WHERE id=$product_id");

        if($new_stock < $min_stock){
            $warning .= "Warning: Stock of $product_name is below minimum ($min_stock).<br>";
        }

        $subtotal += $qty * $price;
    }

    $tax_amount = ($subtotal - $discount) * ($tax_percent/100);
    $total = $subtotal - $discount + $tax_amount;
    $due = $total - $paid;

    $conn->query("UPDATE invoices SET subtotal=$subtotal, discount=$discount, tax=$tax_amount, total=$total, paid=$paid, due=$due WHERE id=$invoice_id");

    $msg = "Invoice created successfully!";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create Invoice</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

    <!-- jsPDF + html2canvas -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>

    <script>
        function addRow(){
            let table = document.getElementById("invoice_table");
            let row = table.insertRow();
            row.innerHTML = `<td>
                <select name="product_id[]" class="form-select" required>
                    <?php
                    $res = $conn->query("SELECT * FROM products");
                    while($r = $res->fetch_assoc()){
                        echo "<option value='{$r['id']}'>{$r['name']} (Stock: {$r['stock']} {$r['unit']})</option>";
                    }
                    ?>
                </select>
            </td>
            <td><input type="number" name="quantity[]" class="form-control" min="1" required></td>
            <td><input type="number" step="0.01" name="price[]" class="form-control" min="0" required></td>`;
        }

        function printInvoice(){
            let divContents = document.getElementById("invoice_print").innerHTML;
            let a = window.open('', '', 'height=600, width=800');
            a.document.write('<html><body>');
            a.document.write(divContents);
            a.document.write('</body></html>');
            a.document.close();
            a.print();
        }

        function downloadPDF(){
            const element = document.getElementById("invoice_print");
            html2canvas(element).then((canvas) => {
                const imgData = canvas.toDataURL('image/png');
                const pdf = new jspdf.jsPDF('p', 'mm', 'a4');
                const pdfWidth = pdf.internal.pageSize.getWidth();
                const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
                pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
                pdf.save("Invoice_<?= $invoice_data['invoice_no'] ?? 'new' ?>.pdf");
            });
        }
    </script>
</head>
<body class="container mt-5">
    <h2 class="mb-4">🧾 Create Invoice</h2>

    <?php if(!empty($msg)) echo "<div class='alert alert-success'>$msg</div>"; ?>
    <?php if(!empty($warning)) echo "<div class='alert alert-warning'>$warning</div>"; ?>

    <form method="POST">
        <table class="table table-bordered" id="invoice_table">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Quantity</th>
                    <th>Unit Price</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>
                        <select name="product_id[]" class="form-select" required>
                            <?php
                            $res = $conn->query("SELECT * FROM products");
                            while($r = $res->fetch_assoc()){
                                echo "<option value='{$r['id']}'>{$r['name']} (Stock: {$r['stock']} {$r['unit']})</option>";
                            }
                            ?>
                        </select>
                    </td>
                    <td><input type="number" name="quantity[]" class="form-control" min="1" required></td>
                    <td><input type="number" step="0.01" name="price[]" class="form-control" min="0" required></td>
                </tr>
            </tbody>
        </table>

        <button type="button" class="btn btn-secondary mb-3" onclick="addRow()">➕ Add More Product</button>

        <div class="row mb-3">
            <div class="col-md-4">
                <label>Discount</label>
                <input type="number" step="0.01" name="discount" class="form-control" value="0">
            </div>
            <div class="col-md-4">
                <label>Tax %</label>
                <input type="number" step="0.01" name="tax" class="form-control" value="0">
            </div>
            <div class="col-md-4">
                <label>Paid Amount</label>
                <input type="number" step="0.01" name="paid" class="form-control" value="0">
            </div>
        </div>

        <button type="submit" name="create_invoice" class="btn btn-primary">Create Invoice</button>
    </form>

    <?php if($invoice_id): 
        $invoice_data = $conn->query("SELECT * FROM invoices WHERE id=$invoice_id")->fetch_assoc();
        $items = $conn->query("SELECT ii.*, p.name, p.unit FROM invoice_items ii 
                               JOIN products p ON ii.product_id=p.id 
                               WHERE ii.invoice_id=$invoice_id");
    ?>
        <div class="card p-4 mt-4" id="invoice_print">
            <h4>Invoice No: <?= $invoice_data['invoice_no'] ?></h4>
            <p>Date: <?= $invoice_data['date'] ?></p>
            <table class="table table-bordered">
                <thead>
                    <tr><th>Product</th><th>Quantity</th><th>Unit</th><th>Price</th><th>Total</th></tr>
                </thead>
                <tbody>
                    <?php 
                    $grand_total = 0;
                    while($item=$items->fetch_assoc()){ 
                        $item_total = $item['quantity'] * $item['price'];
                        $grand_total += $item_total;
                    ?>
                        <tr>
                            <td><?= $item['name'] ?></td>
                            <td><?= $item['quantity'] ?></td>
                            <td><?= $item['unit'] ?></td>
                            <td><?= number_format($item['price'],2) ?></td>
                            <td><?= number_format($item_total,2) ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>

            <div class="row">
                <div class="col-md-6"></div>
                <div class="col-md-6">
                    <table class="table table-borderless">
                        <tr>
                            <th class="text-end">Subtotal:</th>
                            <td class="text-end"><?= number_format($invoice_data['subtotal'],2) ?></td>
                        </tr>
                        <tr>
                            <th class="text-end">Discount:</th>
                            <td class="text-end"><?= number_format($invoice_data['discount'],2) ?></td>
                        </tr>
                        <tr>
                            <th class="text-end">Tax:</th>
                            <td class="text-end"><?= number_format($invoice_data['tax'],2) ?></td>
                        </tr>
                        <tr>
                            <th class="text-end">Total:</th>
                            <td class="text-end"><?= number_format($invoice_data['total'],2) ?></td>
                        </tr>
                        <tr>
                            <th class="text-end">Paid:</th>
                            <td class="text-end"><?= number_format($invoice_data['paid'],2) ?></td>
                        </tr>
                        <tr>
                            <th class="text-end">Due:</th>
                            <td class="text-end"><?= number_format($invoice_data['due'],2) ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>

                <!-- Print & PDF Export Buttons -->
        <div class="mt-3">
            <button class="btn btn-primary" onclick="printInvoice()">🖨️ Print Invoice</button>
            <button class="btn btn-danger" onclick="downloadPDF()">📄 Download PDF</button>
        </div>
    <?php endif; ?>
</body>
</html>
