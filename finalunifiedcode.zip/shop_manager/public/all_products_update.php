<?php
session_start();
include("../config/db.php");
require_once '../includes/auth.php';
start_secure_session();
//$user_id = $_SESSION['user_id'] ?? 0;
if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$user_id = $_SESSION['user_id'];
header('Content-Type: application/json');
if(!isset($_SESSION['user_id'])) exit(json_encode(['status'=>0,'message'=>'Not logged in']));

$user_id=$_SESSION['user_id'];
$id=intval($_POST['id']??0);
$field=$_POST['field']??'';
$value=$_POST['value']??'';

if($id<=0 || !in_array($field,['stock','price','unit'])) exit(json_encode(['status'=>0,'message'=>'Invalid request']));

if($field=='stock'||$field=='price') $value=floatval($value); else $value=trim($value);

$stmt=$conn->prepare("UPDATE products SET $field=? WHERE id=? AND user_id=?");
if($field=='stock') $stmt->bind_param("iii",$value,$id,$user_id);
elseif($field=='price') $stmt->bind_param("dii",$value,$id,$user_id);
else $stmt->bind_param("sii",$value,$id,$user_id);

if($stmt->execute()) echo json_encode(['status'=>1,'message'=>'Updated successfully']);
else echo json_encode(['status'=>0,'message'=>'Database error']);
$stmt->close();