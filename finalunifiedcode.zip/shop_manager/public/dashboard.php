<?php
session_start();
include("../config/db.php");
require_once '../includes/auth.php';
start_secure_session();

if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'] ?? 'User';

// Fetch Dashboard summary
function fetch_value($conn, $query, $user_id) {
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i",$user_id);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return array_values($res)[0] ?? 0;
}

$total_today = fetch_value($conn, "SELECT SUM(total) FROM invoices WHERE user_id=? AND DATE(created_at)=CURDATE()", $user_id);
$cash_today = fetch_value($conn, "SELECT SUM(paid) FROM invoices WHERE user_id=? AND DATE(created_at)=CURDATE()", $user_id);
$due_today = fetch_value($conn, "SELECT SUM(due) FROM invoices WHERE user_id=? AND DATE(created_at)=CURDATE()", $user_id);
$total_invoice = fetch_value($conn, "SELECT COUNT(*) FROM invoices WHERE user_id=?", $user_id);
$total_products = fetch_value($conn, "SELECT COUNT(*) FROM products WHERE user_id=?", $user_id);

?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<title>Dashboard | MyERP</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>

<style>
/* Theme color variables */
:root {
  --main-bg: #f4f6f9;
  --text-color: #222;
  --card-bg: #ffffff;
}
.dark-mode {
  --main-bg: #181a1b;
  --text-color: #e6e6e6;
  --card-bg: #242526;
}
body {
  background-color: var(--main-bg);
  color: var(--text-color);
  transition: all 0.3s ease;
}
.navbar-custom {
  background-color: var(--card-bg);
  border-bottom: 1px solid #ddd;
}
</style>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

<?php include("sidebar.php"); ?>

<!-- ======= Top Navbar ======= -->
<nav class="main-header navbar navbar-expand navbar-light navbar-custom">
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
    </li>
    <li class="nav-item d-none d-sm-inline-block">
      <span class="nav-link">👋 স্বাগতম, <?= htmlspecialchars($user_name) ?></span>
    </li>
  </ul>

  <ul class="navbar-nav ml-auto">
    <!-- Theme toggle -->
    <li class="nav-item">
      <a class="nav-link" href="#" id="themeToggle" title="থিম পরিবর্তন করুন">
        <i class="fas fa-moon"></i>
      </a>
    </li>

    <!-- Profile -->
    <li class="nav-item">
      <a class="nav-link" href="profile.php" title="প্রোফাইল">
        <i class="fas fa-user"></i>
      </a>
    </li>

    <!-- Logout -->
    <li class="nav-item">
      <a class="nav-link text-danger" href="logout.php" title="লগআউট">
        <i class="fas fa-sign-out-alt"></i>
      </a>
    </li>
  </ul>
</nav>

<!-- ======= Content ======= -->
<div class="content-wrapper">
  <div class="content-header">
    <div class="container-fluid">
      <h3>ড্যাশবোর্ড</h3>
      <p class="text-muted">আপনার ব্যবসার সারসংক্ষেপ নিচে দেখানো হয়েছে।</p>
    </div>
  </div>

  <section class="content">
    <div class="container-fluid">

      <!-- Dashboard Summary -->
      <!-- Dynamic Section -->
      <div id="dynamic_content"></div>

    </div>
  </section>
</div>
</div>

<!-- ======= Theme System ======= -->
<script>
document.addEventListener('DOMContentLoaded', function() {
  const body = document.body;
  const themeToggle = document.getElementById('themeToggle');
  const currentTheme = localStorage.getItem('theme') || 'light';

  if (currentTheme === 'dark') body.classList.add('dark-mode');

  themeToggle.addEventListener('click', () => {
    body.classList.toggle('dark-mode');
    const newTheme = body.classList.contains('dark-mode') ? 'dark' : 'light';
    localStorage.setItem('theme', newTheme);
  });
});

// Dynamic content load functions
function AjaxSummary() { $('#dynamic_content').load('ajax_dashboard_summary.php'); }
function showProducts() { $('#dynamic_content').load('all_products.php'); }
function showInvoiceForm() { $('#dynamic_content').load('invoice.php'); }
function showAllInvoices() { $('#dynamic_content').load('ajax_all_invoices.php'); }
function totalInvoices() { $('#dynamic_content').load('invoice_list.php'); }
function stockLow() { $('#dynamic_content').load('ajax_low_stock.php'); }
</script>

</body>
</html>
