<?php
function updateProductStock($conn, $shop_id, $invoice_items) {
    foreach($invoice_items as $product_id => $qty){
        $product_id = intval($product_id);
        $qty = intval($qty);

        // প্রোডাক্ট স্টক চেক
        $row = $conn->query("SELECT quantity, name FROM products WHERE id=$product_id AND shop_id=$shop_id")->fetch_assoc();
        if(!$row){
            continue; // product not found
        }

        if($qty > $row['quantity']){
            die("Error: Quantity for '{$row['name']}' exceeds available stock ({$row['quantity']}).");
        }

        // প্রোডাক্টের quantity কমানো
        $stmt = $conn->prepare("UPDATE products SET quantity = quantity - ? WHERE id=? AND shop_id=?");
        $stmt->bind_param("iii", $qty, $product_id, $shop_id);
        $stmt->execute();
        $stmt->close();

        // Optional: stock 0 হলে লগ/notice
        if($row['quantity'] - $qty <= 0){
            // এখানে চাইলে alert বা log করতে পারেন
            // echo "Warning: '{$row['name']}' is now out of stock!";
        }
    }
}
?>
