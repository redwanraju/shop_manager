<?php
// includes/db.php
$servername = "localhost"; // অথবা আপনার host
$username   = "root";
$password   = "";
$dbname     = "shop_manager";

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$conn = new mysqli($servername, $username, $password, $dbname);
$conn->set_charset('utf8mb4');
