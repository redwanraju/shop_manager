
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop Manager</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Custom Styles -->
    <style>
        body {
            background: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar {
            background: linear-gradient(45deg, #0d6efd, #0b5ed7);
        }
        .navbar-brand {
            font-weight: bold;
            color: #fff !important;
        }
        .nav-link {
            color: #f1f1f1 !important;
            transition: 0.3s;
        }
        .nav-link:hover {
            color: #ffd700 !important;
        }
        .card {
            border-radius: 1rem;
        }
        footer {
            background: #0d6efd;
            color: #fff;
            padding: 10px 0;
            text-align: center;
            margin-top: 40px;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="../public/dashboard.php">
            <i class="bi bi-shop"></i> Shop Manager
        </a>
        <button class="navbar-toggler text-white" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <?php if (!empty($_SESSION['user_id'])): ?>
				 <li class="nav-item">
                        <a class="nav-link" href="../admin/index.php"><i class="bi bi-speedometer2"></i> Admin Panel</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../public/all_products.php"><i class="bi bi-speedometer2"></i> Add Products</a>
                    </li>
					<li class="nav-item">
                        <a class="nav-link" href="../public/invoice.php"><i class="bi bi-speedometer2"></i> Create Invoice</a>
                    </li>
					<li class="nav-item">
                        <a class="nav-link" href="../public/invoice_list.php"><i class="bi bi-speedometer2"></i> All Invoice</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../public/profile.php"><i class="bi bi-person-circle"></i> Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-danger" href="../public/logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="../public/login.php"><i class="bi bi-box-arrow-in-right"></i> Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../public/signup.php"><i class="bi bi-person-plus"></i> Register</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>